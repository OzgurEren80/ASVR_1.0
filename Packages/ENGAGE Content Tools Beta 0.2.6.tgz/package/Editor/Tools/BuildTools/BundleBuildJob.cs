﻿using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using Debug = UnityEngine.Debug;

namespace Engage.CreatorSDK
{
    public enum AssetType
    {
        Undefined = 0,
        Location = 1,
        IFX = 2,
        Snapshot
    }

    public class BundleBuildJob
    {
        protected BundleBuildJob() { }

        public BundleBuildJob(string guid)
        {
            BundleGuid = guid;
            BundlePath = AssetDatabase.GUIDToAssetPath(guid);
            BundleLabel = Path.GetFileNameWithoutExtension(BundlePath);

            Initialize();
        }

        public string BundleGuid { get; }
        public string BundlePath { get; }
        public string BundleLabel { get; set; }

        public EngagePlatform BuildTargets { get; set; }
        public AssetType AssetType { get; set; }

        public bool IsQAPassed { get; protected set; }

        public EngagePlatform Completed { get; protected set; }
        public EngagePlatform Failed { get; protected set; }

        public bool buildQACheckOverride { get; set; }

        public Action<BundleBuildJob, EngagePlatform> OnComplete;
        public Action<BundleBuildJob, EngagePlatform> OnFail;

        public void Initialize()
        {
            UpdateAssetType();
            RunQATests();
        }

        public async void RunQATests()
        {
            //TODO: run QA tests for real
            //if (!buildQACheckOverride)
            //{
            //    var qaTool = UnityEngine.ScriptableObject.CreateInstance<IFXToolsQualityCheckTool>();

            //    // repaint

            //    IsQAPassed = await qaTool.BundleQualityCheck(this);

            //    // repaint
            //}

            IsQAPassed = true;
        }

        public void Fail(EngagePlatform platform)
        {
            Failed |= platform;
            OnFail?.Invoke(this, platform);
        }

        public void Complete(EngagePlatform platform)
        {
            Completed |= platform;
            OnComplete?.Invoke(this, platform);
        }

        public void Clear(EngagePlatform platform)
        {
            Failed &= ~platform;
            Completed &= ~platform;
        }

        public void Clear()
        {
            Failed = EngagePlatform.None;
            Completed = EngagePlatform.None;
        }

        public void UpdateAssetType()
        {
            if (AssetDatabase.IsValidFolder(BundlePath))
            {
                Debug.Log($"PATH: {BundlePath} (Valid Folder: {AssetDatabase.IsValidFolder(BundlePath)})");

                var bundlePath = new string[] { BundlePath };

                if (AssetDatabase.FindAssets("t:scene", bundlePath).Length > 0)
                {
                    AssetType = AssetType.Location;
                }
                else if (AssetDatabase.FindAssets("t:prefab", bundlePath).Length > 0)
                {
                    AssetType = AssetType.IFX;
                }
                else
                {
                    AssetType = AssetType.Undefined;
                }
            }
            else
            {
                var type = AssetDatabase.GetMainAssetTypeAtPath(BundlePath);

                if (type == typeof(SceneAsset))
                {
                    AssetType = AssetType.Location;
                }
                else if (type == typeof(GameObject))
                {
                    AssetType = AssetType.IFX;
                }
                else
                {
                    AssetType = AssetType.Undefined;
                }
            }
        }

        public string[] GetAssetList()
        {
            var assetList = new string[] { BundlePath };

            if (AssetDatabase.IsValidFolder(BundlePath))
            {
                if (AssetType == AssetType.Location)
                {
                    var guids = AssetDatabase.FindAssets("t:scene", assetList);
                    assetList = new string[guids.Length];

                    for (int i = 0; i < guids.Length; i++)
                    {
                        assetList[i] = AssetDatabase.GUIDToAssetPath(guids[i]);
                    }
                }
                else if (AssetType == AssetType.IFX)
                {
                    var guids = AssetDatabase.FindAssets("t:prefab", assetList);
                    assetList = new string[guids.Length];

                    for (int i = 0; i < guids.Length; i++)
                    {
                        assetList[i] = AssetDatabase.GUIDToAssetPath(guids[i]);
                    }
                }
            }

            return assetList;
        }
    }
}