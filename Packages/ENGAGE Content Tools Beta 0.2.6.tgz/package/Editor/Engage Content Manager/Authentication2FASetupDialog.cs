﻿using Engage.UI.Editor;
using UnityEditor;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    public class Authentication2FASetupDialog : EngageConfirmDialog<EngageUser>
    {
        public class Labels : Content.Labels
        {
            public const string Setup2FANotificationTitle = "Security Policy Update";
            public const string Setup2FANotificationMessage = "As a member of {0} group, you must set up & enable two-factor authentication (2FA) before you can log in.";

            public const string Setup2FANotificationNewEmailMessage = "We've sent you an email with more information and a link to begin the process.";
        }

        protected const int heightExtent = 100;
        protected const int widthExtent = 150;

        public override void Draw()
        {
            EditorGUILayout.Space();

            using (var messagePanel = new EditorGUILayout.HorizontalScope(GUILayout.MinHeight(60)))
            {
                EditorGUILayout.LabelField(string.Empty, GUILayout.Width(20));
                using (var content = new EditorGUILayout.VerticalScope())
                {
                    EditorGUILayout.LabelField(MessageBody, MessageStyle);
                    
                    EditorGUILayout.LabelField(string.Empty);

                    EditorGUILayout.LabelField(Labels.Setup2FANotificationNewEmailMessage, MessageStyle);
                }
                EditorGUILayout.LabelField(string.Empty, GUILayout.Width(20));
            }

            EditorGUILayout.LabelField(string.Empty, GUILayout.ExpandHeight(true));

            using (var selectionButtons = new EditorGUILayout.HorizontalScope())
            {
                GuiTools.DrawButton(LabelConfirm, ConfirmSelection);
            }
        }

        public static void OpenDialog()
        {
            var dialog = GetWindow<Authentication2FASetupDialog>(Labels.Setup2FANotificationTitle);

            dialog.MessageBody = string.Format(Labels.Setup2FANotificationMessage, EngageUser.LastLoginRequestResponse.Details.PolicyGroup?.Name);

            dialog.LabelConfirm = Labels.Login2FAReturnToLoginLabel;
            dialog.OnConfirm = dialog.Close;

            var extents = new Vector2(widthExtent, heightExtent);

            dialog.maxSize = dialog.minSize = extents * 2;

            // TODO: set position relative to parent view

            dialog.ShowModalUtility();
        }
    }
}
