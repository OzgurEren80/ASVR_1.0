﻿namespace Engage.AssetManagement.Content
{
    public class GroupData : IGroup, IData<IGroup>
    {
        public int? Id { get; set; }
        public string Name { get; set; }
        public string CreatedAt { get; set; }
        public string UpdatedAt { get; set; }

        public GroupData() { }
        public GroupData(string name, int? id = null)
        {
            Id = id;
            Name = name;
        }
        public GroupData(IGroup group)
        {
            SetValues(group);
        }

        public void SetValues(IGroup data)
        {
            Id = data.Id;
            Name = data.Name;
            CreatedAt = data.CreatedAt;
            UpdatedAt = data.UpdatedAt;
        }
    }
}
