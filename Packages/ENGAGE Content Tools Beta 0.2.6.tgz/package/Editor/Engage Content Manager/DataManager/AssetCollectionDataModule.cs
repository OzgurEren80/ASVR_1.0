﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Engage.AssetManagement.Content
{
    public class AssetCollectionDataModule : NamedItemDataModule<IAssetCollection, AssetCollectionData>
    {
        protected AssetCollectionClient ApiClient => EngageUser.ApiClient.Module<AssetCollectionClient>();

        protected override Func<Task<IList<IAssetCollection>>> ClientGetListAsync
            => () => ApiClient.GetAsync();
        protected override Func<int, Task<IAssetCollection>> ClientGetSingleAsync
            => (id) => ApiClient.GetAsync(id);
        protected override Func<IAssetCollection, Task<IAssetCollection>> ClientCreateAsync
            => (item) => ApiClient.CreateAsync(item);
        protected override Func<IAssetCollection, Task<bool>> ClientUpdateAsync
            => (item) => ApiClient.UpdateAsync(item);

        public virtual async Task<bool> UploadThumbnail(IAssetCollection item, string imagePath, Action<float> progressCallback)
        {
            var thumbnailPackage = ThumbnailFormData.Create(imagePath);
            var success = await ApiClient.UploadThumbnail(item, thumbnailPackage, progressCallback);

            if (success)
            {
                Update(await ClientGetSingleAsync(item.Id.Value));
            }

            return success;
        }
    }
}
