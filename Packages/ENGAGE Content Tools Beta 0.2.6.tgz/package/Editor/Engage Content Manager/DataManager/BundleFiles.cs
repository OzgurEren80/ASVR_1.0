﻿using Engage.CreatorSDK;
using Engage.Network;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    public class BundleFiles : Dictionary<EngagePlatform, BundleFile>
    {
        public string Name { get; }

        public EngagePlatform Platforms => Keys.Aggregate(EngagePlatform.None, (platforms, platform) => platforms |= platform);

        public EngagePlatform Uploaded
        {
            get
            {
                var uploads = EngagePlatform.None;

                foreach (var platform in Keys)
                {
                    if (this[platform].Uploaded)
                    {
                        uploads |= platform;
                    }
                }

                return uploads;
            }
        }

        public BundleFiles(string bundleName)
        {
            Name = bundleName;
        }

        public bool TryAdd(EngagePlatform platform, BundleFile file, bool replace = false)
        {
            if (ContainsKey(platform))
            {
                Debug.LogWarning($"[{GetType()}.{nameof(TryAdd)}] {Name} already contains and entry for {platform}");

                if (replace)
                {
                    this[platform] = file;
                }

                return false;
            }
            else
            {
                Add(platform, file);
                return true;
            }
        }

        public void Refresh(string assetPath = null)
        {
            if (string.IsNullOrEmpty(assetPath))
            {
                assetPath = BuildSettings.LocalBuildPath;
            }

            var assetPathInfo = new DirectoryInfo(assetPath);

            if (!assetPathInfo.Exists)
            {
                Debug.LogWarning($"[Bundle Manager] Local Bundle Path cannot be found: {assetPath}");
                return;
            }

            Clear();

            foreach (var dir in assetPathInfo.EnumerateDirectories())
            {
                if (Enum.TryParse(dir.Name, out EngagePlatform platform))
                {
                    if (BundleFile.TryGetBundleFile(platform, dir.FullName, Name, out BundleFile localFile))
                    {
                        TryAdd(platform, localFile);
                    }
                }
            }
        }

        public void Refresh(EngagePlatform platform, string assetPath = null)
        {
            if (string.IsNullOrEmpty(assetPath))
            {
                assetPath = BuildSettings.GetLocalBundlePath(platform);
            }

            var assetPathInfo = new DirectoryInfo(assetPath);

            if (assetPathInfo.Exists)
            {
                if (BundleFile.TryGetBundleFile(platform, assetPathInfo.FullName, Name, out BundleFile localFile))
                {
                    TryAdd(platform, localFile);
                }
            }
        }
    }

    public class BundleManifest
    {
        public int ManifestFileVersion { get; set; }
        public string CRC { get; set; }
        public List<string> Assets { get; } = new List<string>();

        public static BundleManifest Load(string manifestPath)
        {
            if (!File.Exists(manifestPath))
            {
                return null;
            }

            var manifest = new BundleManifest();
            var lines = File.ReadAllLines(manifestPath);

            for(int i = 0; i < lines.Length; i++)
            {
                var parts = lines[i].Split(':');

                if (parts.Length == 0)
                    continue;

                switch(parts[0])
                {
                    case nameof(ManifestFileVersion):
                        int.TryParse(parts[1].Trim(), out int fileVersion);
                        manifest.ManifestFileVersion = fileVersion;
                        break;
                    case nameof(CRC):
                        manifest.CRC = parts[1].Trim();
                        break;
                    case nameof(Assets):
                        for(int j = i + 1; j < lines.Length; j++, i++)
                        {
                            if (lines[j].StartsWith("-"))
                            {
                                manifest.Assets.Add(lines[j]);
                            }
                            else
                            {
                                break;
                            }
                        }
                        break;
                    default:
                        break;
                }
            }

            return manifest;
        }

        public static string[] GetAllAssetPaths(string manifestPath, string filter = null)
        {
            return File.ReadAllLines(manifestPath).Where(line => line.EndsWith(filter)).OrderBy(line => line).ToArray();
        }
    }

    public class BundleFile
    {
        public const string dataExtension = ".json";
        public const string bundleExtension = ".engagebundle";
        public const string manifestExtension = ".manifest";

        public FileInfo Bundle { get; }
        public FileInfo Manifest { get; }
        public string CRC { get; }
        public EngagePlatform Platform { get; private set; }

        public RequestStatus Status { get; set; } = RequestStatus.None;
        public float UploadProgress { get; private set; }
        public bool Uploaded { get; set; }//=> EngageUser.WasUploaded(this);

        public event Action<BundleFile, float> OnProgressUpdated;

        public static BundleFile GetBundleFile(EngagePlatform platform, string filePath, string bundleName)
        {
            var bundleFile = new BundleFile(platform, filePath, bundleName);

            return bundleFile;
        }

        public static bool TryGetBundleFile(EngagePlatform platform, string filePath, string bundleName, out BundleFile bundleFile)
        {
            bundleFile = new BundleFile(platform, filePath, bundleName);

            return bundleFile.Bundle.Exists;
        }

        public BundleFile(EngagePlatform platform, string path, string bundleName)
        {
            Platform = platform;
            Bundle = new FileInfo(Path.Combine(path, bundleName + bundleExtension));
            Manifest = new FileInfo(Path.Combine(path, bundleName + manifestExtension));
            CRC = BundleManifest.Load(Manifest.FullName)?.CRC;
        }

        public void UpdateProgress(float progress)
        {
            UploadProgress = progress;
            OnProgressUpdated?.Invoke(this, progress);
        }
    }
}
