﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Engage.AssetManagement.Content
{
    public class AssetCollectionData : IAssetCollection, IData<IAssetCollection>
    {
        public int? Id { get; set; }
        public string Name { get; set; }
        public string CreatedAt { get; set; }
        public string UpdatedAt { get; set; }
        public string PrettyName { get; set; }
        //public int UserId { get; set; }
        public string Image { get; set; }

        [JsonConverter(typeof(EngageItemListConverter<IGroup, Group>))]
        public List<IGroup> Groups { get; } = new List<IGroup>();

        public AssetCollectionData() { }
        public AssetCollectionData(string name, int? id = null)
        {
            Id = id;
            PrettyName = name;
        }
        public AssetCollectionData(IAssetCollection collection)
        {
            SetValues(collection);
        }

        public void SetValues(IAssetCollection data)
        {
            Id = data.Id;
            Name = data.Name;
            PrettyName = data.PrettyName;
            CreatedAt = data.CreatedAt;
            UpdatedAt = data.UpdatedAt;
            //UserId = data.UserId;
            Image = data.Image;
        }
    }
}
