﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Engage.AssetManagement.Content
{
    public class LocationAssetDataModule : NamedItemDataModule<ILocationAsset, LocationAssetData>
    {
        protected LocationAssetClient ApiClient => EngageUser.ApiClient.Module<LocationAssetClient>();

        protected override Func<Task<IList<ILocationAsset>>> ClientGetListAsync
            => () => ApiClient.GetAsync();
        protected override Func<int, Task<ILocationAsset>> ClientGetSingleAsync
            => (id) => ApiClient.GetAsync(id);
        protected override Func<ILocationAsset, Task<ILocationAsset>> ClientCreateAsync
            => (item) => ApiClient.CreateAsync(item);
        protected override Func<ILocationAsset, Task<bool>> ClientUpdateAsync
            => (item) => ApiClient.UpdateAsync(item);
        protected override Func<ILocationAsset, Task<bool>> ClientDeleteAsync
            => (item) => ApiClient.DeleteAsync(item);

        public virtual async Task<bool> UploadThumbnail(ILocationAsset item, string imagePath, Action<float> progressCallback)
        {
            var thumbnailPackage = ThumbnailFormData.Create(imagePath);
            var success = await ApiClient.UploadThumbnail(item, thumbnailPackage, progressCallback);

            if (success)
            {
                Update(await ClientGetSingleAsync(item.Id.Value));
            }

            return success;
        }

        public async Task<bool> UploadBundle(ILocationAsset item, BundleFile localFiles)
        {
            var bundlePackage = BundleFileFormData.Create(
                localFiles.Platform.ToBundleFilePlatform(),
                localFiles.Bundle.FullName,
                localFiles.Manifest.FullName
                );

            return await ApiClient.UploadBundle(item, bundlePackage, localFiles.UpdateProgress);
        }
    }
}
