﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Engage.AssetManagement.Content
{
    public class IfxAssetData : AssetData, IIfxAsset, IData<IIfxAsset>
    {
        [JsonConverter(typeof(EngageItemListConverter<IIfxOption, IfxOptionData>))]
        public List<IIfxOption> Options { get; set; } = new List<IIfxOption>();

        public IfxAssetData() { }
        public IfxAssetData(IIfxAsset asset)
        {
            SetValues(asset);
        }
        public IfxAssetData(string name)
        {
            Name = UnityResourceName = name;
        }

        public virtual void SetValues(IIfxAsset data)
        {
            SetValues(data as IAsset);

            Options.Clear();

            if (data.Options != null)
                Options.AddRange(data.Options);
        }
    }
}
