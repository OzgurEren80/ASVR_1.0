﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Engage.AssetManagement.Content
{
    public class GroupDataModule : NamedItemDataModule<IGroup, GroupData>
    {
        protected GroupClient ApiClient => EngageUser.ApiClient.Module<GroupClient>();

        protected override Func<Task<IList<IGroup>>> ClientGetListAsync
            => () => ApiClient.GetAsync();
        protected override Func<int, Task<IGroup>> ClientGetSingleAsync
            => (id) => ApiClient.GetAsync(id);
    }
}
