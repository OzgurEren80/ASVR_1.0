﻿namespace Engage.AssetManagement.Content
{
    public class IfxOptionData : IIfxOption, IData<IIfxOption>
    {
        public int? Id { get; set; }
        public string Name { get; set; }
        public Glossary PrettyName { get; set; }
        public string Value { get; set; }
        public string CreatedAt { get; set; }
        public string UpdatedAt { get; set; }

        public IfxOptionData() { }
        public IfxOptionData(string name, int? id = null)
        {
            Id = id;
            Name = name;
            PrettyName = (Glossary)name;
        }
        public IfxOptionData(IIfxOption ifxOption)
        {
            SetValues(ifxOption);
        }
        public void SetValues(IIfxOption data)
        {
            Id = data.Id;
            Name = data.Name;
            PrettyName = data.PrettyName;
            Value = data.Value;
            CreatedAt = data.CreatedAt;
            UpdatedAt = data.UpdatedAt;
        }
    }
}
