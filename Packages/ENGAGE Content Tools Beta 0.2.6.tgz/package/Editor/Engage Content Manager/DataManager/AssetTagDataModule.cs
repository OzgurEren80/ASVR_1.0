﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Engage.AssetManagement.Content
{
    public class AssetTagDataModule : EngageItemDataModule<IAssetTag, AssetTagData>
    {
        protected AssetTagClient ApiClient => EngageUser.ApiClient.Module<AssetTagClient>();

        protected override Func<Task<IList<IAssetTag>>> ClientGetListAsync
            => () => ApiClient.GetAsync();
        protected override Func<int, Task<IAssetTag>> ClientGetSingleAsync
            => (id) => ApiClient.GetAsync(id);
    }
}
