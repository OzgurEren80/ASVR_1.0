﻿namespace Engage.AssetManagement.Content
{
    public class AssetTagData : IAssetTag, IData<IAssetTag>
    {
        public int? Id { get; private set; }
        public Glossary Name { get; private set; }
        public string CreatedAt { get; private set; }
        public string UpdatedAt { get; private set; }

        public AssetTagData() { }
        public AssetTagData(string name, int? id = null)
        {
            Id = id;
            Name = (Glossary)name;
        }
        public AssetTagData(IAssetTag tag)
        {
            SetValues(tag);
        }

        public void SetValues(IAssetTag data)
        {
            Id = data.Id;
            Name = data.Name;
            CreatedAt = data.CreatedAt;
            UpdatedAt = data.UpdatedAt;
        }
    }
}
