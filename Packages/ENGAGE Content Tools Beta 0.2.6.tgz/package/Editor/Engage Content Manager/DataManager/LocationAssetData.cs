﻿namespace Engage.AssetManagement.Content
{
    public class LocationAssetData : AssetData, ILocationAsset, IData<ILocationAsset>
    {
        public int? BaseLocationId { get; set; }
        public int? BrandingGroupId { get; set; }

        public LocationAssetData() { }

        public LocationAssetData(ILocationAsset asset)
        {
            SetValues(asset);
        }

        public LocationAssetData(string name)
        {
            Name = UnityResourceName = name;
        }

        public virtual void SetValues(ILocationAsset data)
        {
            SetValues(data as IAsset);

            BaseLocationId = data.BaseLocationId;
            BrandingGroupId = data.BrandingGroupId;
        }
    }
}
