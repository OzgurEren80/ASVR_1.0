﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Engage.AssetManagement.Content
{
    public class IfxOptionDataModule : NamedItemDataModule<IIfxOption, IfxOptionData>
    {
        protected IfxOptionClient ApiClient => EngageUser.ApiClient.Module<IfxOptionClient>();

        protected override Func<Task<IList<IIfxOption>>> ClientGetListAsync
            => () => ApiClient.GetAsync();
        protected override Func<int, Task<IIfxOption>> ClientGetSingleAsync
            => (id) => ApiClient.GetAsync(id);
    }
}
