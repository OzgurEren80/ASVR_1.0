﻿using Engage.UI.Editor;
using UnityEditor;
using UnityEngine;

namespace Engage.AssetManagement.Content
{

    public class AuthenticationFailedDialog : EngageConfirmDialog<EngageUser>
    {
        public class Labels : Content.Labels
        {
            public const string AuthenticationFailed = "Authentication Failed";
            public const string AuthenticationFailedMessage = "These credentials do not match our records.";

            public const string EngageLoginLinkMessage = "To confirm your log-in credentials, go to:";
            public const string EngageLoginLink = "https://app.engagevr.io/login";
            public const string ContentManagerAccess = "To request authorization, please contact:";
            public const string EmailProtocol = "mailto:";
            public const string CustomerServiceLink = "upload-support@engagevr.io";

            public const string ForgotPassword = "Forgot Password";
            public const string ResetPasswordLink = "https://app.engagevr.io/password/reset";
        }

        protected const int heightExtent = 100;
        protected const int widthExtent = 150;

        public override void Draw()
        {
            EditorGUILayout.Space();

            using (var messagePanel = new EditorGUILayout.HorizontalScope(GUILayout.MinHeight(60)))
            {
                EditorGUILayout.LabelField(string.Empty, GUILayout.Width(20));
                using (var content = new EditorGUILayout.VerticalScope())
                {
                    EditorGUILayout.LabelField(Labels.AuthenticationFailedMessage, MessageStyle);
                    
                    EditorGUILayout.LabelField(string.Empty);

                    EditorGUILayout.LabelField(Labels.EngageLoginLinkMessage, MessageStyle);
                    if (EditorGUILayout.LinkButton(Labels.EngageLoginLink))
                    {
                        Application.OpenURL(Labels.EngageLoginLink);
                    }

                    EditorGUILayout.LabelField(string.Empty);

                    EditorGUILayout.LabelField(Labels.ContentManagerAccess, MessageStyle);
                    if (EditorGUILayout.LinkButton(Labels.CustomerServiceLink))
                    {
                        Application.OpenURL(Labels.EmailProtocol + Labels.CustomerServiceLink);
                    }
                }
                EditorGUILayout.LabelField(string.Empty, GUILayout.Width(20));
            }

            EditorGUILayout.LabelField(string.Empty, GUILayout.ExpandHeight(true));

            using (var selectionButtons = new EditorGUILayout.HorizontalScope())
            {
                GuiTools.DrawButton(LabelConfirm, ConfirmSelection);
            }
        }

        public static void OpenDialog()
        {
            var dialog = GetWindow<AuthenticationFailedDialog>(Labels.AuthenticationFailed);

            dialog.MessageBody = Labels.AuthenticationFailedMessage;

            dialog.LabelConfirm = Labels.Close;
            dialog.OnConfirm = dialog.Close;

            var extents = new Vector2(widthExtent, heightExtent);

            dialog.maxSize = dialog.minSize = extents * 2;

            dialog.ShowModalUtility();
        }
    }
}
