﻿using System.Linq;
using System.Threading.Tasks;
using UnityEditor;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    public class IfxBuilder : AssetBuilder<EngageIFX>
    {
        protected IfxAssetDataModule DataModule => DataManager.Module<IfxAssetDataModule>();

        public GameObject Prefab { get; protected set; }
        public override string UnityAssetName => Prefab?.name;

        public override void LoadEngageAsset(string guid)
        {
            // Finds saved local settings for this asset
            if (DataModule.TryGetLocal(guid, out IIfxAsset asset))
            {
                EngageAsset = new EngageIFX(asset);
            }
            else
            {
                EngageAsset = new EngageIFX();
            }

            LoadEngageAsset(EngageAsset);
        }

        public override void LoadUnityAsset(string guid)
        {
            if (string.IsNullOrEmpty(guid))
            {
                Status &= ~BuildStatus.UnityAssetSelected;
                Job = null;
                Message = $"No scene selected";
                Debug.LogWarning($"[Location Builder] {Message}");
                return;
            }

            var path = AssetDatabase.GUIDToAssetPath(guid);
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);

            LoadUnityPrefab(prefab);
        }

        public void LoadUnityPrefab(GameObject prefab)
        {
            Status &= ~BuildStatus.UnityAssetSelected;

            if (prefab == null)
            {
                Job = null;
                Message = $"Selected object is not a prefab";
                Debug.LogWarning($"[IFX Builder] {Message}");
                return;
            }

            Status |= BuildStatus.UnityAssetSelected;
            Message = $"Prefab {prefab.name} selected";

            Prefab = prefab;
            UpdateIfxOptions();
            LoadBuildJob(Prefab.GetGUID());
        }

        protected struct CollidersAvailable : IIfxOption
        {
            public int? Id => 22;
            public string Name => "colliders_available";
            public Glossary PrettyName => (Glossary)"Colliders Available";
            public string Value => null;
            public string CreatedAt => "2020-04-21T11:30:00Z";
            public string UpdatedAt => "2022-12-02T09:39:39Z";
        }

        protected void UpdateIfxOptions()
        {
            var collidersAvailable = new CollidersAvailable();

            if (Prefab.GetComponentInChildren<Collider>() != null)
            {
                if (!EngageAsset.Options.Any(option => option.Id == collidersAvailable.Id))
                {
                    EngageAsset.Options.Add(collidersAvailable);
                }
            }
            else
            {
                EngageAsset.Options.RemoveAll(option => option.Id == collidersAvailable.Id);
            }
        }
    }
}