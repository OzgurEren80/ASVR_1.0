﻿using UnityEditor;
using UnityEngine;
using System;

namespace Engage.AssetManagement.Content
{
    public class ConfirmUploadDialog : EngageConfirmDialog<EditorWindow>
    {
        protected const int heightExtent = 100;
        protected const int widthExtent = 150;

        public string Statement { get; set; }
        public string Guidelines { get; set; }
        public string GuidelinesUrl { get; set; }

        GUIStyle statementStyle;
        GUIStyle StatementStyle
        {
            get
            {
                if (statementStyle == null)
                {
                    statementStyle = new GUIStyle(MessageStyle);
                    statementStyle.fontStyle = FontStyle.Bold;
                }

                return statementStyle;
            }
            set
            {
                statementStyle = value;
            }
        }

        public static void OpenDialog(
            EditorWindow view,
            string title,
            string statement,
            string messageBody,
            string guidelines,
            string guidelinesUrl,
            Action confirmCallback = null,
            Action cancelCallback = null
            )
        {
            var dialog = GetWindow<ConfirmUploadDialog>(title);
            dialog.Statement = statement;
            dialog.MessageBody = messageBody;

            dialog.Guidelines = guidelines;
            dialog.GuidelinesUrl = guidelinesUrl;

            dialog.LabelConfirm = Labels.Upload;
            dialog.OnConfirm = confirmCallback;
            dialog.OnCancel = cancelCallback;

            var extents = new Vector2(widthExtent, heightExtent);

            dialog.position = new Rect(view.position.center - extents, extents * 2);

            dialog.ShowModalUtility();
        }

        public override Action<EditorWindow> DrawMessageBody
        {
            get => DrawMessage;
            set => base.DrawMessageBody = value;
        }

        public void DrawMessage(EditorWindow window)
        {
            using (var bodyArea = new EditorGUILayout.VerticalScope())
            {
                GUILayout.Space(10);

                using (var statementArea = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.HelpBox("", MessageType.Warning);
                    GUILayout.Space(20);
                    EditorGUILayout.LabelField(Statement, StatementStyle);
                }

                GUILayout.Space(20);
                EditorGUILayout.LabelField(MessageBody, MessageStyle);

                GUILayout.Space(20);
                if (EditorGUILayout.LinkButton(Guidelines))
                {
                    Application.OpenURL(GuidelinesUrl);
                }
            }
        }
    }
}