﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using UnityEditor;
using UnityEngine;
using UnityEngine.Networking;

namespace Engage.AssetManagement.Content
{
    public enum ThumbnailStatus
    {
        None = 0,
        Loading,
        Error,
        Loaded
    }

    public class Thumbnail
    {
        private Texture2D image;

        public string Path { get; }
        public ThumbnailStatus Status { get; private set; }

        public static readonly string[] validFileExtensions = new string[] { ".jpg", ".png", ".jpeg" };

        public static readonly string[] imageTypes = new string[] { "Image", "jpg,jpeg,png", "JPEG", "jpg,jpeg", "Portable Network Graphic", "png" };

        public Texture2D Image
        {
            get
            {
                if (image == null && Status == ThumbnailStatus.Loaded)
                {
                    Load();
                }

                return image;
            }
            private set => image = value;
        }

        public Action OnLoadComplete { get; set; }

        public Thumbnail(string path)
        {
            Path = path;
        }

        public void Load()
        {
            Status = ThumbnailStatus.None;

            if (string.IsNullOrEmpty(Path))
            {
                return;
            }

            if (File.Exists(Path))
            {
                try
                {
                    var bytes = File.ReadAllBytes(Path);

                    Image = new Texture2D(2, 2);
                    Image.LoadImage(bytes, true);

                    Status = ThumbnailStatus.Loaded;
                }
                catch
                {
                    Status = ThumbnailStatus.Error;
                }

                OnLoadComplete?.Invoke();
            }
            else if (Status == ThumbnailStatus.None)
            {
                Fetch();
            }
        }

        public static Texture2D Load(string path)
        {
            if (string.IsNullOrEmpty(path))
            {
                return null;
            }

            if (File.Exists(path))
            {
                try
                {
                    var bytes = File.ReadAllBytes(path);

                    var image = new Texture2D(2, 2);
                    image.LoadImage(bytes, true);
                    return image;
                }
                catch
                {
                    //TODO: Error message file not existing.
                }
            }

            return null;
        }

        protected async void Fetch()
        {
            if (Status > ThumbnailStatus.None)
            {
                return;
            }

            Status = ThumbnailStatus.Loading;

            try
            {
                using (var cancellationTokenSource = new CancellationTokenSource(TimeSpan.FromSeconds(30)))
                {
                    var texture = await UnityWebRequestAsync.RequestTextureAsync(Path, true, cancellationTokenSource.Token);

                    if (texture == null)
                    {
                        Status = ThumbnailStatus.Error;
                    }
                    else
                    {
                        Status = ThumbnailStatus.Loaded;
                    }

                    Image = texture;
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Thumbnail Cache] There was an exception attempting to download image at {Path}: {ex}");
                Status = ThumbnailStatus.Error;
            }

            OnLoadComplete?.Invoke();
        }
    }

    public static class ThumbnailCache
    {
        private static Dictionary<string, Thumbnail> index = new Dictionary<string, Thumbnail>();
        public static Action OnCacheUpdate { get; set; }

        private static void CacheUpdated()
        {
            OnCacheUpdate?.Invoke();
        }

        public static bool Add(string path)
        {
            if (index.ContainsKey(path))
                return false;

            Debug.Log("[Thumbnail Cache] Adding " + path);

            var thumbnail = new Thumbnail(path);
            thumbnail.OnLoadComplete += CacheUpdated;
            index.Add(path, thumbnail);

            return true;
        }

        public static Thumbnail Get(string path)
        {
            if (string.IsNullOrEmpty(path))
                return null;

            if (!index.TryGetValue(path, out Thumbnail thumbnail))
            {
                Debug.Log("[Thumbnail Cache] Adding " + path);

                thumbnail = new Thumbnail(path);
                thumbnail.OnLoadComplete += CacheUpdated;
                index.Add(path, thumbnail);

                thumbnail.Load();
            }

            return thumbnail;
        }

        public static void Clear()
        {
            index.Clear();
        }
    }
}