﻿using Engage.CreatorSDK;
using Engage.Network;
using Engage.UI.Editor;
using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    public class LocationManagerView : View<LocationManager>
    {
        public class Labels : Content.Labels
        {
            public const string MenuTitle = "Manage Locations";
            public const string ViewTitle = " Location Manager";
        }

        [MenuItem(MenuLabels.EngageAssetManagementPath + Labels.MenuTitle, priority = MenuLabels.ManagerViewPriority + 1)]
        public static void OpenView() => GetWindow<LocationManagerView>().Open();

        protected string search;
        protected Texture logo;
        private const int imageScaleUnit = 25;

        public Texture Logo
        {
            get
            {
                if (logo == null)
                {
                    logo = AssetDatabase.LoadAssetAtPath<Texture>(Icons.EngageLogoB);
                }

                return logo;
            }
        }

        private class LocationDisplaySet
        {
            private readonly HashSet<EngageLocation> displaySet = new HashSet<EngageLocation>();

            public bool this[EngageLocation location]
            {
                get => displaySet.Contains(location);
                set
                {
                    if (value)
                    {
                        if (displaySet.Add(location))
                        {
                            location.Refresh();
                        }
                    }
                    else
                    {
                        displaySet.Remove(location);
                    }
                }
            }
        }

        private CollectionPresenter<EngageLocation> sortState = new CollectionPresenter<EngageLocation>();

        private Action SortAction(SortOption sortOption, Comparison<EngageLocation> comparer)
        {
            return () =>
            {
                if (sortState.currentSortOption != sortOption)
                {
                    sortState.currentSortOption = sortOption;
                    sortState.currentSortDirection = SortDirection.None;
                }

                sortState.currentSort = comparer;
                sortState.Sort(ViewModel.ItemDisplayList);
            };
        }

        private void ReSort()
        {
            sortState.Sort(ViewModel.ItemDisplayList, true);
        }

        protected override void OnEnable()
        {
            base.OnEnable();

            titleContent = new GUIContent(Labels.ViewTitle, Logo);
            ViewModel.OnRefreshDisplay += ReSort;
            ThumbnailCache.OnCacheUpdate += ThumbnailCacheUpdated;
        }

        protected override void OnDisable()
        {
            base.OnDisable();

            ViewModel.OnRefreshDisplay -= ReSort;
            ThumbnailCache.OnCacheUpdate -= ThumbnailCacheUpdated;
        }

        public override void Draw()
        {
            using (var updatingArea = new GuiTools.EnabledScope(ViewModel.RefreshStatus != RequestStatus.Requesting))
            {
                Login.DrawLoginHeader(this);

                EditorGUILayout.Space();

                GuiTools.DrawSearchBar(ref search);

                GUILayout.Space(20);

                DrawLocationPanel();

                EditorGUILayout.Space();
            }

            EditorGUILayout.Space();

            ViewTools.DrawFooter();
        }

        private void ConfirmDeleteLocation(EngageLocation location)
        {
            if (EditorUtility.DisplayDialog(
                    title: "Confirm Delete Location",
                    message: $"Permanently delete {location.PrettyName} from {(location.Id.HasValue ? "your ENGAGE locations" : "the local cache")}?",
                    ok: Labels.Delete,
                    cancel: Labels.Cancel
                ))
            {
                ViewModel.DeleteLocation(location);
            }
        }

        private void DrawLocationPanel()
        {
            using (var locationPanelContentFrame = new EditorGUILayout.VerticalScope())
            {
                using (var locationListColumnHeaders = new EditorGUILayout.HorizontalScope())
                {
                    using (var enabled = new GuiTools.EnabledScope(ViewModel.ItemDisplayList?.Count > 0))
                    {
                        GUILayout.Space(imageScaleUnit * 3 + 12);
                        GuiTools.DrawHeader($"{Labels.Name}{sortState.GetSymbol(SortOption.PrettyName)}", SortAction(SortOption.PrettyName, (a, b) => a.PrettyName.ToString().CompareTo(b.PrettyName)), GUILayout.Width(CreatorStyle.PRETTYNAME_WIDTH));
                        GuiTools.DrawHeader($"{Labels.Description}{sortState.GetSymbol(SortOption.Description)}", SortAction(SortOption.Description, (a, b) => a.Description.ToString().CompareTo(b.Description)), GUILayout.Width(CreatorStyle.PRETTYNAME_WIDTH));
                        GuiTools.DrawHeader($"{Labels.Updated}{sortState.GetSymbol(SortOption.LastUpdated)}", SortAction(SortOption.LastUpdated, (a, b) => a.UpdatedAt.CompareTo(b.UpdatedAt)), GUILayout.Width(CreatorStyle.DATE_WIDTH));
                    }
                }

                using (var scrollArea = new GuiTools.ScrollArea(ref scrollPos, EditorStyles.helpBox))
                {
                    DrawEngageLocationListView();
                }

                if (GUI.Button(new Rect(locationPanelContentFrame.rect.width - 84, locationPanelContentFrame.rect.y - 15, 40, 30), Icons.Plus.Tooltip("Create a new Location")))
                {
                    LocationBuilderView.OpenView();
                }

                if (GUI.Button(new Rect(locationPanelContentFrame.rect.width - 40, locationPanelContentFrame.rect.y - 15, 40, 30), Icons.Refresh.Tooltip(Labels.RefreshFromServer)))
                {
                    ThumbnailCache.Clear();
                    ViewModel.RefreshFromServer();
                }
            }
        }

        private void DrawEngageLocationListView()
        {
            using (var locationListPanel = new EditorGUILayout.VerticalScope())
            {
                bool even = true;

                foreach (var location in ViewModel.ItemDisplayList.ToArray())
                {
                    if (string.IsNullOrEmpty(search) || location.ToString().IndexOf(search, StringComparison.InvariantCultureIgnoreCase) > -1)
                    {
                        DrawEngageLocationRow(location, even ? CreatorStyle.RowStyleEven : CreatorStyle.RowStyleOdd);
                        even = !even;
                    }
                }
            }
        }

        private Color GetSyncStateColorCoding(EngageLocation location)
        {
            if (!location.Id.HasValue)
            {
                return CreatorStyle.Yellow;
            }

            return GUI.color;
        }

        private void DrawEngageLocationRow(EngageLocation location, GUIStyle style)
        {
            using (var engageBundleRow = new EditorGUILayout.HorizontalScope(style, GUILayout.ExpandWidth(false)))
            {
                // thumbnail
                GUILayout.Box(GetThumbnail(location), GUILayout.Width(imageScaleUnit * 3), GUILayout.Height(imageScaleUnit * 2));

                using (var localScope = new GuiTools.ColorScope(color: GetSyncStateColorCoding(location)))
                {
                    // Pretty Name
                    EditorGUILayout.LabelField(location.PrettyName, GUILayout.Width(CreatorStyle.PRETTYNAME_WIDTH));

                    // Description
                    EditorGUILayout.LabelField(location.Description, GUILayout.Width(CreatorStyle.PRETTYNAME_WIDTH));

                    // Timestamps
                    //EditorGUILayout.LabelField($"{bundle.CreatedAt}", GUILayout.Width(CreatorStyle.DATE_WIDTH));
                    EditorGUILayout.LabelField($"{location.UpdatedAt}", GUILayout.Width(CreatorStyle.DATE_WIDTH));

                    // Edit Button
                    GuiTools.DrawButton(Labels.Edit, () => LocationBuilderView.Edit(location), GUILayout.Width(CreatorStyle.SHORT_BUTTON_WIDTH));

                    // Delete Button
                    GuiTools.DrawButton(Labels.Delete, () => ConfirmDeleteLocation(location), GUILayout.Width(CreatorStyle.SHORT_BUTTON_WIDTH));
                }
            }
        }

        private GUIContent GetThumbnail(EngageLocation location)
        {
            if (string.IsNullOrEmpty(location.Image))
            {
                return Icons.Image;
            }

            if (string.IsNullOrEmpty(location.LocalThumbnailPath))
            {
                location.LocalThumbnailPath = location.Image;
            }

            if (BundleBuilder.IsBuildInProgress)
            {
                return Icons.GetWaitSpinner(ShowSpinner());
            }

            var thumbnail = ThumbnailCache.Get(location.LocalThumbnailPath);

            if (thumbnail.Status == ThumbnailStatus.Loading)
            {
                return Icons.GetWaitSpinner(ShowSpinner());
            }
            
            if (thumbnail.Status == ThumbnailStatus.Error)
            {
                return Icons.Error;
            }

            return new GUIContent(thumbnail.Image);
        }

        private void ThumbnailCacheUpdated()
        {
            UpdateView();
        }
    }
}