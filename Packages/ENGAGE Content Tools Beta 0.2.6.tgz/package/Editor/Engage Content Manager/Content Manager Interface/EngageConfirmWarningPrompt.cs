﻿using Engage.UI.Editor;
using UnityEditor;
using UnityEngine;
using System;

namespace Engage.AssetManagement.Content
{
    public class EngageConfirmWarningPrompt<T> : EditorWindow
    {
        protected T Target { get; private set; }
        protected Vector2 scrollPos;
        protected bool confirmed;
        protected bool cancelled;

        public virtual Action OnConfirm { get; protected set; }

        public virtual string LabelCancel { get; protected set; } = Labels.Cancel;
        public virtual string LabelConfirm { get; protected set; } = Labels.OK;
        public virtual string MessageBody { get; set; }

        protected GUIStyle messageStyle;
        protected GUIStyle MessageStyle
        {
            get
            {
                if (messageStyle == null)
                {
                    messageStyle = new GUIStyle(EditorStyles.label)
                    {
                        wordWrap = true
                    };
                }

                return messageStyle;
            }
        }

        protected Action<T> drawMessageBody;
        public virtual Action<T> DrawMessageBody
        {
            get
            {
                if (drawMessageBody == null)
                {
                    drawMessageBody = (T) => EditorGUILayout.LabelField(MessageBody, MessageStyle);
                }

                return drawMessageBody;
            }
            set
            {
                drawMessageBody = value;
            }
        }


        private void OnGUI()
        {
            Draw();
        }

        public virtual void Draw()
        {
            EditorGUILayout.Space();

            using (var messagePanel = new EditorGUILayout.HorizontalScope(GUILayout.MinHeight(60)))
            {
                EditorGUILayout.LabelField(string.Empty, GUILayout.Width(20));
                DrawMessageBody(Target);
                EditorGUILayout.LabelField(string.Empty, GUILayout.Width(20));
            }

            EditorGUILayout.LabelField(string.Empty, GUILayout.ExpandHeight(true));

            using (var selectionButtons = new EditorGUILayout.HorizontalScope())
            {
                GuiTools.DrawButton(LabelConfirm, ConfirmSelection);
            }
        }

        protected void ConfirmSelection()
        {
            confirmed = true;
            OnConfirm?.Invoke();
            Close();
        }

    }
}