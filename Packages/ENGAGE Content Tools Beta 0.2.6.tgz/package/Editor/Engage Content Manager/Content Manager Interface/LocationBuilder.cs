using UnityEditor;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    public class LocationBuilder : AssetBuilder<EngageLocation>
    {
        protected LocationAssetDataModule DataModule => DataManager.Module<LocationAssetDataModule>();

        public int? BrandingGroupId { get => EngageAsset.BrandingGroupId; set => EngageAsset.BrandingGroupId = value; }
        public IGroup BrandingGroup { get => EngageAsset.BrandingGroup; set => EngageAsset.BrandingGroup = value; }
        public void SetBrandingGroup(IGroup group) => EngageAsset.SetBrandingGroup(group);

        public SceneAsset Scene { get; protected set; }
        public override string UnityAssetName => Scene?.name;

        public override void LoadEngageAsset(string guid)
        {
            // Finds saved local settings for this asset
            if (DataModule.TryGetLocal(guid, out ILocationAsset asset))
            {
                EngageAsset = new EngageLocation(asset);
            }
            else
            {
                EngageAsset = new EngageLocation();
            }

            LoadEngageAsset(EngageAsset);
        }

        public override void LoadUnityAsset(string guid)
        {
            if (string.IsNullOrEmpty(guid))
            {
                Status &= ~BuildStatus.UnityAssetSelected;
                Job = null;
                Message = $"No scene selected";
                Debug.LogWarning($"[Location Builder] {Message}");
                return;
            }

            var path = AssetDatabase.GUIDToAssetPath(guid);
            var scene = AssetDatabase.LoadAssetAtPath<SceneAsset>(path);

            LoadUnityScene(scene);
        }

        public void LoadUnityScene(SceneAsset scene)
        {
            Status &= ~BuildStatus.UnityAssetSelected;

            if (scene == null)
            {
                Job = null;
                Message = $"Selected object is not a scene";
                Debug.LogWarning($"[Location Builder] {Message}");
                return;
            }

            Message = $"Scene {scene.name} selected";

            Status |= BuildStatus.UnityAssetSelected;

            Scene = scene;

            LoadBuildJob(Scene.GetGUID());
        }
    }
}