﻿using Engage.Network;
using Engage.UI.Editor;
using System;
using System.Collections.Generic;

namespace Engage.AssetManagement.Content
{
    public class LocationManager : EngageItemManager<ILocationAsset, EngageLocation, LocationAssetDataModule>
    {
        protected override LocationAssetDataModule DataModule => DataManager.Module<LocationAssetDataModule>();
        protected override IList<ILocationAsset> Cache => DataModule.Get();

        // NOTE: shortens time for view render on first load
        protected bool preloadedInventory = false;

        protected override EngageLocation Create(ILocationAsset location)
        {
            var item = location as EngageLocation;

            if (item == null)
            {
                item = new EngageLocation(location);
            }

            item.AddListener(this, OnLocationUpdated);
            return item;
        }

        protected override EngageLocation Create(string name)
        {
            var item = new EngageLocation();
            item.Name = name;
            item.AddListener(this, OnLocationUpdated);

            return item;
        }

        protected override void Initialize()
        {
            base.Initialize();

            EngageUser.AddAuthenticationStateListener(OnAuthenticationChanged);
            OnAuthenticationChanged(EngageUser.AuthenticationState);
            preloadedInventory = true;
        }

        public override void Dispose()
        {
            EngageUser.RemoveAuthenticationStateListener(OnAuthenticationChanged);
            base.Dispose();
        }

        protected async void OnAuthenticationChanged(AuthenticationState authenticationState)
        {
            if (authenticationState == AuthenticationState.Authenticated)
            {
                await DataModule.RefreshAsync();
                RebuildInventory(await DataModule.GetAsync());
            }
        }

        protected override void RebuildInventory(IList<ILocationAsset> locations)
        {
            if (preloadedInventory)
            {
                preloadedInventory = false;
                return;
            }

            itemInventory.Clear();

            foreach (ILocationAsset location in locations)
            {
                itemInventory.Add(Create(location));
            }

            RefreshUploadHistory();
            RefreshDisplay();
        }

        protected override Predicate<EngageLocation> DisplayItem => (bundle) => bundle.Id.HasValue ? true : bundle.UnityResourceName == EngageUser.CurrentProjectName;

        public void RefreshUploadHistory()
        {
            EngageUser.RefreshUploadHistory();
            NotifyPropertyChange(nameof(RefreshUploadHistory));
        }

        public void ClearBundleUploadHistory()
        {
            EngageUser.ClearUploadHistory();
            NotifyPropertyChange(nameof(ClearBundleUploadHistory));
        }

        protected void OnLocationUpdated(ViewModel viewModel, string property)
        {
            NotifyPropertyChange(property);
        }

        internal async void DeleteLocation(EngageLocation location)
        {
            if (await location.DeleteAsset())
            {
                itemInventory.Remove(location);
            }

            RefreshDisplay();
        }

        public async override void RefreshFromServer()
        {
            await DataModule.RefreshAsync();

            Refresh();
        }
    }
}