﻿using Engage.CreatorSDK;
using Engage.UI.Editor;
using System;
using UnityEditor;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    public abstract class BuildStatusPanel<T>
    {
        public abstract void NextState();

        protected Action DrawSaveButton;
        protected Action DrawStartButton;

        protected virtual bool SaveButtonEnabled => true;
        protected virtual bool StartButtonEnabled => true;

        protected abstract string TitleLabel { get; }
        protected abstract string AssetSelectedLabel { get; }
        protected string AssetLabel { get; set; }
        protected string StateLabel { get; set; }

        protected T Parent { get; }
        public BuildStatusPanel(T parent)
        {
            Parent = parent;
        }
        public virtual void Update() { }

        public virtual void Draw()
        {
            DrawHeader();

            using (var buildOptions = new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                DrawBody();
            }

            EditorGUILayout.LabelField("", GUILayout.ExpandHeight(true));

            DrawButtons();
        }

        public virtual void DrawHeader()
        {
            using (var statusPanel = new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField(TitleLabel, EditorStyles.boldLabel);
                //EditorGUILayout.LabelField(StateLabel);
            }
        }

        public virtual void DrawBody()
        {
            DrawStatusRow("", AssetSelectedLabel);
            DrawStatusRow("", AssetLabel);
            DrawStatusRow("", Labels.ThumbnailUploaded);
            DrawStatusRow("", Labels.Bundles);
        }
        public virtual void DrawButtons()
        {
            using (var buttons = new EditorGUILayout.HorizontalScope())
            {
                using (var saveDisabled = new GuiTools.EnabledScope(SaveButtonEnabled))
                {
                    DrawSaveButton();
                }
                using (var startDisabled = new GuiTools.EnabledScope(StartButtonEnabled))
                {
                    DrawStartButton();
                }
            }
        }

        protected virtual void DrawStatusRow(string status, string label)
        {
            DrawStatusRow(new GUIContent(status), new GUIContent(label));
        }

        protected virtual void DrawStatusRow(GUIContent status, string label)
        {
            DrawStatusRow(status, new GUIContent(label));
        }

        protected virtual void DrawStatusRow(GUIContent status, GUIContent label)
        {
            using (var opPanel = new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField(string.Empty, GUILayout.Width(leftPadding));
                EditorGUILayout.LabelField(status, GUILayout.Width(statusWidth));
                EditorGUILayout.LabelField(label);
            }
        }

        protected const int rightPadding = 2;
        protected const int leftPadding = 10;
        protected const int statusWidth = 30;
        protected const int column1 = leftPadding + statusWidth;
        protected const int column2 = 40;
        protected const int column3 = 40;
        protected const int processLabelWidth = 100;
        protected const int progressBarOffset = column1 + column2 + column3 + 90;
        protected const int retryButtonWidth = 60;
        protected const int reUploadButtonWidth = 90;

        public virtual void DrawPlatformStatus(EngagePlatform platform)
        {
            var icon = ViewTools.PlatformIcons[platform];
            var installed = BundleBuilder.IsModuleInstalled(platform);

            var status = Icons.TestPassed;

            if (!installed)
            {
                status = Icons.Error.Tooltip(Labels.BuildModuleNotInstalledMessage);
            }

            using (var platformPanel = new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField("", GUILayout.Width(column1));
                EditorGUILayout.LabelField(status, GUILayout.Width(column2));
                EditorGUILayout.LabelField(icon, GUILayout.Width(column3));

                string processLabel = installed ? "" : Labels.BuildModuleNotInstalledMessage;

                EditorGUILayout.LabelField(processLabel, GUILayout.Width(processLabelWidth));
            }
        }

        protected bool DrawBundleStatus(bool assetSelected, bool bundlesAvailable, bool reUpload)
        {
            using (var prefabSelected = new GuiTools.EnabledScope(assetSelected || bundlesAvailable))
            {
                using (var opPanel = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(string.Empty, GUILayout.Width(leftPadding));
                    EditorGUILayout.LabelField("", GUILayout.Width(statusWidth));
                    EditorGUILayout.LabelField(Labels.Bundles);

                    if (!bundlesAvailable)
                        return false;

                    var reUploadRect = new Rect(
                        Mathf.Max(
                            opPanel.rect.x + opPanel.rect.width - (reUploadButtonWidth + rightPadding),
                            reUploadButtonWidth + rightPadding
                            ),
                        opPanel.rect.y,
                        reUploadButtonWidth,
                        EditorGUIUtility.singleLineHeight
                        );

                    return GUI.Toggle(reUploadRect, reUpload, Labels.ReUpload, "Button");
                }
            }
        }
    }
}