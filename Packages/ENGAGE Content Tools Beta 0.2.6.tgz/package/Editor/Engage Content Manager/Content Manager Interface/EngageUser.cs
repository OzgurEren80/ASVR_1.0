﻿using System.IO;
using System.Threading.Tasks;
using UnityEditor;
using Engage.Network;
using Engage.CreatorSDK;
using System;
using System.Collections.Generic;

namespace Engage.AssetManagement.Content
{
    public class EngageUser
    {
        private static class Keys
        {
            public const string rememberCredentialsKey = "RememberUserCredentials";

            public const string currentLocalAssetPathKey = "CurrentBuildPath";
            public const string currentAssetPlatform = "CurrentBuildTargets";

            public const string defaultIfxAssetKey = "DefaultIfxSettings";
            public const string defaultLocationAssetKey = "DefaultLocationSettings";
        }

        public enum AccountLockType { Password, ValidationCode, RecoveryCode }

        public struct AccountLock
        {
            public AccountLockType Type { get; }
            public DateTime Start { get; }
            public int Duration { get; }

            public AccountLock(AccountLockType type, int duration)
            {
                Type = type;
                Start = DateTime.Now;
                Duration = duration;
            }
        }

        private const string defaultLocalAssetPath = "AssetBundles";

        private static EngageUser instance;
        internal static EngageUser Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new EngageUser();
                }

                return instance;
            }
        }

        public static string GetUserKey(string key) => $"{ApiClient.Host.Environment}_{key}";
        public static string CurrentProjectName => new DirectoryInfo(Directory.GetCurrentDirectory()).Name;

        internal static string RememberCredentialsKey => GetUserKey(Keys.rememberCredentialsKey);

        private ApiClient apiClient;
        public static ApiClient ApiClient
        {
            get
            {
                if (Instance.apiClient == null)
                {
                    Instance.apiClient = ApiClient.CreateApiClient<ApiClientAuthentication>();
                }

                return Instance.apiClient;
            }
        }

        protected static ApiClientAuthentication Authentication => ApiClient.Module<ApiClientAuthentication>();
        protected static IUser CurrentUser => Authentication.CurrentUser;

        #region Authentication
        public static UserLoginType CurrentLoginType { get; set; }

        private UserLoginTypes loginTypes;
        public static UserLoginTypes LoginTypes => Instance.loginTypes;

        public static bool RequiresSso => LoginTypes?.RequiresSso ?? false;
        public static bool RequiresPassword => LoginTypes?.RequiresPassword ?? false;
        public static bool Requires2FASetup => LoginTypes?.Requires2FASetup ?? false;
        public static bool Requires2FA => LoginTypes?.Requires2FA ?? false;

        public static bool Awaiting2FAValidation
        {
            get
            {
                return Requires2FA
                    && LastLoginRequestResponse.CredentialsAccepted
                    && LastLoginRequestResponse.Type == LoginResponseType.Awaiting2FACode;
            }
        }

        public static bool ValidationCodeInvalid { get; private set; }
        public static bool RecoveryCodeInvalid { get; private set; }

        public static string UserName
        {
            get => CurrentUser.Name;
            set => CurrentUser.Name = value;
        }
        public static string Password { get; set; }
        public static int? ValidationCode { get; set; }

        private bool? rememberCredentials;
        private bool unmaskPassword;
        private HashSet<Action<AuthenticationState>> authenticationListeners = new HashSet<Action<AuthenticationState>>();

        private LoginResponse lastLoginRequestResponse = LoginResponse.None();
        public static LoginResponse LastLoginRequestResponse => Instance.lastLoginRequestResponse;

        private string validationCodeFormat;

        private Dictionary<AccountLockType, AccountLock> AccountLocks { get; } = new();

        public static string ValidationCodeFormat => Instance.validationCodeFormat;
        public static bool AccountLocked(AccountLockType lockType)
        {
            return Instance.AccountLocks.ContainsKey(lockType);
        }
        public static int LockoutTimeRemaining(AccountLockType lockType)
        {
            if (!Instance.AccountLocks.TryGetValue(lockType, out AccountLock lockout))
            {
                return 0;
            }

            float elapsedTime = (float)(DateTime.Now - lockout.Start).TotalMinutes;
            int remainder = UnityEngine.Mathf.RoundToInt(lockout.Duration - elapsedTime);

            if (remainder <= 0)
            {
                Instance.ClearAccountLock(lockType);
            }

            return remainder;
        }

        public static bool IsRemembered => !string.IsNullOrEmpty(CurrentUser?.UserToken);
        public static bool IsAuthenticated => AuthenticationState == AuthenticationState.Authenticated;
        public static AuthenticationState AuthenticationState => Authentication.AuthenticationStatus;

        private void StartAccountLock(AccountLockType lockType, int duration)
        {
            AccountLocks.Remove(lockType);
            AccountLocks.Add(lockType, new AccountLock(lockType, duration));
        }

        private void ClearAccountLock(AccountLockType lockType)
        {
            AccountLocks.Remove(lockType);
        }

        public static void ClearAuthenticationFields()
        {
            UserName = string.Empty;
            Password = string.Empty;
            ValidationCode = null;
            UnmaskPassword = false;
            ValidationCodeInvalid = false;
            RecoveryCodeInvalid = false;
        }

        public static void ResetAuthentication()
        {
            ClearAuthenticationFields();
            Instance.lastLoginRequestResponse = LoginResponse.None();
        }

        public static void AddAuthenticationStateListener(Action<AuthenticationState> listener)
        {
            if (Instance.authenticationListeners.Add(listener))
            {
                Authentication.OnAuthenticationStateChanged += listener;
            }
        }

        public static void RemoveAuthenticationStateListener(Action<AuthenticationState> listener)
        {
            if (Instance.authenticationListeners.Remove(listener))
            {
                Authentication.OnAuthenticationStateChanged -= listener;
            }
        }

        public static bool RememberCredentials
        {
            get
            {
                if (!Instance.rememberCredentials.HasValue)
                {
                    Instance.rememberCredentials = EditorPrefs.GetBool(RememberCredentialsKey, false);
                }

                return Instance.rememberCredentials.Value;
            }
            set
            {
                if (Instance.rememberCredentials.HasValue)
                {
                    if (Instance.rememberCredentials != value)
                    {
                        Instance.rememberCredentials = value;
                        EditorPrefs.SetBool(RememberCredentialsKey, Instance.rememberCredentials.Value);
                    }
                }
            }
        }

        public static bool UnmaskPassword { get => Instance.unmaskPassword; set => Instance.unmaskPassword = value; }

        public static async Task RequestLoginTypes()
        {
            Instance.loginTypes = await Authentication.RequestLoginTypes(UserName);
        }

        public static async Task<bool> RequestLogin()
        {
            Instance.loginTypes = await Authentication.RequestLoginTypes(UserName);

            if (CurrentLoginType == UserLoginType.SSO)
            {
                if (RequiresPassword) return false;

                Instance.lastLoginRequestResponse = await Authentication.RequestSSOLogin(CurrentUser, LoginTypes.Credentials);
            }
            else
            {
                if (RequiresSso) return false;

                Instance.lastLoginRequestResponse = await Authentication.RequestLogin(CurrentUser, Password);
            }

            if (Instance.lastLoginRequestResponse.Type == LoginResponseType.AccountTempLocked)
            {
                Instance.StartAccountLock(AccountLockType.Password, LastLoginRequestResponse.Details.TimeLeft);
            }

            if (LastLoginRequestResponse.CredentialsAccepted)
            {
                if (!string.IsNullOrEmpty(Instance.lastLoginRequestResponse.Details.Code))
                {
                    try
                    {
                        string[] codeDetails = LastLoginRequestResponse.Details.Code.Split('.');
                        Instance.validationCodeFormat = codeDetails[1].ToUpper();
                    }
                    catch (Exception ex)
                    {
                        UnityEngine.Debug.LogError($"[2FA Authentication] Code parse error ({LastLoginRequestResponse.Details.Code}) - {ex}");
                    }
                }

                if (RememberCredentials)
                {
                    Authentication.SaveCredentials();
                }
                else
                {
                    Authentication.ForgetCredentials();
                }

                ClearAuthenticationFields();
            }

            return LastLoginRequestResponse.CredentialsAccepted;
        }

        public static async Task<bool> RequestLogout()
        {
            bool success = await Authentication.RequestLogout();

            if (success)
            {
                Authentication.ClearCredentials();
            }

            ResetAuthentication();
            return success;
        }

        public static async Task<bool> Submit2FACode(int code)
        {
            var response = await Authentication.Request2FAVerification(code, ValidationCodeFormat);

            if (response.Type == LoginResponseType.Success)
            {
                ClearAuthenticationFields();
                Instance.lastLoginRequestResponse = response;
                return true;
            }

            if (response.Type == LoginResponseType.AccountTempLocked)
            {
                Instance.StartAccountLock(AccountLockType.ValidationCode, response.Details.TimeLeft);
            }

            ValidationCodeInvalid = true;
            return false;
        }

        public static async Task<bool> Submit2FARecoveryCode(string code)
        {
            var response = await Authentication.Request2FARecovery(code);

            if (response.Type == LoginResponseType.Success)
            {
                ClearAuthenticationFields();
                Instance.lastLoginRequestResponse = response;
                return true;
            }

            if (response.Type == LoginResponseType.AccountTempLocked)
            {
                Instance.StartAccountLock(AccountLockType.RecoveryCode, response.Details.TimeLeft);
            }

            RecoveryCodeInvalid = true;
            return false;
        }

        public static void ResendSMSCode()
        {
            Authentication.RequestResend2FASMSCode();
        }
        #endregion


        private ILocationAsset defaultLocationAssetSettings;
        public static ILocationAsset DefaultLocationAssetSettings
        {
            get
            {
                //if (Instance.defaultSceneAssetSettings == null)
                //{
                //    var settings = EditorPrefs.GetString(GetUserKey(Keys.defaultSceneAssetKey));

                //    if (string.IsNullOrEmpty(settings))
                //    {
                //        Instance.defaultSceneAssetSettings = new SceneAssetData("DefaultLocationSettings");
                //    }
                //    else
                //    {
                //        try
                //        {
                //            Instance.defaultSceneAssetSettings = JsonConvert.DeserializeObject<SceneAsset>(settings);
                //        }
                //        catch (Exception ex)
                //        {
                //            Debug.LogError("[Environment Settings] Default Scene Settings could not be deserialized: " + ex);

                //            Instance.defaultSceneAssetSettings = new SceneAssetData("DefaultLocationSettings");
                //        }
                //    }
                //}

                return Instance.defaultLocationAssetSettings;
            }
            set
            {
                //try
                //{
                //    var settings = JsonConvert.SerializeObject(value);
                //    EditorPrefs.SetString(GetUserKey(Keys.defaultSceneAssetKey), settings);
                //}
                //catch (Exception ex)
                //{
                //    Debug.LogError("[Environment Settings] Default Scene Settings could not be serialized: " + ex);
                //}

                Instance.defaultLocationAssetSettings = value;
            }
        }

        public static string GetLocalAssetPath(BuildTarget assetPlatform) => Path.Combine(BuildSettings.LocalBuildPath, assetPlatform.ToEngagePlatform().ToString());

        private UploadRegistry uploadedBundles;
        public static UploadRegistry UploadedBundles
        {
            get
            {
                if (Instance.uploadedBundles == null)
                {
                    Instance.uploadedBundles = UploadRegistry.GetUploadHistory();
                }

                return Instance.uploadedBundles;
            }
        }

        public static void RegisterUpload(BundleFile bundle) => UploadedBundles.RegisterUpload(bundle);
        public static void RefreshUploadHistory() => Instance.uploadedBundles = null;
        public static void ClearUploadHistory(BundleFile bundle) => UploadedBundles.ClearUploadHistory(bundle);
        public static void ClearUploadHistory() => UploadedBundles.ClearUploadHistory();
        public static bool WasUploaded(BundleFile bundle) => UploadedBundles.ContainsKey(bundle?.CRC);
    }
}