﻿using Engage.Network;
using Engage.UI.Editor;
using System;
using System.Collections.Generic;

namespace Engage.AssetManagement.Content
{
    public class IfxManager : EngageItemManager<IIfxAsset, EngageIFX, IfxAssetDataModule>
    {
        protected override IfxAssetDataModule DataModule => DataManager.Module<IfxAssetDataModule>();
        protected override IList<IIfxAsset> Cache => DataModule.Get();

        // used to shorten time before view can be rendered on first load
        protected bool preloadedInventory = false;

        protected override EngageIFX Create(IIfxAsset ifx)
        {
            var item = ifx as EngageIFX;

            if (item == null)
            {
                item = new EngageIFX(ifx);
            }

            item.AddListener(this, OnIfxUpdated);
            return item;
        }

        protected override EngageIFX Create(string name)
        {
            var item = new EngageIFX();
            item.Name = name;
            item.AddListener(this, OnIfxUpdated);

            return item;
        }

        protected override void Initialize()
        {
            base.Initialize();

            EngageUser.AddAuthenticationStateListener(OnAuthenticationChanged);
            OnAuthenticationChanged(EngageUser.AuthenticationState);
            preloadedInventory = true;
        }

        public override void Dispose()
        {
            EngageUser.RemoveAuthenticationStateListener(OnAuthenticationChanged);
            base.Dispose();
        }

        protected async void OnAuthenticationChanged(AuthenticationState authenticationState)
        {
            if (authenticationState == AuthenticationState.Authenticated)
            {
                await DataModule.RefreshAsync();
                RebuildInventory(await DataModule.GetAsync());
            }
        }

        protected override void RebuildInventory(IList<IIfxAsset> ifxs)
        {
            if (preloadedInventory)
            {
                preloadedInventory = false;
                return;
            }

            itemInventory.Clear();

            foreach (IIfxAsset ifx in ifxs)
            {
                itemInventory.Add(Create(ifx));
            }

            RefreshUploadHistory();
            RefreshDisplay();
        }

        protected override Predicate<EngageIFX> DisplayItem => (bundle) => bundle.Id.HasValue ? true : bundle.UnityResourceName == EngageUser.CurrentProjectName;

        public void RefreshUploadHistory()
        {
            EngageUser.RefreshUploadHistory();
            NotifyPropertyChange(nameof(RefreshUploadHistory));
        }

        public void ClearBundleUploadHistory()
        {
            EngageUser.ClearUploadHistory();
            NotifyPropertyChange(nameof(ClearBundleUploadHistory));
        }

        protected void OnIfxUpdated(ViewModel viewModel, string property)
        {
            NotifyPropertyChange(property);
        }

        internal async void DeleteIFX(EngageIFX ifx)
        {
            if (await ifx.DeleteAsset())
            {
                itemInventory.Remove(ifx);
            }

            RefreshDisplay();
        }

        public async override void RefreshFromServer()
        {
            await DataModule.RefreshAsync();

            Refresh();
        }
    }
}