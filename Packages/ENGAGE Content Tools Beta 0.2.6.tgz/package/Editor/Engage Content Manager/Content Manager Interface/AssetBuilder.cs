using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using System.IO;
using Engage.UI.Editor;
using Engage.CreatorSDK;
using System.Linq;
using System;
using System.Threading.Tasks;

namespace Engage.AssetManagement.Content
{
    public enum BundleBuildQueue { Parallel, Serial }

    public enum BuildMode { Create, Edit }

    [Flags]
    public enum BuildStatus
    {
        None = 0x0000,

        EngageAssetExists = 0x0001,
        BundlesExist = 0x0002,

        ThumbnailSelected = 0x0004,
        UnityAssetSelected = 0x0008,

        BundlesUploaded = 0x0010,
        ThumbnailUploaded = 0x0020,

        EngageAssetUpdated = 0x0040,

        EngageAssetError = 0x0100,
        ThumbnailError = 0x0200,
        BundleError = 0x0400,
        UnityAssetError = 0x0800
    }

    public abstract class AssetBuilder<T> : ViewModel where T : EngageAsset
    {
        public bool DemoMode { get; set; } = false;
        protected readonly BundleBuilder.BatchHandler handler = new BundleBuilder.BatchHandler();

        protected string localThumbnail;
        protected float thumbnailUploadProgress;

        protected T engageAsset;
        private Queue<BuildTarget> buildTargetQueue = new Queue<BuildTarget>();
        private BundleBuildQueue buildQueue = BundleBuildQueue.Serial;

        public BuildStatus Status { get; set; }
        public bool AwaitingBuild(EngagePlatform platform) => buildTargetQueue.Contains(platform.ToBuildTarget());
        public bool BuildModuleInstalled(EngagePlatform platform) => BundleBuilder.InstalledBuildModules.Contains(platform.ToBuildTarget());
        public bool BatchBuild { get; set; }

        public T EngageAsset
        {
            get
            {
                if (engageAsset == null)
                {
                    Refresh();
                }

                return engageAsset;
            }
            set
            {
                engageAsset = value;
                NotifyPropertyChange(nameof(EngageAsset));
            }
        }

        public BuildMode Mode { get; private set; } = BuildMode.Create;
        public string Message { get; set; }

        public int? Id { get => EngageAsset.Id; }
        public string Name { get => EngageAsset.Name; }
        public string UnityResourceName { get => EngageAsset.UnityResourceName; set => EngageAsset.UnityResourceName = value; }
        public string PrettyName { get => EngageAsset.PrettyName; set => EngageAsset.PrettyName.Set(Glossary.English, value); }
        public string Description { get => EngageAsset.Description; set => EngageAsset.Description.Set(Glossary.English, value); }
        public string ImageURL { get => EngageAsset.Image; set => EngageAsset.Image = value; }

        public List<IGroup> Groups => EngageAsset.Groups;
        public List<IAssetCollection> Collections => EngageAsset.Collections;
        public List<IAssetTag> Tags => EngageAsset.Tags;

        public string LocalThumbnail
        {
            get
            {
                return localThumbnail;
            }
            set
            {
                localThumbnail = value;
                NotifyPropertyChange(nameof(LocalThumbnail));
            }
        }

        internal void Edit(T asset)
        {
            Mode = BuildMode.Edit;
            this.engageAsset = asset;
            localThumbnail = EngageAsset.Image;
        }

        public BundleFiles LocalFiles { get; set; }
        public BundleBuildJob Job { get; protected set; }
        public abstract string UnityAssetName { get; }
        public bool ReUploadRequested { get; set; }

        // Returns max bundle file size in MBs
        public int MaxBundleFileSize
        {
            get
            {
                if (DemoMode) return 501;

                LocalFiles.Refresh();

                var maxBundleLength = LocalFiles.Count > 0 ? LocalFiles.Max(file => file.Value.Bundle.Length) : 0;
                return (int)(maxBundleLength / (1024 * 1024));
            }
        }

        public float ThumbnailUploadProgress
        {
            get => thumbnailUploadProgress;
            set
            {
                thumbnailUploadProgress = value;
                NotifyPropertyChange(nameof(ThumbnailUploadProgress));
            }
        }

        public bool MissingBuildModules
        {
            get
            {
                foreach (var target in BundleBuilder.SupportedBuildTargets)
                {
                    if (!BundleBuilder.InstalledBuildModules.Contains(target))
                    {
                        return true;
                    }
                }

                return false;
            }
        }

        public bool IsModuleInstalled(BuildTarget target)
        {
            if (target == BuildTarget.iOS)
                return false;

            return BundleBuilder.InstalledBuildModules.Contains(target);
        }


        protected override void Initialize()
        {
            base.Initialize();

            foreach (var target in BundleBuilder.SupportedBuildTargets)
            {
                if (BundleBuilder.IsModuleInstalled(target))
                {
                    BundleBuilder.InstalledBuildModules.Add(target);
                }
            }
        }

        public override void Refresh()
        {
            Message = "";

            if (engageAsset != null && Mode == BuildMode.Edit)
            {
                LoadEngageAsset(EngageAsset);
                LoadUnityAsset(EngageAsset.Name);
                LoadLocalFiles(EngageAsset.Name);
            }
            else
            {
                var guid = Selection.assetGUIDs.FirstOrDefault();
                LoadEngageAsset(guid);
                LoadUnityAsset(guid);
            }
        }

        public abstract void LoadEngageAsset(string guid);
        public virtual void LoadEngageAsset(T asset)
        {
            Status &= ~BuildStatus.EngageAssetExists;
            Status &= ~BuildStatus.ThumbnailSelected;

            localThumbnail = EngageAsset.Image;

            // Existing EngageAsset
            if (EngageAsset.Id.HasValue)
            {
                Status |= BuildStatus.EngageAssetExists;
            }
            else
            {
                if (!string.IsNullOrEmpty(localThumbnail))
                {
                    Status |= BuildStatus.ThumbnailSelected;
                }
            }
        }

        public void LoadLocalFiles(string guid)
        {
            Status &= ~BuildStatus.BundlesExist;

            if (string.IsNullOrEmpty(guid))
                return;

            LocalFiles = new BundleFiles(guid);
            LocalFiles.Refresh();

            //if (LocalFiles.Platforms > EngagePlatform.None)
            if (LocalFiles.Platforms == EngagePlatform.WAMI)
            {
                Debug.Log($"[Build Status] GUID {guid} Adding ({BuildStatus.BundlesExist}) to ({Status})");
                Status |= BuildStatus.BundlesExist;
            }

            NotifyPropertyChange(nameof(LocalFiles));
        }

        public abstract void LoadUnityAsset(string guid);

        public virtual void LoadBuildJob(string guid)
        {
            if (string.IsNullOrEmpty(Name))
            {
                LoadEngageAsset(guid);
                PrettyName = UnityAssetName.ToPretty();
            }

            UnityResourceName = UnityAssetName;

            Job = new BundleBuildJob(guid);
            Job.BundleLabel = Name ?? guid;
            Job.BuildTargets = BundleBuilder.ToEngagePlatform(BundleBuilder.SupportedBuildTargets);
            Job.OnComplete += OnBuildComplete;

            LoadLocalFiles(Name);

            NotifyPropertyChange(nameof(Job));
        }

        public void AddGroup(IGroup group) => EngageAsset.AddGroup(group);
        public void RemoveGroup(IGroup group) => EngageAsset.RemoveGroup(group);
        public void AddCollection(IAssetCollection collection) => EngageAsset.AddCollection(collection);
        public void RemoveCollection(IAssetCollection collection) => EngageAsset.RemoveCollection(collection);
        public void AddTag(IAssetTag tag) => EngageAsset.AddTag(tag);
        public void RemoveTag(IAssetTag tag) => EngageAsset.RemoveTag(tag);

        public async void Start()
        {
            if (BundleBuilder.IsBuildInProgress)
            {
                Debug.LogWarning("A build is already in progress");
                return;
            }

            // 1. Create/Update ENGAGE Location
            await CreateAsset();

            if (Status.HasFlag(BuildStatus.EngageAssetError))
            {
                if (Status.HasFlag(BuildStatus.EngageAssetExists))
                {
                    Debug.LogError($"[Create Asset] ({PrettyName}) - There was an error with the ENGAGE asset request.");
                }
                else
                {
                    Debug.LogError($"[Create Asset] ({PrettyName}) - There was an error with the ENGAGE asset request. Aborting build and upload process.");
                    return;
                }
            }

            // 2. Upload Thumbnail
            if (Status.HasFlag(BuildStatus.ThumbnailSelected))
            {
                await UploadThumbnail();
            }

            // 3. Build Bundles
            if (Status.HasFlag(BuildStatus.UnityAssetSelected))
            {
                buildTargetQueue = new Queue<BuildTarget>(BundleBuilder.SupportedBuildTargets);
                BuildBundles();
            }
        }

        public async Task CreateAsset()
        {
            if (DemoMode)
            {
                await Task.Delay(1000);
                Status |= BuildStatus.EngageAssetExists | BuildStatus.EngageAssetUpdated;
                LocalFiles = new BundleFiles("Demo");
                NotifyPropertyChange(nameof(Status));
                return;
            }

            if (Status.HasFlag(BuildStatus.EngageAssetExists))
            {
                await EngageAsset.UpdateAssetAsync();
            }
            else
            {
                await EngageAsset.CreateAssetAsync();
            }

            if (EngageAsset.RequestStatus == Network.RequestStatus.Error)
            {
                Status |= BuildStatus.EngageAssetError;
                NotifyPropertyChange(nameof(T));
                return;
            }
            else
            {
                if (Id.HasValue)
                {
                    Status |= BuildStatus.EngageAssetExists | BuildStatus.EngageAssetUpdated;
                    LocalFiles = new BundleFiles(EngageAsset.Name);

                    if (Job != null)
                    {
                        Job.BundleLabel = EngageAsset.Name;
                    }
                }
                else
                {
                    // NOTE: This shouldn't be able to happen.
                    Status &= ~BuildStatus.EngageAssetExists;
                    Status |= BuildStatus.EngageAssetError;
                }
            }

            NotifyPropertyChange(nameof(Status));
        }

        public async Task UploadThumbnail()
        {
            if (DemoMode)
            {
                await Task.Delay(1000);
                await MockThumbnailUploadProgress(OnThumbnailUploadDone);
                NotifyPropertyChange(nameof(Status));
                return;
            }

            if (File.Exists(LocalThumbnail))
            {
                EngageAsset.LocalThumbnailPath = LocalThumbnail;
                EngageAsset.UploadThumbnail(OnThumbnailProgress, OnThumbnailUploadDone);
            }

            NotifyPropertyChange(nameof(Status));
        }

        protected void OnThumbnailProgress(float progress)
        {
            ThumbnailUploadProgress = progress;
            NotifyPropertyChange(nameof(ThumbnailUploadProgress));
        }

        protected void OnThumbnailUploadDone(bool success)
        {
            if (success)
            {
                Status |= BuildStatus.ThumbnailUploaded;
            }
            else
            {
                Status |= BuildStatus.ThumbnailError;
            }
        }

        public async void BuildBundles()
        {
            if (DemoMode)
            {
                while (buildTargetQueue.Count > 0)
                {
                    var nextBuildTarget = buildTargetQueue.Dequeue();
                    await Task.Delay(1000);
                    OnBuildComplete(Job, nextBuildTarget.ToEngagePlatform());
                    Status |= BuildStatus.BundlesExist;
                }

                NotifyPropertyChange(nameof(Status));
                return;
            }

            NotifyPropertyChange(nameof(Status));

            if (BatchBuild)
            {
                buildQueue = BundleBuildQueue.Parallel;
                StartBatchBuildJob();
            }
            else
            {
                buildQueue = BundleBuildQueue.Serial;
                StartBuildJob();
            }
        }

        protected void StartBuildJob()
        {
            if (AssetDatabase.AssetPathToGUID(Job.BundlePath) == Job.BundleGuid)
            {
                Job.RunQATests();

                if (Job.IsQAPassed)
                {
                    NextBuildJob();
                }
            }
        }

        protected async void NextBuildJob()
        {
            var nextBuildTarget = buildTargetQueue.Dequeue();

            if (BundleBuilder.InstalledBuildModules.Contains(nextBuildTarget))
            {
                BundleBuilder.IsBuildInProgress = true;

                await Task.Delay(1000);
                Job.Start(nextBuildTarget);
            }
            else
            {
                Debug.LogWarning($"[Build Job] Build support for {nextBuildTarget} platform not installed.");
            }
        }

        private void StartBatchBuildJob()
        {
            foreach (BuildTarget target in BundleBuilder.InstalledBuildModules)
            {
                string batchPath = handler.CreateBatchBuildFile(Job, target);
                handler.RunBatchFile(batchPath);
            }
        }

        protected void OnBuildComplete(BundleBuildJob job, EngagePlatform platform)
        {
            Debug.Log($"[Build Job] Build Complete: ({platform})");
            NotifyPropertyChange(nameof(Status));

            if (DemoMode)
            {
                LocalFiles.Add(platform, new BundleFile(platform, "test", "TestAsset"));
                NotifyPropertyChange(nameof(LocalFiles));
                return;
            }

            LocalFiles.Refresh(platform);
            NotifyPropertyChange(nameof(LocalFiles));

            if (buildQueue == BundleBuildQueue.Serial && buildTargetQueue.Count > 0)
            {
                NotifyPropertyChange(nameof(Status));

                NextBuildJob();
            }
            else
            {
                // TODO: State change needed here
                Debug.Log($"[Build Status] Complete. Adding ({BuildStatus.BundlesExist}) to ({Status})");
                Status |= BuildStatus.BundlesExist;

                BundleBuilder.IsBuildInProgress = false;
                NotifyPropertyChange(nameof(LocalFiles));

                // 4. Upload Bundles
                //StartUpload();
                // NOTE: Upload is triggered by View state change
            }
        }

        public void StartUpload()
        {
            foreach (var bundle in BundleBuilder.SupportedBuildTargets)
            {
                Upload(bundle.ToEngagePlatform());
            }
        }

        public void Upload(EngagePlatform platform)
        {
            if (LocalFiles == null || !LocalFiles.TryGetValue(platform, out BundleFile localFile))
            {
                Debug.LogWarning($"[Upload] could find no local files for Platform ({platform})");
                return;
            }

            if (DemoMode)
            {
                MockUploadProgress(platform, OnUploadComplete);
            }
            else
            {
                //TODO: Need to add better error handling here
                EngageAsset.UploadBundle(platform, localFile, (bundle, progress) => NotifyPropertyChange($"{EngageAsset.PrettyName}_{platform}"), OnUploadComplete);
            }
        }

        protected void OnUploadComplete(BundleFile bundle, bool success)
        {
            if (success)
            {
                Debug.Log($"[{nameof(T)}] {bundle.Platform} ({bundle.Bundle?.FullName}) upload complete");
                bundle.Uploaded = true;
            }

            NotifyPropertyChange($"{EngageAsset.PrettyName}_{bundle.Platform}");
        }

        public async Task MockThumbnailUploadProgress(Action<bool> onComplete)
        {
            while (ThumbnailUploadProgress < 1)
            {
                await Task.Delay(80);
                ThumbnailUploadProgress += ThumbnailUploadProgress + 0.01f;
                NotifyPropertyChange(nameof(Status));
            }

            ThumbnailUploadProgress = 1f;
            onComplete?.Invoke(true);
        }

        public async void MockUploadProgress(EngagePlatform platform, Action<BundleFile, bool> onComplete)
        {
            if (LocalFiles.TryGetValue(platform, out BundleFile bundle))
            {
                while (bundle.UploadProgress < 1f)
                {
                    bundle.Status = Network.RequestStatus.Requesting;

                    await Task.Delay(20);
                    bundle.UpdateProgress(bundle.UploadProgress + 0.01f);

                    if (bundle.UploadProgress > 0.5f && bundle.UploadProgress < 0.515f)
                    {
                        bundle.Status = Network.RequestStatus.Error;
                        return;
                    }
                }

                bundle.UpdateProgress(1f);
                bundle.Status = Network.RequestStatus.Complete;
                bundle.Uploaded = true;
                onComplete?.Invoke(bundle, true);
            }
        }

        public void Save()
        {
            if (!Status.HasFlag(BuildStatus.EngageAssetExists))
            {
                EngageAsset.DeleteAsset();
                EngageAsset.Name = Job.BundleGuid;
                EngageAsset.UnityResourceName = EngageUser.CurrentProjectName;
            }

            if (Status.HasFlag(BuildStatus.ThumbnailSelected))
            {
                EngageAsset.Image = LocalThumbnail;
            }

            EngageAsset.Save();

            Message = $"{PrettyName} saved to local cache";
        }
    }
}