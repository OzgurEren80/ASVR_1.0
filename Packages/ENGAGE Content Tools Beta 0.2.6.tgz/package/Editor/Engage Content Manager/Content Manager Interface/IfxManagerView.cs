﻿using Engage.CreatorSDK;
using Engage.Network;
using Engage.UI.Editor;
using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    public class IfxManagerView : View<IfxManager>
    {
        public class Labels : Content.Labels
        {
            public const string MenuTitle = "Manage IFXs";
            public const string ViewTitle = " IFX Manager";
        }

        [MenuItem(MenuLabels.EngageAssetManagementPath + Labels.MenuTitle, priority = MenuLabels.ManagerViewPriority + 1)]
        public static void OpenView() => GetWindow<IfxManagerView>().Open();

        protected string search;
        protected Texture logo;
        private const int imageScaleUnit = 25;

        public Texture Logo
        {
            get
            {
                if (logo == null)
                {
                    logo = AssetDatabase.LoadAssetAtPath<Texture>(Icons.EngageLogoB);
                }

                return logo;
            }
        }

        private class IfxDisplaySet
        {
            private readonly HashSet<EngageIFX> displaySet = new HashSet<EngageIFX>();

            public bool this[EngageIFX ifx]
            {
                get => displaySet.Contains(ifx);
                set
                {
                    if (value)
                    {
                        if (displaySet.Add(ifx))
                        {
                            ifx.Refresh();
                        }
                    }
                    else
                    {
                        displaySet.Remove(ifx);
                    }
                }
            }
        }

        private CollectionPresenter<EngageIFX> sortState = new CollectionPresenter<EngageIFX>();

        private Action SortAction(SortOption sortOption, Comparison<EngageIFX> comparer)
        {
            return () =>
            {
                if (sortState.currentSortOption != sortOption)
                {
                    sortState.currentSortOption = sortOption;
                    sortState.currentSortDirection = SortDirection.None;
                }

                sortState.currentSort = comparer;
                sortState.Sort(ViewModel.ItemDisplayList);
            };
        }

        private void ReSort()
        {
            sortState.Sort(ViewModel.ItemDisplayList, true);
        }

        protected override void OnEnable()
        {
            base.OnEnable();

            titleContent = new GUIContent(Labels.ViewTitle, Logo);
            ViewModel.OnRefreshDisplay += ReSort;
            ThumbnailCache.OnCacheUpdate += ThumbnailCacheUpdated;
        }

        protected override void OnDisable()
        {
            base.OnDisable();

            ViewModel.OnRefreshDisplay -= ReSort;
            ThumbnailCache.OnCacheUpdate -= ThumbnailCacheUpdated;
        }

        public override void Draw()
        {
            using (var updatingArea = new GuiTools.EnabledScope(ViewModel.RefreshStatus != RequestStatus.Requesting))
            {
                Login.DrawLoginHeader(this);

                EditorGUILayout.Space();

                GuiTools.DrawSearchBar(ref search);

                GUILayout.Space(20);

                DrawIfxPanel();

                EditorGUILayout.Space();
            }

            EditorGUILayout.Space();

            ViewTools.DrawFooter();
        }

        private void ConfirmDeleteIFX(EngageIFX ifx)
        {
            if (EditorUtility.DisplayDialog(
                    title: "Confirm Delete IFX",
                    message: $"Permanently delete {ifx.PrettyName} from {(ifx.Id.HasValue ? "your ENGAGE IFXs" : "the local cache")}?",
                    ok: Labels.Delete,
                    cancel: Labels.Cancel
                ))
            {
                ViewModel.DeleteIFX(ifx);
            }
        }

        private void DrawIfxPanel()
        {
            using (var ifxPanelContentFrame = new EditorGUILayout.VerticalScope())
            {
                using (var ifxListColumnHeaders = new EditorGUILayout.HorizontalScope())
                {
                    using (var enabled = new GuiTools.EnabledScope(ViewModel.ItemDisplayList?.Count > 0))
                    {
                        GUILayout.Space(imageScaleUnit * 3 + 12);
                        GuiTools.DrawHeader($"{Labels.Name}{sortState.GetSymbol(SortOption.PrettyName)}", SortAction(SortOption.PrettyName, (a, b) => a.PrettyName.ToString().CompareTo(b.PrettyName)), GUILayout.Width(CreatorStyle.PRETTYNAME_WIDTH));
                        GuiTools.DrawHeader($"{Labels.Description}{sortState.GetSymbol(SortOption.Description)}", SortAction(SortOption.Description, (a, b) => a.Description.ToString().CompareTo(b.Description)), GUILayout.Width(CreatorStyle.PRETTYNAME_WIDTH));
                        GuiTools.DrawHeader($"{Labels.Updated}{sortState.GetSymbol(SortOption.LastUpdated)}", SortAction(SortOption.LastUpdated, (a, b) => a.UpdatedAt.CompareTo(b.UpdatedAt)), GUILayout.Width(CreatorStyle.DATE_WIDTH));
                    }
                }

                using (var scrollArea = new GuiTools.ScrollArea(ref scrollPos, EditorStyles.helpBox))
                {
                    DrawEngageIfxListView();
                }

                if (GUI.Button(new Rect(ifxPanelContentFrame.rect.width - 84, ifxPanelContentFrame.rect.y - 15, 40, 30), Icons.Plus.Tooltip("Create a new IFX")))
                {
                    IfxBuilderView.OpenView();
                }

                // TODO: disable button when request currently underway
                if (GUI.Button(new Rect(ifxPanelContentFrame.rect.width - 40, ifxPanelContentFrame.rect.y - 15, 40, 30), Icons.Refresh.Tooltip(Labels.RefreshFromServer)))
                {
                    ThumbnailCache.Clear();
                    ViewModel.RefreshFromServer();
                }
            }
        }

        private void DrawEngageIfxListView()
        {
            using (var ifxListPanel = new EditorGUILayout.VerticalScope())
            {
                bool even = true;

                foreach (var ifx in ViewModel.ItemDisplayList.ToArray())
                {
                    if (string.IsNullOrEmpty(search) || ifx.ToString().IndexOf(search, StringComparison.InvariantCultureIgnoreCase) > -1)
                    {
                        DrawEngageIfxRow(ifx, even ? CreatorStyle.RowStyleEven : CreatorStyle.RowStyleOdd);
                        even = !even;
                    }
                }
            }
        }

        private Color GetSyncStateColorCoding(EngageIFX ifx)
        {
            if (!ifx.Id.HasValue)
            {
                return CreatorStyle.Yellow;
            }

            return GUI.color;
        }

        private void DrawEngageIfxRow(EngageIFX ifx, GUIStyle style)
        {
            using (var engageBundleRow = new EditorGUILayout.HorizontalScope(style, GUILayout.ExpandWidth(false)))
            {
                // thumbnail
                GUILayout.Box(GetThumbnail(ifx), GUILayout.Width(imageScaleUnit * 3), GUILayout.Height(imageScaleUnit * 2));

                using (var localScope = new GuiTools.ColorScope(color: GetSyncStateColorCoding(ifx)))
                {
                    // Pretty Name
                    EditorGUILayout.LabelField(ifx.PrettyName, GUILayout.Width(CreatorStyle.PRETTYNAME_WIDTH));

                    // Description
                    EditorGUILayout.LabelField(ifx.Description, GUILayout.Width(CreatorStyle.PRETTYNAME_WIDTH));

                    // Timestamps
                    //EditorGUILayout.LabelField($"{bundle.CreatedAt}", GUILayout.Width(CreatorStyle.DATE_WIDTH));
                    EditorGUILayout.LabelField($"{ifx.UpdatedAt}", GUILayout.Width(CreatorStyle.DATE_WIDTH));

                    // Edit Button
                    GuiTools.DrawButton(Labels.Edit, () => IfxBuilderView.Edit(ifx), GUILayout.Width(CreatorStyle.SHORT_BUTTON_WIDTH));

                    // Delete Button
                    GuiTools.DrawButton(Labels.Delete, () => ConfirmDeleteIFX(ifx), GUILayout.Width(CreatorStyle.SHORT_BUTTON_WIDTH));
                }
            }
        }

        private GUIContent GetThumbnail(EngageIFX ifx)
        {
            if (string.IsNullOrEmpty(ifx.Image))
            {
                return Icons.Image;
            }

            if (string.IsNullOrEmpty(ifx.LocalThumbnailPath))
            {
                ifx.LocalThumbnailPath = ifx.Image;
            }

            if (BundleBuilder.IsBuildInProgress)
            {
                return Icons.GetWaitSpinner(ShowSpinner());
            }

            var thumbnail = ThumbnailCache.Get(ifx.LocalThumbnailPath);

            if (thumbnail.Status == ThumbnailStatus.Loading)
            {
                return Icons.GetWaitSpinner(ShowSpinner());
            }

            if (thumbnail.Status == ThumbnailStatus.Error)
            {
                return Icons.Error;
            }

            return new GUIContent(thumbnail.Image);
        }

        private void ThumbnailCacheUpdated()
        {
            Debug.Log("[IFX Manager View] Thumbnail Cache update");
            UpdateView();
        }
    }
}