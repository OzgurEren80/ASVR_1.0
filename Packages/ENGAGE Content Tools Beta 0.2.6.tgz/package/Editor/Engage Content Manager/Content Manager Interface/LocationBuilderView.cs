using Engage.UI.Editor;
using UnityEditor;
using UnityEngine;
using Engage.CreatorSDK;
using System.Linq;

namespace Engage.AssetManagement.Content
{
    public class LocationBuilderView : View<LocationBuilder>
    {
        private Texture logo;
        private float thumbnailScale = 50;
        private Vector2 thumbnailRatio = new Vector2(3, 2);
        private GUIContent localThumbnail;

        private LocationStatusPanel locationBuildStatusPanel;

        public Texture Logo
        {
            get
            {
                if (logo == null)
                {
                    logo = AssetDatabase.LoadAssetAtPath<Texture>(Icons.EngageLogoB);
                }

                return logo;
            }
        }

        private string LocalThumbnailPath
        {
            get => ViewModel.LocalThumbnail;
            set
            {
                if (ViewModel.LocalThumbnail == value)
                    return;

                localThumbnail = null;
                ViewModel.LocalThumbnail = value;
            }
        }

        public GUIContent LocalThumbnail
        {
            get
            {
                if (localThumbnail?.image == null)
                {
                    if (BundleBuilder.IsBuildInProgress)
                    {
                        return GetSpinner();
                    }

                    if (string.IsNullOrEmpty(LocalThumbnailPath))
                    {
                        localThumbnail = new GUIContent(Icons.Image);
                    }
                    else
                    {
                        var thumbnail = ThumbnailCache.Get(LocalThumbnailPath);

                        if (thumbnail.Status == ThumbnailStatus.Loading)
                        {
                            return GetSpinner();
                        }

                        if (thumbnail.Status == ThumbnailStatus.Error)
                        {
                            localThumbnail = new GUIContent(Icons.Error);
                        }
                        else
                        {
                            localThumbnail = new GUIContent(thumbnail.Image);
                        }
                    }

                    localThumbnail.tooltip = (string.IsNullOrEmpty(ViewModel.LocalThumbnail) ? Labels.ThumbnailSelectTooltip : ViewModel.LocalThumbnail) + "\n\n" + Labels.ThumbnailSpecification;
                }

                return localThumbnail;
            }
        }

        private LocationStatusPanel LocationBuildStatusPanel
        {
            get
            {
                if (locationBuildStatusPanel == null)
                {
                    locationBuildStatusPanel = new LocationStartState(this);
                }

                return locationBuildStatusPanel;
            }

            set
            {
                locationBuildStatusPanel = value;
            }
        }

        private class Labels : Content.Labels
        {
            public const string MenuTitle = "Create new ENGAGE Location";
            public const string ViewTitle = " Location Builder";
            public const string Build = Labels.Publish;//"Build Location";
            public const string Rebuild = Labels.Publish;//"Rebuild Location";
            public const string ThumbnailSelect = "Select\nThumbnail";

            public const string ConfirmBuildTitle = "Publish Location";
            public const string ConfirmBuildMessage = "Do you want to build this location and publish it to ENGAGE?";

            public const string Scene = "Scene";
            public const string SceneNoneSelected = "No scene selected";
            public const string SceneNoneSelectedMessage = "Please select a Unity scene to build as an ENGAGE location";
            public const string SaveTooltip = "Save your locations settings locally without uploading.";

            public const string SceneSelected = "Scene selected";
            public const string RebuildLocationConditionTooltip = "To rebuild this location, select a scene.";
            public const string UpdateLocationTooltip = "Update the details for this Location.";
            public const string ReUploadLocationTooltip = "Re-upload asset bundles and update the details for this Location.";
            public const string RebuildAndUpdateLocationTooltip = "Rebuild and update this Location.";

            public const string BuildLocationTooltip = "Build and upload this Location.";

            public const string CreateLocation = "Create Location";
            public const string UpdateLocation = "Update Location";

            public const string LocationStatus = "Location Status";
            public const string LocationUpdated = "Location updated";
            public const string LocationCreated = "Location created";

            public const string GuidelinesMessage = "Please refer to our Location guidelines.";
            public const string GuidelinesDocumentationLink = "https://docs.engagevr.io/developer/creating-locations";
        }

        protected override void OnEnable()
        {
            base.OnEnable();
            titleContent = new GUIContent(Labels.ViewTitle, Logo);
        }

        protected override void OnGUI()
        {
            base.OnGUI();

            if (Event.current.commandName == "ObjectSelectorClosed")
            {
                selectedScene = EditorGUIUtility.GetObjectPickerObject() as SceneAsset;
            }
        }

        protected SceneAsset selectedScene;

        protected override void Update()
        {
            base.Update();
            
            if (selectedScene != null)
            {
                Debug.Log($"[Location Builder View] Selected scene [{selectedScene}]");
                ViewModel.LoadUnityScene(selectedScene);

                localThumbnail = null;
                selectedScene = null;
            }

            LocationBuildStatusPanel.Update();
        }

        protected override void Open()
        {
            localThumbnail = null;
            base.Open();
        }

        [MenuItem(MenuLabels.AssetsToolsPath + Labels.MenuTitle, priority = MenuLabels.BuildViewPriority + 1)]
        public static void OpenView()
        {
            if (BundleBuilder.IsBuildInProgress)
            {
                BuildInProgressWarningDialog.OpenDialog();
                return;
            }

            var window = GetWindow<LocationBuilderView>();
            window.Open();
        }
        
        public static void Edit(EngageLocation location)
        {
            if (BundleBuilder.IsBuildInProgress)
            {
                BuildInProgressWarningDialog.OpenDialog();
                return;
            }

            var window = GetWindow<LocationBuilderView>();
            window.ViewModel.Edit(location);
            window.Open();
        }

        protected override void Initialize()
        {
            base.Initialize();

            LocationBuildStatusPanel = new LocationStartState(this);
        }

        public override void Draw()
        {
            Login.DrawLoginHeader(this);

            EditorGUILayout.Space();

            DrawBuildJob(ViewModel.Job);

            EditorGUILayout.Space();

            EditorGUILayout.Space();

            using (var enableEditing = new GuiTools.EnabledScope(!(LocationBuildStatusPanel is LocationStartState)))
            {
                using (var textArea = new EditorGUILayout.VerticalScope())
                {
                    // Pretty Name field
                    ViewModel.PrettyName = EditorGUILayout.TextField(Labels.Name, ViewModel.PrettyName);

                    EditorGUILayout.Space();

                    // Description field
                    ViewModel.Description = EditorGUILayout.TextField(Labels.Description, ViewModel.Description);

                    EditorGUILayout.Space();
                }

                //Thumbnail field
                if (GUILayout.Button(LocalThumbnail, GUILayout.Width(thumbnailScale * thumbnailRatio.x), GUILayout.Height(thumbnailScale * thumbnailRatio.y)))
                {
                    SelectThumbnail();
                }

                EditorGUILayout.Space();

                // Groups field
                MemberListView.DrawMemberListPanel(nameof(ViewModel.Groups), ViewModel.Groups, (IGroup group) => group.Name, ViewModel.RemoveGroup, GroupSelectorView.SelectMultiple, ViewModel.AddGroup);

                EditorGUILayout.Space();

                // Collections field
                //MemberListView.DrawMemberListPanel(nameof(ViewModel.Collections), ViewModel.Collections, (IAssetCollection collection) => collection.PrettyName, ViewModel.RemoveCollection, CollectionSelectorView.SelectMultiple, ViewModel.AddCollection);

                //EditorGUILayout.Space();

                // Tags field
                MemberListView.DrawMemberListPanel(nameof(ViewModel.Tags), ViewModel.Tags, (IAssetTag tag) => tag.Name, ViewModel.RemoveTag, TagSelectorView.SelectMultiple, ViewModel.AddTag);
            }

            GUILayout.Space(verticalSpace);

            LocationBuildStatusPanel.Draw();

            ViewTools.DrawFooter(ViewModel.Message);
        }

        private void DrawBuildJob(BundleBuildJob job)
        {
            using (var jobPanel = new EditorGUILayout.VerticalScope())
            {
                var sceneLabel = job == null ? new GUIContent(Labels.SceneNoneSelected, Labels.SceneNoneSelectedMessage)
                    : new GUIContent(ViewModel.UnityAssetName);
                var scenePath = job == null ? new GUIContent(Labels.EmptySelection)
                    : new GUIContent(job.BundlePath);

                using (var labelPanel = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(new GUIContent(Labels.Scene), EditorStyles.boldLabel, GUILayout.Width(EditorGUIUtility.labelWidth));
                    EditorGUILayout.LabelField(sceneLabel, EditorStyles.boldLabel);
                }

                EditorGUILayout.Space();

                using (var scenePathPanel = new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
                {
                    EditorGUILayout.LabelField(scenePath);

                    using (var buildInProgress = new GuiTools.EnabledScope(!BundleBuilder.IsBuildInProgress))
                    {
                        if (GUI.Button(new Rect(scenePathPanel.rect.x + scenePathPanel.rect.width - 22, scenePathPanel.rect.y + (scenePathPanel.rect.height * 0.5f) - 10, 20, 20), new GUIContent(Labels.Ellipsis)))
                        {
                            DrawAssetSelector();
                        }
                    }
                }
            }
        }

        public GUIContent GetSpinner() => Icons.GetWaitSpinner(ShowSpinner());

        private void DrawAssetSelector()
        {
            EditorGUIUtility.ShowObjectPicker<SceneAsset>(ViewModel.Scene, true, "", EditorGUIUtility.GetControlID(GetInstanceID(), FocusType.Keyboard));
        }

        private void SelectThumbnail()
        {
            var imagePath = GuiTools.BrowseFilePath(Labels.ThumbnailSelectTitle, ViewModel.LocalThumbnail, Thumbnail.imageTypes);

            if (!Thumbnail.validFileExtensions.Any(fileExtension => imagePath.ToLower().EndsWith(fileExtension)))
            {
                ThumbnailSizeDialog.OpenThumbnailWarningDialog(this);
                return;
            }

            var image = Thumbnail.Load(imagePath);

            if (image == null || image.width > 750 || image.height > 500)
            {
                ThumbnailSizeDialog.OpenThumbnailWarningDialog(this);
                return;
            }

            ViewModel.Status |= BuildStatus.ThumbnailSelected;
            LocalThumbnailPath = imagePath;
        }

        public Color GetBackgroundColorCoding(BundleFile file)
        {
            if (file != null)
            {
                return file.Uploaded ? CreatorStyle.Green : CreatorStyle.Red;
            }

            return GUI.backgroundColor;
        }

        private void Save()
        {
            ViewModel.Save();
            Close();
        }

        private void ConfirmCreateLocation()
        {
            ConfirmBuildDialog.OpenDialog(
                this,
                Labels.ConfirmBuildTitle,
                Labels.ConfirmBuildMessage,
                CreateLocation
                );
        }

        private void CreateLocation()
        {
            LocationBuildStatusPanel.NextState();
            ViewModel.Start();
        }

        /// <summary>
        /// Base class for all Location Status State Panels
        /// </summary>
        public abstract class LocationStatusPanel : BuildStatusPanel<LocationBuilderView>
        {
            public LocationStatusPanel(LocationBuilderView parent) : base(parent)
            {
                AssetLabel = Parent.ViewModel.Mode == BuildMode.Create ? Labels.LocationCreated : Labels.LocationUpdated;
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), Parent.Save);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Close), Parent.Close);
            }

            protected override string TitleLabel => Labels.LocationStatus;
            protected override string AssetSelectedLabel => Labels.SceneSelected;
            protected BuildStatus Status => Parent?.ViewModel?.Status ?? BuildStatus.None;
        }

        /// <summary>
        /// Error state
        /// </summary>
        public class ErrorState : LocationStatusPanel
        {
            public override void NextState() { }

            public ErrorState(LocationBuilderView parent) : base(parent) { }

            public override void DrawBody()
            {
                var sceneStatus = Icons.TestSkipped;

                if (Status.HasFlag(BuildStatus.UnityAssetSelected))
                {
                    sceneStatus = Icons.TestPassed;
                }

                DrawStatusRow(sceneStatus, Labels.SceneSelected);

                //---------

                var locationStatus = Icons.TestSkipped;

                if (Status.HasFlag(BuildStatus.EngageAssetError))
                {
                    locationStatus = Icons.Error.Tooltip($"There was an error with the {(Status.HasFlag(BuildStatus.EngageAssetExists) ? Labels.UpdateLocation : Labels.CreateLocation)} request");
                }
                else if (Status.HasFlag(BuildStatus.EngageAssetUpdated) && Status.HasFlag(BuildStatus.EngageAssetExists))
                {
                    locationStatus = Icons.TestPassed;
                }

                DrawStatusRow(locationStatus, AssetLabel);

                //---------

                var thumbnailStatus = Icons.TestSkipped;

                if (Status.HasFlag(BuildStatus.ThumbnailError))
                {
                    thumbnailStatus = Icons.Error.Tooltip("The thumbnail upload failed.");
                }
                else if (Status.HasFlag(BuildStatus.ThumbnailUploaded))
                {
                    thumbnailStatus = Icons.TestPassed;
                }

                DrawStatusRow(thumbnailStatus, Labels.ThumbnailUploaded);

                //---------

                var bundlesStatus = Icons.TestSkipped;

                if (Parent.ViewModel.MissingBuildModules)
                {
                    bundlesStatus = Icons.Error.Tooltip(Labels.BuildModulesMissing);
                }
                else if (Status.HasFlag(BuildStatus.BundleError))
                {
                    bundlesStatus = Icons.Error.Tooltip($"There was an error {(Status.HasFlag(BuildStatus.BundlesExist) ? "uploading" : "building")} this location.");
                }

                DrawStatusRow(bundlesStatus, Labels.Bundles);

                //---------

                if (Parent.ViewModel.MissingBuildModules)
                {
                    foreach (var platform in new EngagePlatform[] { EngagePlatform.Windows, EngagePlatform.Android, EngagePlatform.iOS, EngagePlatform.OSX })
                    {
                        DrawPlatformStatus(platform);
                    }

                    GUILayout.Space(20);

                    using (var errorText = new GuiTools.ColorScope(CreatorStyle.Red))
                    {
                        EditorGUILayout.LabelField(Labels.BuildModulesMissing);
                    }
                }
            }
        }

        /// <summary>
        /// Starting default Location state
        /// </summary>
        public class LocationStartState : LocationStatusPanel
        {
            public LocationStartState(LocationBuilderView parent) : base(parent)
            {
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Cancel), Parent.Close);
            }

            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => true;

            public override void NextState()
            {
                if (Status.HasFlag(BuildStatus.UnityAssetSelected))
                {
                    if (Parent.ViewModel.MissingBuildModules)
                    {
                        Parent.LocationBuildStatusPanel = new ErrorState(Parent);
                        return;
                    }

                    Parent.LocationBuildStatusPanel = new LocationBuildReadyState(Parent);
                }
                else
                {
                    Parent.LocationBuildStatusPanel = new LocationUpdateReadyState(Parent);
                }
            }

            public override void Update()
            {
                if (Status.HasFlag(BuildStatus.EngageAssetExists) || Status.HasFlag(BuildStatus.UnityAssetSelected))
                {
                    NextState();
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Status.HasFlag(BuildStatus.UnityAssetSelected) ? Icons.TestPassed : Icons.Error.Tooltip(Labels.SceneNoneSelectedMessage), Labels.SceneSelected);
                DrawStatusRow("", AssetLabel);
                DrawStatusRow("", Labels.ThumbnailUploaded);
                DrawStatusRow("", Labels.Bundles);
            }
        }

        /// <summary>
        /// State for starting update of existing Location with no Scene asset selected.
        /// </summary>
        public class LocationUpdateReadyState : LocationStatusPanel
        {
            public LocationUpdateReadyState(LocationBuilderView parent) : base(parent)
            {
                DrawStartButton = DrawButton;
            }

            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => EngageUser.IsAuthenticated;

            protected bool isRebuild;
            public override void NextState() => Parent.LocationBuildStatusPanel = new UpdatingLocationState(Parent);

            public override void Update()
            {
                if (Status.HasFlag(BuildStatus.UnityAssetSelected) && !isRebuild)
                {
                    isRebuild = true;

                    if (Parent.ViewModel.MissingBuildModules)
                    {
                        Parent.LocationBuildStatusPanel = new ErrorState(Parent);
                        return;
                    }

                    DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Rebuild, Labels.RebuildAndUpdateLocationTooltip), Parent.ConfirmCreateLocation);
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Parent.ViewModel.Status.HasFlag(BuildStatus.UnityAssetSelected) ? Icons.TestPassed : Icons.Warning.Tooltip(Labels.RebuildLocationConditionTooltip), Labels.SceneSelected);
                DrawStatusRow("", AssetLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow("", Labels.ThumbnailUploaded);
                }

                Parent.ViewModel.ReUploadRequested = DrawBundleStatus(Status.HasFlag(BuildStatus.UnityAssetSelected), Status.HasFlag(BuildStatus.BundlesExist), Parent.ViewModel.ReUploadRequested);
            }

            private void DrawButton() => GuiTools.DrawButton(GetButtonLabel(), Parent.CreateLocation);

            private GUIContent GetButtonLabel()
            {
                return Parent.ViewModel.ReUploadRequested && Status.HasFlag(BuildStatus.BundlesExist) ?
                    new GUIContent(Labels.ReUpload, Labels.ReUploadLocationTooltip)
                    : new GUIContent(Labels.Update, Labels.UpdateLocationTooltip);
            }
        }

        /// <summary>
        /// State for the update of existing Location's details and optionally thumbnail.
        /// </summary>
        public class UpdatingLocationState : LocationStatusPanel
        {
            public UpdatingLocationState(LocationBuilderView parent) : base(parent)
            {
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Update), null);
            }

            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;

            public override void NextState() => Parent.LocationBuildStatusPanel = new UploadingThumbnailState(Parent);

            public override void Update()
            {
                if (Status.HasFlag(BuildStatus.EngageAssetUpdated))
                {
                    NextState();
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Status.HasFlag(BuildStatus.UnityAssetSelected) ? Icons.TestPassed : Icons.TestSkipped, Labels.SceneSelected);
                DrawStatusRow(Status.HasFlag(BuildStatus.EngageAssetUpdated) ? Icons.TestPassed : Parent.GetSpinner(), AssetLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow("", Labels.SceneSelected);
                }

                DrawBundleStatus(Status.HasFlag(BuildStatus.UnityAssetSelected), Status.HasFlag(BuildStatus.BundlesExist), Parent.ViewModel.ReUploadRequested);
            }
        }

        /// <summary>
        /// Completed state for Update process.
        /// </summary>
        public class LocationUpdateCompleteState : LocationStatusPanel
        {
            public LocationUpdateCompleteState(LocationBuilderView parent) : base(parent)
            {
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Close), Parent.Close);
            }

            protected override bool SaveButtonEnabled => false;
            public override void NextState() { }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestSkipped, Labels.SceneSelected);
                DrawStatusRow(Icons.TestPassed, AssetLabel);
                DrawStatusRow(Status.HasFlag(BuildStatus.ThumbnailUploaded) ? Icons.TestPassed : Icons.TestSkipped, Labels.ThumbnailUploaded);
                DrawStatusRow(Icons.TestSkipped, Labels.Bundles);
            }
        }

        /// <summary>
        /// State in which Scene asset has been selected and the creation process is started.
        /// </summary>
        public class LocationBuildReadyState : LocationStatusPanel
        {
            public LocationBuildReadyState(LocationBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save, Labels.SaveTooltip), Parent.Save);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Build, BuildButtonTooltop), Parent.ConfirmCreateLocation);
            }

            protected override bool SaveButtonEnabled => true;
            protected override bool StartButtonEnabled => EngageUser.IsAuthenticated;
            protected string BuildButtonTooltop => StartButtonEnabled ? Labels.BuildLocationTooltip : Labels.LoginTooltip;

            public override void NextState() => Parent.LocationBuildStatusPanel = new CreatingLocationState(Parent);

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestPassed, Labels.SceneSelected);
                DrawStatusRow("", AssetLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow("", Labels.ThumbnailUploaded);
                }

                DrawStatusRow("", Labels.Bundles);

                // NOTE: Batch Mode will be supported in a later release
                // Batch Build Mode
                //Parent.ViewModel.BatchBuild = EditorGUILayout.Toggle(new GUIContent(Labels.BatchBuildMode, Labels.BatchBuildTooltip), Parent.ViewModel.BatchBuild);
            }
        }

        /// <summary>
        /// State in which the Location is created or updated.
        /// </summary>
        public class CreatingLocationState : LocationStatusPanel
        {
            public CreatingLocationState(LocationBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), null);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Build), null);
            }
            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;

            public override void NextState() => Parent.LocationBuildStatusPanel = new UploadingThumbnailState(Parent);

            public override void Update()
            {
                if (Status.HasFlag(BuildStatus.EngageAssetExists))
                {
                    NextState();
                }
                else if (Status.HasFlag(BuildStatus.EngageAssetError))
                {
                    Parent.LocationBuildStatusPanel = new ErrorState(Parent);
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestPassed, Labels.SceneSelected);
                DrawStatusRow(Parent.GetSpinner(), AssetLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow("", Labels.ThumbnailUploaded);
                }

                DrawStatusRow("", Labels.Bundles);
            }
        }

        /// <summary>
        /// State in which the Thumbnail is uploaded.
        /// </summary>
        public class UploadingThumbnailState : LocationStatusPanel
        {
            public UploadingThumbnailState(LocationBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), null);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Build), null);
            }
            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;

            public override void NextState()
            {
                if (Status.HasFlag(BuildStatus.UnityAssetSelected))
                {
                    Parent.LocationBuildStatusPanel = new BuildingLocationBundlesState(Parent);
                    return;
                }

                if (Parent.ViewModel.ReUploadRequested && Status.HasFlag(BuildStatus.BundlesExist))
                {
                    Parent.LocationBuildStatusPanel = new LocationUploadReadyState(Parent);
                }
                else
                {
                    Parent.LocationBuildStatusPanel = new LocationUpdateCompleteState(Parent);
                }
            }

            public override void Update()
            {
                if (!Status.HasFlag(BuildStatus.ThumbnailSelected))
                {
                    NextState();
                }

                if (Status.HasFlag(BuildStatus.ThumbnailUploaded)
                    || Status.HasFlag(BuildStatus.ThumbnailError)
                    )
                {
                    NextState();
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Status.HasFlag(BuildStatus.UnityAssetSelected) ? Icons.TestPassed : Icons.TestSkipped, Labels.SceneSelected);
                DrawStatusRow(Icons.TestPassed, AssetLabel);

                using (var opPanel = new EditorGUILayout.HorizontalScope())
                {
                    DrawStatusRow(Parent.GetSpinner(), Labels.ThumbnailUploaded);

                    var progress = Parent.ViewModel.ThumbnailUploadProgress;

                    if (progress < 1)
                    {
                        var progressRect = new Rect(
                            opPanel.rect.x + progressBarOffset,
                            opPanel.rect.y,
                            Mathf.Max(opPanel.rect.width - progressBarOffset, retryButtonWidth),
                            opPanel.rect.height
                            );

                        EditorGUI.ProgressBar(progressRect, progress, $"{progress * 100:F0}%");
                    }
                }

                using (var sceneSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.UnityAssetSelected)))
                {
                    DrawStatusRow("", Labels.Bundles);
                }
            }

            public override void DrawButtons()
            {
                using (var actionsEnabled = new GuiTools.EnabledScope(false))
                {
                    base.DrawButtons();
                }
            }
        }

        /// <summary>
        /// State in which the Build status is displayed.
        /// </summary>
        public class BuildingLocationBundlesState : LocationStatusPanel
        {
            public BuildingLocationBundlesState(LocationBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), null);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Build), null);
            }
            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;

            public override void NextState()
            {
                Parent.LocationBuildStatusPanel = new LocationUploadReadyState(Parent);
            }

            public override void Update()
            {
                if (Parent.ViewModel.LocalFiles.Platforms == Parent.ViewModel.Job.BuildTargets)
                {

                    NextState();
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestPassed, Labels.SceneSelected);
                DrawStatusRow(Icons.TestPassed, AssetLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow(Status.HasFlag(BuildStatus.ThumbnailUploaded) ? Icons.TestPassed : Icons.TestSkipped, Labels.ThumbnailUploaded);
                }

                DrawStatusRow(Parent.GetSpinner(), Labels.Bundles);

                foreach (var platform in new EngagePlatform[] { EngagePlatform.Windows, EngagePlatform.Android, EngagePlatform.iOS, EngagePlatform.OSX })
                {
                    DrawPlatformStatus(platform);
                }
            }

            public override void DrawPlatformStatus(EngagePlatform platform)
            {
                var icon = ViewTools.PlatformIcons[platform];

                bool built = Parent.ViewModel.LocalFiles?.ContainsKey(platform) ?? false;
                bool awaitingBuild = Parent.ViewModel.AwaitingBuild(platform);
                var status = new GUIContent();
                string processLabel = "";

                if (built)
                {
                    status = Icons.TestPassed;
                }
                else if (!awaitingBuild)
                {
                    status = Parent.GetSpinner();
                    processLabel = Labels.Building;
                }

                using (var platformPanel = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(new GUIContent(), GUILayout.Width(column1));
                    EditorGUILayout.LabelField(status, GUILayout.Width(column2));
                    EditorGUILayout.LabelField(icon, GUILayout.Width(column3));
                    EditorGUILayout.LabelField(processLabel, GUILayout.Width(processLabelWidth));
                }
            }
        }

        /// <summary>
        /// State in which the Upload status is evaluated.
        /// </summary>
        public class LocationUploadReadyState : LocationStatusPanel
        {
            public LocationUploadReadyState(LocationBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), null);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Build), null);
            }
            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;

            protected int bundleSizeThreshold = 500;
            protected bool cancelUpload;

            public override void NextState()
            {
                if (cancelUpload)
                {
                    Parent.LocationBuildStatusPanel = new ErrorState(Parent);
                    return;
                }

                Parent.ViewModel.StartUpload();
                Parent.LocationBuildStatusPanel = new UploadingLocationBundlesState(Parent);
            }

            public override void Update()
            {
                if (Status.HasFlag(BuildStatus.BundlesExist))
                {
                    if (Parent.ViewModel.MaxBundleFileSize > bundleSizeThreshold)
                    {
                        ConfirmUploadDialog.OpenDialog(
                            Parent,
                            Labels.LargeAssetSizeWarningTitle,
                            string.Format(Labels.LargeAssetSizeWarning, $"{bundleSizeThreshold} MB"),
                            Labels.LargeAssetSizeWarningConsequences,
                            Labels.GuidelinesMessage,
                            Labels.GuidelinesDocumentationLink,
                            NextState,
                            CancelUpload
                            );
                    }
                    else
                    {
                        NextState();
                    }
                }
            }

            protected void CancelUpload()
            {
                cancelUpload = true;
                NextState();
            }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestPassed, Labels.SceneSelected);
                DrawStatusRow(Icons.TestPassed, AssetLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow(Status.HasFlag(BuildStatus.ThumbnailUploaded) ? Icons.TestPassed : Icons.TestSkipped, Labels.ThumbnailUploaded);
                }

                DrawStatusRow(Parent.GetSpinner(), Labels.Bundles);

                foreach (var platform in new EngagePlatform[] { EngagePlatform.Windows, EngagePlatform.Android, EngagePlatform.iOS, EngagePlatform.OSX })
                {
                    DrawPlatformStatus(platform);
                }
            }

            public override void DrawPlatformStatus(EngagePlatform platform)
            {
                var icon = ViewTools.PlatformIcons[platform];

                var status = new GUIContent();
                string processLabel = Labels.Uploading;

                using (var platformPanel = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(new GUIContent(), GUILayout.Width(column1));
                    EditorGUILayout.LabelField(status, GUILayout.Width(column2));
                    EditorGUILayout.LabelField(icon, GUILayout.Width(column3));
                    EditorGUILayout.LabelField(processLabel, GUILayout.Width(processLabelWidth));
                }
            }
        }

        /// <summary>
        /// State in which the Upload status is displayed.
        /// </summary>
        public class UploadingLocationBundlesState : LocationStatusPanel
        {
            public UploadingLocationBundlesState(LocationBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), null);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Build), null);

                IsRunning = true;
            }
            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;
            protected bool IsRunning { get; set; }

            public override void NextState() => Parent.LocationBuildStatusPanel = new CompleteState(Parent);

            public override void Update()
            {
                if (Parent.ViewModel.LocalFiles.Uploaded == (EngagePlatform.Windows | EngagePlatform.Android | EngagePlatform.iOS | EngagePlatform.OSX))// Parent.ViewModel.Job.BuildTargets)
                {
                    NextState();
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestPassed, Labels.SceneSelected);
                DrawStatusRow(Icons.TestPassed, AssetLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow(Status.HasFlag(BuildStatus.ThumbnailUploaded) ? Icons.TestPassed : Icons.TestSkipped, Labels.ThumbnailUploaded);
                }

                IsRunning = Parent.ViewModel.LocalFiles.Any(bundle => bundle.Value.Status == Network.RequestStatus.Requesting);

                DrawStatusRow(IsRunning ? Parent.GetSpinner() : Icons.Error, Labels.Bundles);

                foreach (var platform in new EngagePlatform[] { EngagePlatform.Windows, EngagePlatform.Android, EngagePlatform.iOS, EngagePlatform.OSX })
                {
                    DrawPlatformStatus(platform);
                }
            }

            public override void DrawPlatformStatus(EngagePlatform platform)
            {
                var icon = ViewTools.PlatformIcons[platform];

                bool uploaded = false;
                float progress = 0;
                bool error = false;

                if (Parent.ViewModel.LocalFiles.TryGetValue(platform, out BundleFile bundle))
                {
                    uploaded = bundle.Uploaded;
                    progress = bundle.UploadProgress;
                    error = bundle.Status == Network.RequestStatus.Error;
                    IsRunning = bundle.Status == Network.RequestStatus.Requesting;
                }

                GUIContent testPassedIcon = Icons.TestPassed.Tooltip("Upload complete.");
                GUIContent errorIcon = Icons.Error.Tooltip("An error occurred during upload.");

                GUIContent status = uploaded ? testPassedIcon : error ? errorIcon : Parent.GetSpinner();
                string processLabel = uploaded ? Labels.Done : error ? Labels.Error : Labels.Uploading;

                using (var uploadProgressPanel = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField("", GUILayout.Width(column1));
                    EditorGUILayout.LabelField(status, GUILayout.Width(column2));
                    EditorGUILayout.LabelField(icon, GUILayout.Width(column3));
                    EditorGUILayout.LabelField(processLabel, GUILayout.Width(processLabelWidth));

                    if (!uploaded && progress < 1)
                    {
                        var progressRect = new Rect(
                            uploadProgressPanel.rect.x + progressBarOffset,
                            uploadProgressPanel.rect.y,
                            Mathf.Max(uploadProgressPanel.rect.width - progressBarOffset, retryButtonWidth),
                            uploadProgressPanel.rect.height
                            );

                        using (var progressActive = new GuiTools.EnabledScope(!error))
                        {
                            EditorGUI.ProgressBar(progressRect, progress, $"{progress * 100:F0}%");
                        }

                        if (error)
                        {
                            var retryRect = new Rect(
                                Mathf.Max(
                                    uploadProgressPanel.rect.x + uploadProgressPanel.rect.width - (retryButtonWidth + rightPadding),
                                    retryButtonWidth + rightPadding
                                    ),
                                uploadProgressPanel.rect.y,
                                retryButtonWidth,
                                EditorGUIUtility.singleLineHeight
                                );

                            if (GUI.Button(retryRect, Labels.Retry))
                            {
                                Parent.ViewModel.Upload(platform);
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// State in which all processes are completed, and the window can then be closed.
        /// </summary>
        public class CompleteState : LocationStatusPanel
        {
            public CompleteState(LocationBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), null);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Close), Parent.Close);
            }
            protected override bool SaveButtonEnabled => false;

            public override void NextState() { }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestPassed, Labels.SceneSelected);
                DrawStatusRow(Icons.TestPassed, AssetLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow(Status.HasFlag(BuildStatus.ThumbnailUploaded) ? Icons.TestPassed : Icons.TestSkipped, Labels.ThumbnailUploaded);
                }

                DrawStatusRow(Icons.TestPassed, Labels.Bundles);
            }
        }
    }
}