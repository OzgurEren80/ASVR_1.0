﻿using UnityEditor;
using UnityEngine;
using System;

namespace Engage.AssetManagement.Content
{
    public class ThumbnailSizeDialog : EngageConfirmWarningPrompt<EditorWindow>
    {
        protected const int heightExtent = 100;
        protected const int widthExtent = 150;

        public string Statement { get; set; }
        public string Guidelines { get; set; }
        public string GuidelinesUrl { get; set; }

        GUIStyle statementStyle;
        GUIStyle StatementStyle
        {
            get
            {
                if (statementStyle == null)
                {
                    statementStyle = new GUIStyle(MessageStyle);
                    statementStyle.fontStyle = FontStyle.Bold;
                }

                return statementStyle;
            }
            set
            {
                statementStyle = value;
            }
        }

        public static void OpenDialog(
            EditorWindow view,
            string title,
            string statement,
            string messageBody,
            Action confirmCallback = null
            )
        {
            var dialog = GetWindow<ThumbnailSizeDialog>(title);
            dialog.Statement = statement;
            dialog.MessageBody = messageBody;

            dialog.LabelConfirm = Labels.CancelUpload;
            dialog.OnConfirm = confirmCallback;

            var extents = new Vector2(widthExtent, heightExtent);

            dialog.position = new Rect(view.position.center - extents, extents * 2);

            dialog.ShowModalUtility();
        }

        public static void OpenThumbnailWarningDialog(EditorWindow view)
        {
            //Warning pop-up
            ThumbnailSizeDialog.OpenDialog(
                        view,
                        Labels.ThumbnailSizeWarningTitle,
                        string.Format(Labels.ThumbnailSizeWarning),
                        Labels.ThumbnailWarningConsequences
                        );
        }

        public override Action<EditorWindow> DrawMessageBody
        {
            get => DrawMessage;
            set => base.DrawMessageBody = value;
        }

        public void DrawMessage(EditorWindow window)
        {
            using (var bodyArea = new EditorGUILayout.VerticalScope())
            {
                GUILayout.Space(10);

                using (var statementArea = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.HelpBox("", MessageType.Warning);
                    GUILayout.Space(20);
                    EditorGUILayout.LabelField(Statement, StatementStyle);
                }

                GUILayout.Space(20);
                EditorGUILayout.LabelField(MessageBody, MessageStyle);

                GUILayout.Space(20);
                if (EditorGUILayout.LinkButton(Guidelines))
                {
                    Application.OpenURL(GuidelinesUrl);
                }
            }
        }
    }
}