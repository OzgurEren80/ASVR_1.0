﻿using UnityEditor;
using UnityEngine;
using System;

namespace Engage.AssetManagement.Content
{
    public class ConfirmBuildDialog : EngageConfirmDialog<EditorWindow>
    {
        protected const int heightExtent = 75;
        protected const int widthExtent = 150;

        public static void OpenDialog(
            EditorWindow view,
            string title,
            string messageBody,
            Action confirmCallback = null,
            Action cancelCallback = null
            )
        {
            var dialog = GetWindow<ConfirmBuildDialog>(title);

            dialog.MessageBody = messageBody;
            dialog.LabelConfirm = Labels.Publish;
            dialog.OnConfirm = confirmCallback;
            dialog.OnCancel = cancelCallback;

            var extents = new Vector2(widthExtent, heightExtent);

            dialog.position = new Rect(view.position.center - extents, extents * 2);

            dialog.ShowModalUtility();
        }
    }
}