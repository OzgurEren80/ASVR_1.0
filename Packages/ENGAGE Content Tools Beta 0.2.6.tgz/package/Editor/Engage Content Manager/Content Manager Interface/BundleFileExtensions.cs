﻿using System.Collections.Generic;
using UnityEditor;
using Engage.CreatorSDK;

namespace Engage.AssetManagement.Content
{
    public enum EngageFileType
    {
        Unknown = -1,
        Bundle = 0,
        Manifest = 1
    }

    public enum AssetPrivacy
    {
        Private, Public, Mixed
    }

    public enum EngageTarget
    {
        Unspecified = 0, Common = 1, Client = 2
    }

    public class BundleTarget
    {
        public EngageTarget id;
        public string name;
    }

    public static class BundleFileExtensions
    {
        public static BundleFileFormData.Platform ToBundleFilePlatform(this EngagePlatform platform)
        {
            switch (platform)
            {
                case EngagePlatform.Android: return BundleFileFormData.Platform.Android;
                case EngagePlatform.iOS: return BundleFileFormData.Platform.iOS;
                case EngagePlatform.OSX: return BundleFileFormData.Platform.macOS;
                case EngagePlatform.Windows: return BundleFileFormData.Platform.Windows;
                default: return BundleFileFormData.Platform.Undefined;
            }
        }

        public static EngagePlatform ToEngagePlatform(this BuildTarget target)
        {
            switch (target)
            {
                case BuildTarget.Android: return EngagePlatform.Android;
                case BuildTarget.iOS: return EngagePlatform.iOS;
                case BuildTarget.StandaloneOSX: return EngagePlatform.OSX;
                case BuildTarget.WebGL: return EngagePlatform.WebGL;
                case BuildTarget.StandaloneWindows:
                case BuildTarget.StandaloneWindows64: return EngagePlatform.Windows;
                default: return EngagePlatform.None;
            }
        }

        public static BuildTarget ToBuildTarget(this EngagePlatform platform)
        {
            switch (platform)
            {
                case EngagePlatform.Android: return BuildTarget.Android;
                case EngagePlatform.iOS: return BuildTarget.iOS;
                case EngagePlatform.OSX: return BuildTarget.StandaloneOSX;
                default:
                case EngagePlatform.Windows: return BuildTarget.StandaloneWindows;
            }
        }

        public static string ToString(this EngagePlatform platform)
        {
            var buildTargets = new List<string>();

            foreach (EngagePlatform target in System.Enum.GetValues(typeof(EngagePlatform)))
            {
                if (target > EngagePlatform.None && platform.HasFlag(target))
                {
                    buildTargets.Add(target.ToString());
                }
            }

            return string.Join(", ", buildTargets);
        }
    }
}