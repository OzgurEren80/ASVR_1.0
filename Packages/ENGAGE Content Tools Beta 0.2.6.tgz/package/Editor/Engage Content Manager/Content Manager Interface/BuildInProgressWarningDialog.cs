﻿using UnityEngine;

namespace Engage.AssetManagement.Content
{
    public class BuildInProgressWarningDialog : EngageConfirmDialog<EngageAsset>
    {
        public class Labels : Content.Labels
        {
            public const string BuildInProgress = "Build In Progress";
            public const string Message = "There is already a build in progress. Please wait until the current job has completed before beginning another.";
        }

        protected const int heightExtent = 75;
        protected const int widthExtent = 150;

        public static void OpenDialog()
        {
            var dialog = GetWindow<BuildInProgressWarningDialog>(Labels.BuildInProgress);

            dialog.MessageBody = Labels.Message;

            dialog.LabelConfirm = Labels.OK;
            dialog.OnConfirm = dialog.Close;

            var extents = new Vector2(widthExtent, heightExtent);

            dialog.maxSize = dialog.minSize = extents * 2;

            dialog.ShowModalUtility();
        }

    }
}