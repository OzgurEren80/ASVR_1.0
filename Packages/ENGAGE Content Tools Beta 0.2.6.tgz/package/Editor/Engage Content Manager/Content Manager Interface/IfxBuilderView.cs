using Engage.UI.Editor;
using UnityEditor;
using UnityEngine;
using Engage.CreatorSDK;
using System.Linq;

namespace Engage.AssetManagement.Content
{
    public class IfxBuilderView : View<IfxBuilder>
    {
        private Texture logo;
        private float thumbnailScale = 50;
        private Vector2 thumbnailRatio = new Vector2(3, 2);
        private GUIContent localThumbnail;

        private IfxStatusPanel ifxBuildStatusPanel;

        public Texture Logo
        {
            get
            {
                if (logo == null)
                {
                    logo = AssetDatabase.LoadAssetAtPath<Texture>(Icons.EngageLogoB);
                }

                return logo;
            }
        }

        private string LocalThumbnailPath
        {
            get => ViewModel.LocalThumbnail;
            set
            {
                if (ViewModel.LocalThumbnail == value)
                    return;

                localThumbnail = null;
                ViewModel.LocalThumbnail = value;
            }
        }

        public GUIContent LocalThumbnail
        {
            get
            {
                if (localThumbnail?.image == null)
                {
                    if (BundleBuilder.IsBuildInProgress)
                    {
                        return GetSpinner();
                    }

                    if (string.IsNullOrEmpty(LocalThumbnailPath))
                    {
                        localThumbnail = new GUIContent(Icons.Image);
                    }
                    else
                    {
                        var thumbnail = ThumbnailCache.Get(LocalThumbnailPath);

                        if (thumbnail.Status == ThumbnailStatus.Loading) 
                        {
                            return GetSpinner();
                        }
                        
                        if (thumbnail.Status == ThumbnailStatus.Error)
                        {
                            localThumbnail = new GUIContent(Icons.Error);
                        }
                        else
                        {
                            localThumbnail = new GUIContent(thumbnail.Image);
                        }
                    }

                    localThumbnail.tooltip = (string.IsNullOrEmpty(ViewModel.LocalThumbnail) ? Labels.ThumbnailSelectTooltip : ViewModel.LocalThumbnail) + "\n\n" + Labels.ThumbnailSpecification;
                }

                return localThumbnail;
            }
        }

        private IfxStatusPanel IfxBuildStatusPanel
        {
            get
            {
                if (ifxBuildStatusPanel == null)
                {
                    ifxBuildStatusPanel = new IfxStartState(this);
                }

                return ifxBuildStatusPanel;
            }

            set
            {
                ifxBuildStatusPanel = value;
            }
        }

        private class Labels : Content.Labels
        {
            public const string MenuTitle = "Create new ENGAGE IFX";
            public const string ViewTitle = " IFX Builder";
            public const string Build = Labels.Publish;
            public const string Rebuild = Labels.Publish;
            public const string ThumbnailSelect = "Select\nThumbnail";

            public const string ConfirmBuildTitle = "Publish IFX";
            public const string ConfirmBuildMessage = "Do you want to build this IFX and publish it to ENGAGE?";

            public const string Prefab = "Prefab";
            public const string PrefabNoneSelected = "No prefab selected";
            public const string PrefabNoneSelectedMessage = "Please select a Unity prefab to build as an ENGAGE IFX";
            public const string SaveTooltip = "Save your IFX settings locally without uploading.";

            public const string PrefabSelected = "Prefab Selected";
            public const string RebuildIfxConditionTooltip = "To rebuild this IFX, select a prefab.";
            public const string UpdateIfxTooltip = "Update the details for this IFX.";
            public const string ReUploadIfxTooltip = "Re-upload asset bundles and update the details for this IFX.";
            public const string RebuildAndUpdateIfxTooltip = "Rebuild and update this IFX.";

            public const string BuildIfxTooltip = "Build and upload this IFX.";

            public const string CreateIFX = "Create IFX";
            public const string UpdateIFX = "Update IFX";

            public const string IfxStatus = "IFX Status";
            public const string IfxUpdated = "IFX updated";
            public const string IfxCreated = "IFX created";

            public const string GuidelinesMessage = "Please refer to our IFX guidelines.";
            public const string GuidelinesDocumentationLink = "https://docs.engagevr.io/developer/creating-ifx";
        }

        protected override void OnEnable()
        {
            base.OnEnable();
            titleContent = new GUIContent(Labels.ViewTitle, Logo);
        }

        protected override void OnGUI()
        {
            base.OnGUI();

            if (Event.current.commandName == "ObjectSelectorClosed")
            {
                var prefab = EditorGUIUtility.GetObjectPickerObject() as GameObject;

                if (prefab == null)
                    return;

                Debug.Log($"[IFX Builder View] Selected prefab [{prefab}]");
                ViewModel.LoadUnityPrefab(prefab);
                localThumbnail = null;
            }
        }

        protected GameObject selectedPrefab;

        protected override void Update()
        {
            base.Update();

            if (selectedPrefab != null)
            {
                Debug.Log($"[IFX Builder View] Selected prefab [{selectedPrefab}]");
                ViewModel.LoadUnityPrefab(selectedPrefab);

                localThumbnail = null;
                selectedPrefab = null;
            }

            IfxBuildStatusPanel.Update();
        }

        protected override void Open()
        {
            localThumbnail = null;
            base.Open();
        }

        [MenuItem(MenuLabels.AssetsToolsPath + Labels.MenuTitle, priority = MenuLabels.BuildViewPriority + 1)]
        public static void OpenView()
        {
            if (BundleBuilder.IsBuildInProgress)
            {
                BuildInProgressWarningDialog.OpenDialog();
                return;
            }

            var window = GetWindow<IfxBuilderView>();
            window.Open();
        }

        public static void Edit(EngageIFX ifx)
        {
            if (BundleBuilder.IsBuildInProgress)
            {
                BuildInProgressWarningDialog.OpenDialog();
                return;
            }

            var window = GetWindow<IfxBuilderView>();
            window.ViewModel.Edit(ifx);
            window.Open();
        }

        protected override void Initialize()
        {
            base.Initialize();

            IfxBuildStatusPanel = new IfxStartState(this);
        }

        public override void Draw()
        {
            Login.DrawLoginHeader(this);

            EditorGUILayout.Space();

            DrawBuildJob(ViewModel.Job);

            EditorGUILayout.Space();

            EditorGUILayout.Space();

            using (var enableEditing = new GuiTools.EnabledScope(!(IfxBuildStatusPanel is IfxStartState)))
            {
                using (var textArea = new EditorGUILayout.VerticalScope())
                {
                    // Pretty Name field
                    ViewModel.PrettyName = EditorGUILayout.TextField(Labels.Name, ViewModel.PrettyName);

                    EditorGUILayout.Space();

                    // Description field
                    ViewModel.Description = EditorGUILayout.TextField(Labels.Description, ViewModel.Description);

                    EditorGUILayout.Space();
                }

                //Thumbnail field
                if (GUILayout.Button(LocalThumbnail, GUILayout.Width(thumbnailScale * thumbnailRatio.x), GUILayout.Height(thumbnailScale * thumbnailRatio.y)))
                {
                    SelectThumbnail();
                }

                EditorGUILayout.Space();

                // Groups field
                MemberListView.DrawMemberListPanel(nameof(ViewModel.Groups), ViewModel.Groups, (IGroup group) => group.Name, ViewModel.RemoveGroup, GroupSelectorView.SelectMultiple, ViewModel.AddGroup);

                EditorGUILayout.Space();

                // Collections field
                //MemberListView.DrawMemberListPanel(nameof(ViewModel.Collections), ViewModel.Collections, (IAssetCollection collection) => collection.PrettyName, ViewModel.RemoveCollection, CollectionSelectorView.SelectMultiple, ViewModel.AddCollection);

                //EditorGUILayout.Space();

                // Tags field
                MemberListView.DrawMemberListPanel(nameof(ViewModel.Tags), ViewModel.Tags, (IAssetTag tag) => tag.Name, ViewModel.RemoveTag, TagSelectorView.SelectMultiple, ViewModel.AddTag);
            }

            GUILayout.Space(verticalSpace);

            IfxBuildStatusPanel.Draw();

            ViewTools.DrawFooter(ViewModel.Message);
        }

        private void DrawBuildJob(BundleBuildJob job)
        {
            using (var jobPanel = new EditorGUILayout.VerticalScope())
            {
                var ifxLabel = job == null ? new GUIContent(Labels.PrefabNoneSelected, Labels.PrefabNoneSelectedMessage)
                    : new GUIContent(ViewModel.UnityAssetName);
                var ifxPath = job == null ? new GUIContent(Labels.EmptySelection)
                    : new GUIContent(job.BundlePath);

                using (var labelPanel = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(new GUIContent(Labels.Prefab), EditorStyles.boldLabel, GUILayout.Width(EditorGUIUtility.labelWidth));
                    EditorGUILayout.LabelField(ifxLabel, EditorStyles.boldLabel);
                }

                EditorGUILayout.Space();

                using (var ifxPathPanel = new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
                {
                    EditorGUILayout.LabelField(ifxPath);

                    using (var buildInProgress = new GuiTools.EnabledScope(!BundleBuilder.IsBuildInProgress))
                    {
                        if (GUI.Button(new Rect(ifxPathPanel.rect.x + ifxPathPanel.rect.width - 22, ifxPathPanel.rect.y + (ifxPathPanel.rect.height * 0.5f) - 10, 20, 20), new GUIContent(Labels.Ellipsis)))
                        {
                            DrawAssetSelector();
                        }
                    }
                }
            }
        }

        public GUIContent GetSpinner() => Icons.GetWaitSpinner(ShowSpinner());

        private void DrawAssetSelector()
        {
            EditorGUIUtility.ShowObjectPicker<GameObject>(ViewModel.Prefab, false, "t:prefab", GUIUtility.GetControlID(GetInstanceID(), FocusType.Keyboard));
        }

        private void SelectThumbnail()
        {
            var imagePath = GuiTools.BrowseFilePath(Labels.ThumbnailSelectTitle, ViewModel.LocalThumbnail, Thumbnail.imageTypes);

            if (!Thumbnail.validFileExtensions.Any(fileExtension => imagePath.ToLower().EndsWith(fileExtension)))
            {
                ThumbnailSizeDialog.OpenThumbnailWarningDialog(this);
                return;
            }

            var image = Thumbnail.Load(imagePath);

            if (image == null || image.width > 750 || image.height > 500)
            {
                ThumbnailSizeDialog.OpenThumbnailWarningDialog(this);
                return;
            }

            ViewModel.Status |= BuildStatus.ThumbnailSelected;
            LocalThumbnailPath = imagePath;
        }

        public Color GetBackgroundColorCoding(BundleFile file)
        {
            if (file != null)
            {
                return file.Uploaded ? CreatorStyle.Green : CreatorStyle.Red;
            }

            return GUI.backgroundColor;
        }

        private void Save()
        {
            ViewModel.Save();
            Close();
        }

        private void ConfirmCreateIfx()
        {
            ConfirmBuildDialog.OpenDialog(
                this,
                Labels.ConfirmBuildTitle,
                Labels.ConfirmBuildMessage,
                CreateIfx
                );
        }

        private void CreateIfx()
        {
            IfxBuildStatusPanel.NextState();
            ViewModel.Start();
        }

        /// <summary>
        /// Base class for all Ifx Status State Panels
        /// </summary>
        public abstract class IfxStatusPanel : BuildStatusPanel<IfxBuilderView>
        {
            public IfxStatusPanel(IfxBuilderView parent) : base(parent)
            {
                AssetLabel = Parent.ViewModel.Mode == BuildMode.Create ? Labels.IfxCreated : Labels.IfxUpdated;
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), Parent.Save);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Close), Parent.Close);
            }

            protected override string TitleLabel => Labels.IfxStatus;
            protected override string AssetSelectedLabel => Labels.PrefabSelected;
            protected BuildStatus Status => Parent?.ViewModel?.Status ?? BuildStatus.None;
        }

        /// <summary>
        /// Error state
        /// </summary>
        public class ErrorState : IfxStatusPanel
        {
            public override void NextState() { }

            public ErrorState(IfxBuilderView parent) : base(parent) { }

            public override void DrawBody()
            {
                var ifxStatus = Icons.TestSkipped;

                if (Status.HasFlag(BuildStatus.UnityAssetSelected))
                {
                    ifxStatus = Icons.TestPassed;
                }

                DrawStatusRow(ifxStatus, Labels.PrefabSelected);

                //---------

                var IfxStatus = Icons.TestSkipped;

                if (Status.HasFlag(BuildStatus.EngageAssetError))
                {
                    IfxStatus = Icons.Error.Tooltip($"There was an error with the {(Status.HasFlag(BuildStatus.EngageAssetExists) ? Labels.UpdateIFX : Labels.CreateIFX)} request");
                }
                else if (Status.HasFlag(BuildStatus.EngageAssetUpdated) && Status.HasFlag(BuildStatus.EngageAssetExists))
                {
                    IfxStatus = Icons.TestPassed;
                }

                DrawStatusRow(IfxStatus, AssetLabel);

                //---------

                var thumbnailStatus = Icons.TestSkipped;

                if (Status.HasFlag(BuildStatus.ThumbnailError))
                {
                    thumbnailStatus = Icons.Error.Tooltip("The thumbnail upload failed.");
                }
                else if (Status.HasFlag(BuildStatus.ThumbnailUploaded))
                {
                    thumbnailStatus = Icons.TestPassed;
                }

                DrawStatusRow(thumbnailStatus, Labels.ThumbnailUploaded);

                //---------

                var bundlesStatus = Icons.TestSkipped;

                if (Parent.ViewModel.MissingBuildModules)
                {
                    bundlesStatus = Icons.Error.Tooltip(Labels.BuildModulesMissing);
                }
                else if (Status.HasFlag(BuildStatus.BundleError))
                {
                    bundlesStatus = Icons.Error.Tooltip($"There was an error {(Status.HasFlag(BuildStatus.BundlesExist) ? "uploading" : "building")} this IFX.");
                }

                DrawStatusRow(bundlesStatus, Labels.Bundles);

                //---------

                if (Parent.ViewModel.MissingBuildModules)
                {
                    foreach (var platform in new EngagePlatform[] { EngagePlatform.Windows, EngagePlatform.Android, EngagePlatform.iOS, EngagePlatform.OSX })
                    {
                        DrawPlatformStatus(platform);
                    }

                    GUILayout.Space(20);

                    using (var errorText = new GuiTools.ColorScope(CreatorStyle.Red))
                    {
                        EditorGUILayout.LabelField(Labels.BuildModulesMissing);
                    }
                }
            }
        }

        /// <summary>
        /// Starting default Ifx state
        /// </summary>
        public class IfxStartState : IfxStatusPanel
        {
            public IfxStartState(IfxBuilderView parent) : base(parent)
            {
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Cancel), Parent.Close);
            }

            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => true;

            public override void NextState()
            {
                if (Status.HasFlag(BuildStatus.UnityAssetSelected))
                {
                    if (Parent.ViewModel.MissingBuildModules)
                    {
                        Parent.IfxBuildStatusPanel = new ErrorState(Parent);
                        return;
                    }

                    Parent.IfxBuildStatusPanel = new IfxBuildReadyState(Parent);
                }
                else
                {
                    Parent.IfxBuildStatusPanel = new IfxUpdateReadyState(Parent);
                }
            }

            public override void Update()
            {
                if (Status.HasFlag(BuildStatus.EngageAssetExists) || Status.HasFlag(BuildStatus.UnityAssetSelected))
                {
                    NextState();
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Status.HasFlag(BuildStatus.UnityAssetSelected) ? Icons.TestPassed : Icons.Error.Tooltip(Labels.PrefabNoneSelectedMessage), Labels.PrefabSelected);
                DrawStatusRow("", AssetLabel);
                DrawStatusRow("", Labels.ThumbnailUploaded);
                DrawStatusRow("", Labels.Bundles);
            }
        }

        /// <summary>
        /// State for starting update of existing Ifx with no Prefab asset selected.
        /// </summary>
        public class IfxUpdateReadyState : IfxStatusPanel
        {
            public IfxUpdateReadyState(IfxBuilderView parent) : base(parent)
            {
                DrawStartButton = DrawButton;
            }

            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => EngageUser.IsAuthenticated;

            protected bool isRebuild;
            public override void NextState() => Parent.IfxBuildStatusPanel = new UpdatingIfxState(Parent);

            public override void Update()
            {
                if (Status.HasFlag(BuildStatus.UnityAssetSelected) && !isRebuild)
                {
                    isRebuild = true;

                    if (Parent.ViewModel.MissingBuildModules)
                    {
                        Parent.IfxBuildStatusPanel = new ErrorState(Parent);
                        return;
                    }

                    DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Rebuild, Labels.RebuildAndUpdateIfxTooltip), Parent.ConfirmCreateIfx);
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Parent.ViewModel.Status.HasFlag(BuildStatus.UnityAssetSelected) ? Icons.TestPassed : Icons.Warning.Tooltip(Labels.RebuildIfxConditionTooltip), Labels.PrefabSelected);
                DrawStatusRow("", AssetLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow("", Labels.ThumbnailUploaded);
                }

                Parent.ViewModel.ReUploadRequested = DrawBundleStatus(Status.HasFlag(BuildStatus.UnityAssetSelected), Status.HasFlag(BuildStatus.BundlesExist), Parent.ViewModel.ReUploadRequested);
            }

            private void DrawButton() => GuiTools.DrawButton(GetButtonLabel(), Parent.CreateIfx);

            private GUIContent GetButtonLabel()
            {
                return Parent.ViewModel.ReUploadRequested && Status.HasFlag(BuildStatus.BundlesExist) ?
                    new GUIContent(Labels.ReUpload, Labels.ReUploadIfxTooltip)
                    : new GUIContent(Labels.Update, Labels.UpdateIfxTooltip);
            }
        }

        /// <summary>
        /// State for the update of existing IFX's details and optionally thumbnail.
        /// </summary>
        public class UpdatingIfxState : IfxStatusPanel
        {
            public UpdatingIfxState(IfxBuilderView parent) : base(parent)
            {
                DrawStartButton = Parent.ViewModel.ReUploadRequested ? () => GuiTools.DrawButton(new GUIContent(Labels.ReUpload), null)
                    : () => GuiTools.DrawButton(new GUIContent(Labels.Update), null);
            }

            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;

            public override void NextState() => Parent.IfxBuildStatusPanel = new UploadingThumbnailState(Parent);

            public override void Update()
            {
                if (Status.HasFlag(BuildStatus.EngageAssetUpdated))
                {
                    NextState();
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Status.HasFlag(BuildStatus.UnityAssetSelected) ? Icons.TestPassed : Icons.TestSkipped, Labels.PrefabSelected);
                DrawStatusRow(Status.HasFlag(BuildStatus.EngageAssetUpdated) ? Icons.TestPassed : Parent.GetSpinner(), AssetLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow("", Labels.ThumbnailUploaded);
                }

                DrawBundleStatus(Status.HasFlag(BuildStatus.UnityAssetSelected), Status.HasFlag(BuildStatus.BundlesExist), Parent.ViewModel.ReUploadRequested);
            }
        }

        /// <summary>
        /// Completed state for Update process.
        /// </summary>
        public class IfxUpdateCompleteState : IfxStatusPanel
        {
            public IfxUpdateCompleteState(IfxBuilderView parent) : base(parent)
            {
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Close), Parent.Close);
            }

            protected override bool SaveButtonEnabled => false;
            public override void NextState() { }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestSkipped, Labels.PrefabSelected);
                DrawStatusRow(Icons.TestPassed, AssetLabel);
                DrawStatusRow(Status.HasFlag(BuildStatus.ThumbnailUploaded) ? Icons.TestPassed : Icons.TestSkipped, Labels.ThumbnailUploaded);
                DrawStatusRow(Icons.TestSkipped, Labels.Bundles);
            }
        }

        /// <summary>
        /// State in which Prefab asset has been selected and the creation process is started.
        /// </summary>
        public class IfxBuildReadyState : IfxStatusPanel
        {
            public IfxBuildReadyState(IfxBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save, Labels.SaveTooltip), Parent.Save);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Build, BuildButtonTooltop), Parent.ConfirmCreateIfx);
            }

            protected override bool SaveButtonEnabled => true;
            protected override bool StartButtonEnabled => EngageUser.IsAuthenticated;
            protected string BuildButtonTooltop => StartButtonEnabled ? Labels.BuildIfxTooltip : Labels.LoginTooltip;

            public override void NextState() => Parent.IfxBuildStatusPanel = new CreatingIfxState(Parent);

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestPassed, Labels.PrefabSelected);
                DrawStatusRow("", AssetLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow("", Labels.ThumbnailUploaded);
                }

                DrawStatusRow("", Labels.Bundles);

                // NOTE: Batch Mode will be supported in a later release
                // Batch Build Mode
                //Parent.ViewModel.BatchBuild = EditorGUILayout.Toggle(new GUIContent(Labels.BatchBuildMode, Labels.BatchBuildTooltip), Parent.ViewModel.BatchBuild);
            }
        }

        /// <summary>
        /// State in which the IFX is created or updated.
        /// </summary>
        public class CreatingIfxState : IfxStatusPanel
        {
            public CreatingIfxState(IfxBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), null);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Build), null);
            }
            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;

            public override void NextState() => Parent.IfxBuildStatusPanel = new UploadingThumbnailState(Parent);

            public override void Update()
            {
                if (Parent.ViewModel.Status.HasFlag(BuildStatus.EngageAssetExists))
                {
                    NextState();
                }
                else if (Status.HasFlag(BuildStatus.EngageAssetError))
                {
                    Parent.IfxBuildStatusPanel = new ErrorState(Parent);
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestPassed, Labels.PrefabSelected);
                DrawStatusRow(Parent.GetSpinner(), AssetLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow("", Labels.ThumbnailUploaded);
                }

                DrawStatusRow("", Labels.Bundles);
            }
        }

        /// <summary>
        /// State in which the Thumbnail is uploaded.
        /// </summary>
        public class UploadingThumbnailState : IfxStatusPanel
        {
            public UploadingThumbnailState(IfxBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), null);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Build), null);
            }
            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;

            public override void NextState()
            {
                if (Status.HasFlag(BuildStatus.UnityAssetSelected))
                {
                    Parent.IfxBuildStatusPanel = new BuildingIfxBundlesState(Parent);
                    return;
                }

                if (Parent.ViewModel.ReUploadRequested && Status.HasFlag(BuildStatus.BundlesExist))
                {
                    Parent.IfxBuildStatusPanel = new IfxUploadReadyState(Parent);
                    return;
                }

                Parent.IfxBuildStatusPanel = new IfxUpdateCompleteState(Parent);
            }

            public override void Update()
            {
                if (!Status.HasFlag(BuildStatus.ThumbnailSelected))
                {
                    NextState();
                }

                if (Status.HasFlag(BuildStatus.ThumbnailUploaded)
                    || Status.HasFlag(BuildStatus.ThumbnailError)
                    )
                {
                    NextState();
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Status.HasFlag(BuildStatus.UnityAssetSelected) ? Icons.TestPassed : Icons.TestSkipped, Labels.PrefabSelected);
                DrawStatusRow(Icons.TestPassed, AssetLabel);

                using (var opPanel = new EditorGUILayout.HorizontalScope())
                {
                    DrawStatusRow(Parent.GetSpinner(), Labels.ThumbnailUploaded);

                    var progress = Parent.ViewModel.ThumbnailUploadProgress;

                    if (progress < 1)
                    {
                        var progressRect = new Rect(
                            opPanel.rect.x + progressBarOffset,
                            opPanel.rect.y,
                            Mathf.Max(opPanel.rect.width - progressBarOffset, retryButtonWidth),
                            opPanel.rect.height
                            );

                        EditorGUI.ProgressBar(progressRect, progress, $"{progress * 100:F0}%");
                    }
                }

                using (var prefabSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.UnityAssetSelected)))
                {
                    DrawStatusRow("", Labels.Bundles);
                }
            }

            public override void DrawButtons()
            {
                using (var actionsEnabled = new GuiTools.EnabledScope(false))
                {
                    base.DrawButtons();
                }
            }
        }

        /// <summary>
        /// State in which the Build status is displayed.
        /// </summary>
        public class BuildingIfxBundlesState : IfxStatusPanel
        {
            public BuildingIfxBundlesState(IfxBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), null);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Build), null);
            }
            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;

            public override void NextState()
            {
                Parent.IfxBuildStatusPanel = new IfxUploadReadyState(Parent);
            }

            public override void Update()
            {
                if (Parent.ViewModel.LocalFiles.Platforms == Parent.ViewModel.Job.BuildTargets)
                {
                    NextState();
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestPassed, Labels.PrefabSelected);
                DrawStatusRow(Icons.TestPassed, AssetLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow(Status.HasFlag(BuildStatus.ThumbnailUploaded) ? Icons.TestPassed : Icons.TestSkipped, Labels.ThumbnailUploaded);
                }

                DrawStatusRow(Parent.GetSpinner(), Labels.Bundles);

                foreach (var platform in new EngagePlatform[] { EngagePlatform.Windows, EngagePlatform.Android, EngagePlatform.iOS, EngagePlatform.OSX })
                {
                    DrawPlatformStatus(platform);
                }
            }

            public override void DrawPlatformStatus(EngagePlatform platform)
            {
                var icon = ViewTools.PlatformIcons[platform];

                bool built = Parent.ViewModel.LocalFiles?.ContainsKey(platform) ?? false;
                bool awaitingBuild = Parent.ViewModel.AwaitingBuild(platform);
                var status = new GUIContent();
                string processLabel = "";

                if (built)
                {
                    status = Icons.TestPassed;
                }
                else if (!awaitingBuild)
                {
                    status = Parent.GetSpinner();
                    processLabel = Labels.Building;
                }

                using (var platformPanel = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(new GUIContent(), GUILayout.Width(column1));
                    EditorGUILayout.LabelField(status, GUILayout.Width(column2));
                    EditorGUILayout.LabelField(icon, GUILayout.Width(column3));
                    EditorGUILayout.LabelField(processLabel, GUILayout.Width(processLabelWidth));
                }
            }
        }

        /// <summary>
        /// State in which the Upload status is evaluated.
        /// </summary>
        public class IfxUploadReadyState : IfxStatusPanel
        {
            public IfxUploadReadyState(IfxBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), null);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Build), null);
            }
            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;

            protected int bundleSizeThreshold = 150;
            protected bool cancelUpload;

            public override void NextState()
            {
                if (cancelUpload)
                {
                    Parent.IfxBuildStatusPanel = new ErrorState(Parent);
                    return;
                }

                Parent.ViewModel.StartUpload();
                Parent.IfxBuildStatusPanel = new UploadingIfxBundlesState(Parent);
            }

            public override void Update()
            {
                if (Status.HasFlag(BuildStatus.BundlesExist))
                {
                    if (Parent.ViewModel.MaxBundleFileSize > bundleSizeThreshold)
                    {
                        ConfirmUploadDialog.OpenDialog(
                            Parent,
                            Labels.LargeAssetSizeWarningTitle,
                            string.Format(Labels.LargeAssetSizeWarning, $"{bundleSizeThreshold} MB"),
                            Labels.LargeAssetSizeWarningConsequences,
                            Labels.GuidelinesMessage,
                            Labels.GuidelinesDocumentationLink,
                            NextState,
                            CancelUpload
                            );
                    }
                    else
                    {
                        NextState();
                    }
                }
            }

            protected void CancelUpload()
            {
                cancelUpload = true;
                NextState();
            }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestPassed, Labels.PrefabSelected);
                DrawStatusRow(Icons.TestPassed, AssetLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow(Status.HasFlag(BuildStatus.ThumbnailUploaded) ? Icons.TestPassed : Icons.TestSkipped, Labels.ThumbnailUploaded);
                }

                DrawStatusRow(Parent.GetSpinner(), Labels.Bundles);

                foreach (var platform in new EngagePlatform[] { EngagePlatform.Windows, EngagePlatform.Android, EngagePlatform.iOS, EngagePlatform.OSX })
                {
                    DrawPlatformStatus(platform);
                }
            }

            public override void DrawPlatformStatus(EngagePlatform platform)
            {
                var icon = ViewTools.PlatformIcons[platform];

                var status = new GUIContent();
                string processLabel = Labels.Uploading;

                using (var platformPanel = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(new GUIContent(), GUILayout.Width(column1));
                    EditorGUILayout.LabelField(status, GUILayout.Width(column2));
                    EditorGUILayout.LabelField(icon, GUILayout.Width(column3));
                    EditorGUILayout.LabelField(processLabel, GUILayout.Width(processLabelWidth));
                }
            }
        }

        /// <summary>
        /// State in which the Upload status is displayed.
        /// </summary>
        public class UploadingIfxBundlesState : IfxStatusPanel
        {
            public UploadingIfxBundlesState(IfxBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), null);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Build), null);

                IsRunning = true;
            }
            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;
            protected bool IsRunning { get; set; }

            public override void NextState() => Parent.IfxBuildStatusPanel = new CompleteState(Parent);

            public override void Update()
            {
                if (Parent.ViewModel.LocalFiles.Uploaded == (EngagePlatform.Windows | EngagePlatform.Android | EngagePlatform.iOS | EngagePlatform.OSX))// Parent.ViewModel.Job.BuildTargets)
                {
                    NextState();
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestPassed, Labels.PrefabSelected);
                DrawStatusRow(Icons.TestPassed, AssetLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow(Status.HasFlag(BuildStatus.ThumbnailUploaded) ? Icons.TestPassed : Icons.TestSkipped, Labels.ThumbnailUploaded);
                }

                IsRunning = Parent.ViewModel.LocalFiles.Any(bundle => bundle.Value.Status == Network.RequestStatus.Requesting);

                DrawStatusRow(Parent.GetSpinner(), Labels.Bundles);

                foreach (var platform in new EngagePlatform[] { EngagePlatform.Windows, EngagePlatform.Android, EngagePlatform.iOS, EngagePlatform.OSX })
                {
                    DrawPlatformStatus(platform);
                }
            }

            public override void DrawPlatformStatus(EngagePlatform platform)
            {
                var icon = ViewTools.PlatformIcons[platform];

                bool uploaded = false;
                float progress = 0;
                bool error = false;

                if (Parent.ViewModel.LocalFiles.TryGetValue(platform, out BundleFile bundle))
                {
                    uploaded = bundle.Uploaded;
                    progress = bundle.UploadProgress;
                    error = bundle.Status == Network.RequestStatus.Error;
                    IsRunning = bundle.Status == Network.RequestStatus.Requesting;
                }

                GUIContent testPassedIcon = Icons.TestPassed.Tooltip("Upload complete.");
                GUIContent errorIcon = Icons.Error.Tooltip("An error occurred during upload.");

                GUIContent status = uploaded ? testPassedIcon : error ? errorIcon : Parent.GetSpinner();
                string processLabel = !uploaded ? Labels.Uploading : Labels.Done;

                using (var uploadProgressPanel = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField("", GUILayout.Width(column1));
                    EditorGUILayout.LabelField(status, GUILayout.Width(column2));
                    EditorGUILayout.LabelField(icon, GUILayout.Width(column3));
                    EditorGUILayout.LabelField(processLabel, GUILayout.Width(processLabelWidth));

                    if (!uploaded && progress < 1)
                    {
                        var progressRect = new Rect(
                            uploadProgressPanel.rect.x + progressBarOffset,
                            uploadProgressPanel.rect.y,
                            Mathf.Max(uploadProgressPanel.rect.width - progressBarOffset, retryButtonWidth),
                            uploadProgressPanel.rect.height
                            );

                        using (var progressActive = new GuiTools.EnabledScope(!error))
                        {
                            EditorGUI.ProgressBar(progressRect, progress, $"{progress * 100:F0}%");
                        }

                        if (error)
                        {
                            var retryRect = new Rect(
                                Mathf.Max(
                                    uploadProgressPanel.rect.x + uploadProgressPanel.rect.width - (retryButtonWidth + rightPadding),
                                    retryButtonWidth + rightPadding
                                    ),
                                uploadProgressPanel.rect.y,
                                retryButtonWidth,
                                EditorGUIUtility.singleLineHeight
                                );

                            if (GUI.Button(retryRect, Labels.Retry))
                            {
                                Parent.ViewModel.Upload(platform);
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// State in which all processes are completed, and the window can then be closed.
        /// </summary>
        public class CompleteState : IfxStatusPanel
        {
            public CompleteState(IfxBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), null);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Close), Parent.Close);
            }
            protected override bool SaveButtonEnabled => false;

            public override void NextState() { }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestPassed, Labels.PrefabSelected);
                DrawStatusRow(Icons.TestPassed, AssetLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow(Status.HasFlag(BuildStatus.ThumbnailUploaded) ? Icons.TestPassed : Icons.TestSkipped, Labels.ThumbnailUploaded);
                }

                DrawStatusRow(Icons.TestPassed, Labels.Bundles);
            }
        }
    }
}