﻿using System.Collections.Generic;

namespace Engage.AssetManagement.Content
{
    // NOTE: This is a WIP concept

    public enum ProcessType
    {
        ProcessUnityAsset,
        CreateEngageAsset,
        UpdateEngageAsset,
        ThumbnailUpload,
        Build,
        Upload
    }

    public enum ProcessState
    {
        None,
        Ready,
        Skipped,
        Running,
        Complete,
        Error
    }

    public class EngageProcessStatus
    {
        public Dictionary<ProcessType, EngageProcess> Processes { get; } = new Dictionary<ProcessType, EngageProcess>();

        public bool AddProcess(ProcessType process)
        {
            if (Processes.ContainsKey(process))
            {
                return false;
            }

            Processes.Add(process, EngageProcess.Create(process));
            return true;
        }

        public ProcessState GetStatus(ProcessType processName)
        {
            if (Processes.TryGetValue(processName, out EngageProcess process))
            {
                return process.State;
            }

            return ProcessState.None;
        }
    }

    public class EngageProcess
    {
        public ProcessType Type { get; }
        public string Name { get; }
        public string Message { get; set; }
        public float Progress { get; set; }
        public ProcessState State { get; set; }

        protected EngageProcess(ProcessType type)
        {
            Type = type;
            Name = Type.ToString();
        }

        public static EngageProcess Create(ProcessType type)
        {
            return new EngageProcess(type);
        }
    }
}