﻿using Engage.UI.Editor;
using UnityEditor;
using UnityEngine;
using System.Text.RegularExpressions;

namespace Engage.AssetManagement.Content
{
    public static class Login
    {
        public static string ToMinuteString(this int mins) => $"{mins} {(mins == 1 ? "minute" : "minutes")}";

        public static void DrawLoginHeader(this IView view)
        {
            using (var header = new EditorGUILayout.VerticalScope(CreatorStyle.CreateStyle(background: CreatorStyle.DarkTone)))
            {
                if (EngageUser.IsAuthenticated)
                {
                    using (var userPanel = new EditorGUILayout.HorizontalScope())
                    {
                        EditorGUILayout.LabelField(Labels.EngageUser, EngageUser.ApiClient.Module<ApiClientAuthentication>().CurrentUser.Name, EditorStyles.boldLabel, GUILayout.ExpandWidth(true));
                        GuiTools.DrawButton(Labels.Logout, RequestLogout, GUILayout.Width(CreatorStyle.LONG_BUTTON_WIDTH));
                    }
                }
                else
                {
                    GUILayout.Box(ViewTools.ENGAGELogo, GUILayout.ExpandWidth(true));

                    if (!EngageUser.LastLoginRequestResponse.CredentialsAccepted)
                    {
                        EditorGUILayout.LabelField(Labels.LoginPrompt, EditorStyles.boldLabel);
                    }

                    GUILayout.Space(5);

                    if (EngageUser.Awaiting2FAValidation)
                    {
                        view.DrawLoginField2FAValidation();
                    }
                    else if (EngageUser.CurrentLoginType == UserLoginType.SSO)
                    {
                        view.DrawLoginFieldSSO();
                    }
                    else
                    {
                        view.DrawLoginFieldPassword();
                    }

                    GUILayout.Space(5);
                }
            }
        }

        private static void DrawLoginFieldPassword(this IView view)
        {
            EngageUser.UserName = EditorGUILayout.TextField(new GUIContent(Labels.UserName, Labels.UserNameTooltip), EngageUser.UserName);

            using (var passwordPanel = new EditorGUILayout.HorizontalScope())
            {
                if (EngageUser.UnmaskPassword)
                {
                    EngageUser.Password = EditorGUILayout.TextField(Labels.Password, EngageUser.Password);

                    if (GUILayout.Button(Icons.Visible, EditorStyles.label, GUILayout.Width(20), GUILayout.Height(EditorGUIUtility.singleLineHeight)))
                    {
                        EngageUser.UnmaskPassword = false;
                        GUI.FocusControl(null);
                    }
                }
                else
                {
                    EngageUser.Password = EditorGUILayout.PasswordField(Labels.Password, EngageUser.Password);

                    if (GUILayout.Button(Icons.NotVisible, EditorStyles.label, GUILayout.Width(20), GUILayout.Height(EditorGUIUtility.singleLineHeight)))
                    {
                        EngageUser.UnmaskPassword = true;
                        GUI.FocusControl(null);
                    }
                }
            }

            EngageUser.RememberCredentials = EditorGUILayout.Toggle(Labels.Remember, EngageUser.RememberCredentials);

            if (EngageUser.RequiresSso)
            {
                GUILayout.Space(EditorGUIUtility.singleLineHeight);

                using (var warningColor = new GuiTools.ColorScope(CreatorStyle.Red))
                {
                    EditorGUILayout.LabelField(Labels.SsoRequiredMessage);
                }
            }
            else if (EngageUser.AccountLocked(EngageUser.AccountLockType.Password))
            {
                GUILayout.Space(EditorGUIUtility.singleLineHeight);

                using (var warningColor = new GuiTools.ColorScope(CreatorStyle.Red))
                {
                    int timeRemaining = EngageUser.LockoutTimeRemaining(EngageUser.AccountLockType.Password);
                    EditorGUILayout.LabelField(string.Format(Labels.LoginTooManyFailedAttemptsMessage, timeRemaining.ToMinuteString()));
                }
            }
            else
            {
                GUILayout.Space(EditorGUIUtility.singleLineHeight * 2);
            }

            GuiTools.DrawButton(Labels.Login, RequestLogin, GUILayout.Width(CreatorStyle.EXTRALONG_BUTTON_WIDTH));

            GUILayout.Space(EditorGUIUtility.singleLineHeight);

            if (GUILayout.Button(Labels.LoginSSO, Styles.ClickableLabelBold))
            {
                ToggleSSO();
                view.UpdateView();
            }
        }

        private static void DrawLoginFieldSSO(this IView view)
        {
            EngageUser.UserName = EditorGUILayout.TextField(new GUIContent(Labels.UserName, Labels.UserNameTooltip), EngageUser.UserName);
            EngageUser.RememberCredentials = EditorGUILayout.Toggle(Labels.Remember, EngageUser.RememberCredentials);

            if (EngageUser.RequiresPassword)
            {
                GUILayout.Space(EditorGUIUtility.singleLineHeight);

                using (var warningColor = new GuiTools.ColorScope(CreatorStyle.Red))
                {
                    EditorGUILayout.LabelField(Labels.SsoNotAvailableMessage);
                }
            }
            else
            {
                GUILayout.Space(EditorGUIUtility.singleLineHeight * 2);
            }

            GuiTools.DrawButton(Labels.LoginSSO, RequestLogin, GUILayout.Width(CreatorStyle.EXTRALONG_BUTTON_WIDTH));

            GUILayout.Space(EditorGUIUtility.singleLineHeight);

            if (GUILayout.Button(Labels.LoginPassword, Styles.ClickableLabelBold))
            {
                TogglePassword();
                view.UpdateView();
            }
        }

        private static string validationString;

        private static void DrawLoginField2FAValidation(this IView view)
        {
            string hintMessage = EngageUser.ValidationCodeFormat == "SMS" ? Labels.Login2FASmsHintMessage : Labels.Login2FAAppHintMessage;

            EditorGUILayout.LabelField(hintMessage, EditorStyles.boldLabel);

            validationString = EditorGUILayout.TextField(new GUIContent(Labels.Login2FACodeInputLabel), validationString);

            if (validationString?.Length == 6 && int.TryParse(validationString, out int result))
            {
                EngageUser.ValidationCode = result;
            }
            else
            {
                EngageUser.ValidationCode = null;
            }

            if (EngageUser.ValidationCodeInvalid)
            {
                using (var warningColor = new GuiTools.ColorScope(CreatorStyle.Red))
                {
                    EditorGUILayout.LabelField(" ", Labels.Login2FAVerificationCodeInvalid);

                    if (EngageUser.AccountLocked(EngageUser.AccountLockType.ValidationCode))
                    {
                        int timeRemaining = EngageUser.LockoutTimeRemaining(EngageUser.AccountLockType.ValidationCode);
                        EditorGUILayout.LabelField(" ", string.Format(Labels.Login2FATooManyFailedAttempts, timeRemaining.ToMinuteString()));
                    }
                }

                GUILayout.Space(EditorGUIUtility.singleLineHeight);
            }
            else
            {
                GUILayout.Space(EditorGUIUtility.singleLineHeight * 2);
            }

            using (var recoverLink = new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField(Labels.Login2FADeviceInaccessible, GUILayout.Width(EditorGUIUtility.labelWidth));

                if (GUILayout.Button(Labels.Login2FAUserRecoveryCode, EditorStyles.linkLabel))
                {
                    Request2FARecovery();
                }
            }

            using (var recoverLink = new EditorGUILayout.HorizontalScope())
            {
                if (EngageUser.ValidationCodeFormat == "SMS")
                {
                    GuiTools.DrawButton(Labels.Resend, ResendCode, GUILayout.Width(CreatorStyle.EXTRALONG_BUTTON_WIDTH));
                }

                using (var validationEnabledPanel = new GuiTools.EnabledScope(EngageUser.ValidationCode.HasValue))
                {
                    GuiTools.DrawButton(Labels.Verify, view.RequestValidation, GUILayout.Width(CreatorStyle.EXTRALONG_BUTTON_WIDTH));
                }
            }

            GUILayout.Space(EditorGUIUtility.singleLineHeight);

            if (GUILayout.Button(Labels.Login2FAReturnToLoginLabel, Styles.ClickableLabelBold))
            {
                EngageUser.ResetAuthentication();
                view.UpdateView();
            }
        }

        private static async void ToggleSSO()
        {
            await EngageUser.RequestLoginTypes();

            EngageUser.CurrentLoginType = UserLoginType.SSO;
        }

        private static async void TogglePassword()
        {
            await EngageUser.RequestLoginTypes();

            EngageUser.CurrentLoginType = UserLoginType.NATIVE;
        }

        public static async void RequestLogin()
        {
            var success = await EngageUser.RequestLogin();

            if (!success)
            {
                if (EngageUser.LastLoginRequestResponse.Type == LoginResponseType.Awaiting2FASetup)
                {
                    Authentication2FASetupDialog.OpenDialog();
                }
                else
                {
                    AuthenticationFailedDialog.OpenDialog();
                }
            }
        }

        public static async void RequestLogout()
        {
            var success = await EngageUser.RequestLogout();

            if (success)
            {
                // Logout was successful
            }

            GUI.FocusControl(null);
        }

        public static async void RequestValidation(this IView view)
        {
            if (!EngageUser.ValidationCode.HasValue)
                return;

            var success = await EngageUser.Submit2FACode(EngageUser.ValidationCode.Value);

            GUI.FocusControl(null);
            view.UpdateView();
        }

        public static void ResendCode()
        {
            EngageUser.ResendSMSCode();
        }

        public static void Request2FARecovery()
        {
            Authentication2FARecoveryDialog.OpenDialog();
            GUIUtility.ExitGUI();
        }
    }
}
