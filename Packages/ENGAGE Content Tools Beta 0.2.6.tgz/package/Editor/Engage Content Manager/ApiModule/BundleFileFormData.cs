﻿using Engage.Network;

namespace Engage.AssetManagement.Content
{
    public class BundleFileFormData : FormData
    {
        public enum AssetType
        {
            Mixed = -1,
            Undefined = 0,
            Location = 1,
            IFX = 2,
            Snapshot
        }

        public enum Platform
        {
            Undefined = 0,
            Android = 1,
            Windows = 2,
            iOS = 3,
            macOS = 4,
        }

        public const string PlatformKey = "platform";

        public void AddPlatformSection(Platform platform) => AddText(PlatformKey, $"{platform}");

        public static BundleFileFormData Create(Platform platform, string bundlePath, string manifestPath)
        {
            var bundlePackage = new BundleFileFormData();
            bundlePackage.AddPlatformSection(platform);
            bundlePackage.AddFile(bundlePath);
            bundlePackage.AddFile(manifestPath);

            return bundlePackage;
        }
    }
}