﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace Engage.AssetManagement.Content
{
    public interface IAsset : IEngageItem, INamedItem
    {
        [JsonProperty("unity_resource_name", Required = Required.Always)]
        string UnityResourceName { get; }

        [JsonProperty("pretty_name", Required = Required.Always)]
        Glossary PrettyName { get; }

        [JsonProperty("description", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        Glossary Description { get; }

        [JsonProperty("bundle_id", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        int? BundleId { get; }

        [JsonProperty("image", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        string Image { get; }

        [JsonProperty("tags", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        List<IAssetTag> Tags { get; }

        [JsonProperty("collections", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        List<IAssetCollection> Collections { get; }

        [JsonProperty("groups", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        List<IGroup> Groups { get; }

        [JsonProperty("bundles", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        List<IAssetBundle> Bundles { get; }
    }
}