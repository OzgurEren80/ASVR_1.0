﻿using Newtonsoft.Json;

namespace Engage.AssetManagement.Content
{
    public interface IAssetBundle
    {
        [JsonProperty("id", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        int? Id { get; }

        [JsonProperty("name", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        string Name { get; }

        [JsonProperty("platform", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        BundleFileFormData.Platform Platform { get; }
    }
}