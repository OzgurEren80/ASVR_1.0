using Newtonsoft.Json;
using System.Collections.Generic;

namespace Engage.AssetManagement.Content
{
    public enum UserLoginType
    {
        NATIVE,
        SSO,
        HYBRID,
        TWO_FACTOR_SETUP_REQUIRED,
        TWO_FACTOR_SETUP_DONE
    }

    public class UserLoginTypes
    {
        [JsonProperty("login_type", Required = Required.Always)]
        public List<UserLoginType> LoginTypes { get; set; }

        [JsonProperty("credentials", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        public string Credentials { get; set; }

        [JsonProperty("sso_enforced_by", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        public PolicyGroup Group { get; set; }

        public static UserLoginTypes GetDefault()
        {
            var types = new UserLoginTypes()
            {
                LoginTypes = new List<UserLoginType>() { UserLoginType.NATIVE }
            };

            return types;
        }

        public bool RequiresSso => LoginTypes != null && LoginTypes.Count == 1 && LoginTypes.Contains(UserLoginType.SSO);
        public bool RequiresPassword => LoginTypes != null && LoginTypes.Count == 1 && LoginTypes.Contains(UserLoginType.NATIVE);
        public bool Requires2FASetup => LoginTypes?.Contains(UserLoginType.TWO_FACTOR_SETUP_REQUIRED) ?? false;
        public bool Requires2FA => LoginTypes?.Contains(UserLoginType.TWO_FACTOR_SETUP_DONE) ?? false;
    }

    public class PolicyGroup
    {
        [JsonProperty("group_id", Required = Required.Always)]
        public int Id { get; set; }

        [JsonProperty("group_name", Required = Required.Always)]
        public string Name { get; set; }
    }
}
