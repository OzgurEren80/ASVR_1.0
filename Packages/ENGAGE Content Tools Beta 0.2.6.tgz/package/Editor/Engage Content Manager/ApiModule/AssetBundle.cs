﻿namespace Engage.AssetManagement.Content
{
    public class AssetBundle : IAssetBundle
    {
        public int? Id { get; set; }

        public string Name { get; set; }

        public BundleFileFormData.Platform Platform { get; set; }
    }
}
