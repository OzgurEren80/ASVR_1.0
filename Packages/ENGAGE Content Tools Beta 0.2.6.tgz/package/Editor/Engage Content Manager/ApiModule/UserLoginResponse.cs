﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;

namespace Engage.AssetManagement.Content
{
    public enum LoginResponseType
    {
        None,
        Unauthorized,
        AccountTempLocked,
        Success,
        Awaiting2FASetup,
        Awaiting2FACode,
        Invalid2FACode
    }

    public struct LoginResponseDetails
    {
        [JsonProperty("message", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        public string Message { get; private set; }

        [JsonProperty("code", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        public string Code { get; private set; }

        [JsonProperty("enforced_by_group", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        public Group PolicyGroup { get; private set; }

        [JsonProperty("time_left", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        public int TimeLeft { get; private set; }

        [JsonProperty("limited_access_token", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        public string LimitedAccessToken { get; private set; }

        public HttpStatusCode HttpCode { get; private set; }
        public string RawText { get; private set; }

        public static LoginResponseDetails ParseResponseDetails(int httpCode, string json)
        {
            if (string.IsNullOrEmpty(json))
            {
                return new LoginResponseDetails()
                {
                    HttpCode = (HttpStatusCode)httpCode,
                    RawText = json
                };
            }

            try
            {
                JsonSerializerSettings settings = new JsonSerializerSettings
                {
                    NullValueHandling = NullValueHandling.Ignore,
                    MissingMemberHandling = MissingMemberHandling.Ignore
                };

                var result = JsonConvert.DeserializeObject<LoginResponseDetails>(json, settings);
                result.HttpCode = (HttpStatusCode)httpCode;
                result.RawText = json;

                return result;
            }
            catch (JsonReaderException ex)
            {
                return new LoginResponseDetails()
                {
                    HttpCode = (HttpStatusCode)httpCode,
                    Message = ex.Message,
                    RawText = json
                };
            }
        }
    }

    public struct LoginResponse
    {
        public bool CredentialsAccepted { get; }
        public LoginResponseType Type { get; }
        public DateTime Timestamp { get; }
        public LoginResponseDetails Details { get; }

        private LoginResponse(bool loginSuccessful, LoginResponseType type, LoginResponseDetails details = default)
        {
            CredentialsAccepted = loginSuccessful;
            Type = type;
            Timestamp = DateTime.Now;
            Details = details;
        }

        public static LoginResponse None()
        {
            return new LoginResponse(false, LoginResponseType.None);
        }

        public static LoginResponse Success()
        {
            return new LoginResponse(true, LoginResponseType.Success);
        }

        public static LoginResponse Unauthorized(LoginResponseDetails details = default)
        {
            return new LoginResponse(false, LoginResponseType.Unauthorized);
        }

        public static LoginResponse AccountTempLocked(LoginResponseDetails details)
        {
            return new LoginResponse(false, LoginResponseType.AccountTempLocked, details);
        }

        public static LoginResponse Awaiting2FASetup(LoginResponseDetails details)
        {
            return new LoginResponse(false, LoginResponseType.Awaiting2FASetup, details);
        }

        public static LoginResponse Awaiting2FAValidation(LoginResponseDetails details)
        {
            return new LoginResponse(true, LoginResponseType.Awaiting2FACode, details);
        }

        public static LoginResponse Invalid2FACode(LoginResponseDetails details = default)
        {
            return new LoginResponse(true, LoginResponseType.Invalid2FACode, details);
        }
    }
}
