﻿using Engage.Network;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using UnityEditor;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    public class ApiClientAuthentication : Network.ApiClientAuthentication
    {
        public struct LoginRequest
        {
            //public string email;
            public string username;
            public string password;
            public string grant_type;
            public string scope;
            public string refresh_token;

            public static LoginRequest CreateLoginRequest(string user, string pwd)
            {
                return new LoginRequest()
                {
                    username = user,
                    password = pwd,
                    grant_type = "password",
                    scope = "general-user",
                    refresh_token = ""
                };
            }

            public static LoginRequest CreateRefreshRequest(string user, string token)
            {
                return new LoginRequest()
                {
                    username = user,
                    grant_type = "refresh_token",
                    scope = "general-user",
                    refresh_token = token
                };
            }
        }

        public struct VerificationRequest
        {
            public string code;
            public string application;
            public string verification_type;

            public static VerificationRequest CreateVerificationRequest(int code, string type)
            {
                return new VerificationRequest()
                {
                    code = $"{code:000000}",
                    application = "cms-sdk",
                    verification_type = type
                };
            }
        }

        public struct RecoveryRequest
        {
            public string recovery_code;
            public string source;
            public string application;
            public string engage_release_version;

            public static RecoveryRequest CreateRecoveryRequest(string code)
            {
                return new RecoveryRequest()
                {
                    recovery_code = code,
                    source = "ExtSDK",
                    application = "cms-sdk",
                    engage_release_version = "0.2.6"
                };
            }
        }

        public override IUser CurrentUser
        {
            get
            {
                if (currentUser == null)
                {
                    currentUser = new UserDetails("");
                }

                return currentUser;
            }
        }

        private class Credentials
        {
            public Token Token { get; }
            public UserDetails User { get; }

            public Credentials(UserDetails user, Token token)
            {
                User = user;
                Token = token;
            }
        }

        private const string app = "sdk";
        private readonly char[] Padding = { '=' };

        private const string loginType = "api/user/login_type";
        private const string loginSSO = "api/user/sso/";
        private const string loginNotify = "api/user/sso/login_notify";

        public Uri AuthDomain => ApiClient?.Host.AuthDomain;

        public override Uri LoginUrl => new Uri(AuthDomain, "oauth/token");
        public override Uri LogoutUrl => new Uri(AuthDomain, "api/user/me/logout");

        public Uri Submit2FAVerificationCodeUrl => new Uri(AuthDomain, "oauth/2fa/verify");
        public Uri Submit2FARecoveryCodeUrl => new Uri(AuthDomain, "oauth/2fa/recovery/token");
        public Uri Resend2FASMSCodeUrl => new Uri(AuthDomain, "oauth/2fa/sms/resend");

        public Uri LoginTypeUrl() => new Uri(AuthDomain, loginType);
        public Uri SSOLoginUrl(string userName, string credentials)
        {
            {
                var request = new UriBuilder(AuthDomain.AbsoluteUri + loginSSO + userName);

                var query = new string[]
                {
                    "source=" + Base64UrlEncoded(app),
                    "source_path=" + Base64UrlEncoded(AuthDomain.AbsoluteUri),
                    "credentials=" + credentials,
                    "machine_id=" + Base64UrlEncoded(SystemInfo.deviceUniqueIdentifier)
                };

                request.Query = string.Join('&', query);

                return request.Uri;
            }
        }
        public Uri SSOLoginResultUrl() => new Uri(AuthDomain, loginNotify);

        private AuthenticationState? authenticationStatus;
        public override AuthenticationState AuthenticationStatus
        {
            get
            {
                if (!authenticationStatus.HasValue)
                {
                    authenticationStatus = EditorPrefs.HasKey(Keys.rememberedUserKey) ? AuthenticationState.Requesting : AuthenticationState.Unauthenticated;
                    RequestRefresh();
                }

                return authenticationStatus.Value;
            }
            protected set
            {
                if (authenticationStatus != value)
                {
                    authenticationStatus = value;
                    OnAuthenticationStateChanged?.Invoke(authenticationStatus.Value);
                }
            }
        }


        public ApiClientAuthentication(ApiClient client) : base(client)
        {
            var hostData = File.ReadAllText("Packages/com.engagexr.content-manager/Host.json");

            client.Host = JsonConvert.DeserializeObject<Host>(hostData);
        }

        private static class Keys
        {
            public const string rememberedUserKey = "RememberedUserKey";
        }

        private string Base64UrlEncoded(string param)
        {
            byte[] bytesToEncode = Encoding.UTF8.GetBytes(param);
            return Convert.ToBase64String(bytesToEncode).TrimEnd(Padding).Replace('+', '-').Replace('/', '_');
        }

        public void SaveCredentials()
        {
            var credentials = new Credentials(CurrentUser as UserDetails, token as Token);
            var json = JsonConvert.SerializeObject(credentials);
            var encrypted = EncryptionTool.Encrypt(json, EncryptionKey);

            EditorPrefs.SetString(Keys.rememberedUserKey, encrypted);
        }

        public void ForgetCredentials()
        {
            EditorPrefs.DeleteKey(Keys.rememberedUserKey);
        }

        public override void ClearCredentials()
        {
            base.ClearCredentials();
            ForgetCredentials();
        }

        public bool RestoreCredentials()
        {
            if (!EditorPrefs.HasKey(Keys.rememberedUserKey))
                return false;

            try
            {
                var encrypted = EditorPrefs.GetString(Keys.rememberedUserKey);
                var json = EncryptionTool.Decrypt(encrypted, EncryptionKey);
                var credentials = JsonConvert.DeserializeObject<Credentials>(json);

                if (credentials != null)
                {
                    currentUser = credentials.User;
                    token = credentials.Token;
                }

            }
            catch (Exception e)
            {
                Debug.LogError($"[{nameof(ApiClient)}] Unexpected Request Error: {e}");
                return false;
            }

            return true;
        }

        public WebRequestBody GetUsernameBody(string email)
        {
            var user = new { username = email };
            var json = JsonConvert.SerializeObject(user);
            return WebRequestBody.GetRequestBody(json);
        }

        public class SsoId
        {
            public string scope = "general-user";
            public string grant_type = "sso_callback_token";
            public string id;
            public string error;
        }

        public WebRequestBody GetSSOTokenRequestBody(SsoId guid)
        {
            var json = JsonConvert.SerializeObject(guid);

            return WebRequestBody.GetRequestBody(json);
        }

        protected override WebRequestBody CreateLoginRequestBody(IUser user, string password)
        {
            var loginRequest = LoginRequest.CreateLoginRequest(user.Name, password);
            var loginJson = JsonConvert.SerializeObject(loginRequest);
            return WebRequestBody.GetRequestBody(loginJson);
        }

        protected WebRequestBody CreateRefreshRequestBody(IUser user, string token)
        {
            var loginRequest = LoginRequest.CreateRefreshRequest(user.Name, token);
            var loginJson = JsonConvert.SerializeObject(loginRequest);
            return WebRequestBody.GetRequestBody(loginJson);
        }

        public virtual async Task<UserLoginTypes> RequestLoginTypes(string user)
        {
            var loginTypes = UserLoginTypes.GetDefault();
            var requestBody = GetUsernameBody(user);

            try
            {
                var response = await AsyncRestClient.SendRequest<UserLoginTypes>(LoginTypeUrl(), Request.Post, body: requestBody);

                if (response.IsSuccess)
                {
                    loginTypes = response.Result;
                }
            }
            catch (Exception e)
            {
                AuthenticationStatus = AuthenticationState.Error;
                Debug.LogError($"[{nameof(ApiClient)}] Unexpected Request Error: {e}");
            }

            return loginTypes;
        }

        // TODO: indicating cancellable wait for external authentication in View
        public async Task<LoginResponse> RequestSSOLogin(IUser user, string credentials)
        {
            currentUser = user;

            var ssoLoginUrl = SSOLoginUrl(user.Name, credentials);
            Application.OpenURL(ssoLoginUrl.AbsoluteUri);

            using (var cancellationTokenSource = new CancellationTokenSource(TimeSpan.FromMinutes(5)))
            {
                try
                {
                    var credentialsJson = JsonConvert.SerializeObject(
                        new {
                            credentials,
                            machine_id = SystemInfo.deviceUniqueIdentifier
                        });
                    var credentialsBody = WebRequestBody.GetRequestBody(credentialsJson);

                    var loginResult = await AsyncRestClient.SendRequest(SSOLoginResultUrl(), Request.Post, null, credentialsBody, cancellationTokenSource.Token);

                    if (!loginResult.IsSuccess)
                    {
                        AuthenticationStatus = AuthenticationState.Rejected;
                        var details = LoginResponseDetails.ParseResponseDetails(loginResult.Code, loginResult.Error.RawText);
                        return LoginResponse.Unauthorized(details);
                    }

                    var id = JsonConvert.DeserializeObject<SsoId>(loginResult.ResultText);

                    var requestBody = GetSSOTokenRequestBody(id);
                    var response = await AsyncRestClient.SendRequest<Token>(LoginUrl, Request.Post, null, requestBody);

                    if (!response.IsSuccess || response.Result is null)
                    {
                        AuthenticationStatus = AuthenticationState.Rejected;
                        var details = LoginResponseDetails.ParseResponseDetails(response.Code, response.ResultText);
                        return LoginResponse.Unauthorized(details);
                    }

                    token = response.Result;
                    AuthenticationStatus = AuthenticationState.Authenticated;

                    return LoginResponse.Success();
                }
                catch (Exception e)
                {
                    AuthenticationStatus = AuthenticationState.Error;
                    Debug.LogError($"[{nameof(ApiClient)}] Unexpected Request Error: {e}");

                    return LoginResponse.Unauthorized();
                }
            }
        }

        public new async Task<LoginResponse> RequestLogin(IUser user, string password)
        {
            currentUser = user;

            var requestBody = CreateLoginRequestBody(user, password);

            try
            {
                var response = await AsyncRestClient.SendRequest<Token>(LoginUrl, Request.Post, body: requestBody);

                var details = LoginResponseDetails.ParseResponseDetails(response.Code, response.ResultText);

                if (!response.IsSuccess)
                {
                    AuthenticationStatus = AuthenticationState.Rejected;

                    details = LoginResponseDetails.ParseResponseDetails(response.Code, response.Error.RawText);

                    if (details.HttpCode == System.Net.HttpStatusCode.TooManyRequests)
                    {
                        return LoginResponse.AccountTempLocked(details);
                    }

                    if (details.HttpCode == System.Net.HttpStatusCode.UnprocessableEntity)
                    {
                        AuthenticationStatus = AuthenticationState.Unauthenticated;
                        return LoginResponse.Awaiting2FASetup(details);
                    }

                    return LoginResponse.Unauthorized(details);
                }
                else if (details.HttpCode == System.Net.HttpStatusCode.Accepted)
                {
                    AuthenticationStatus = AuthenticationState.Unauthenticated;

                    if (string.IsNullOrEmpty(details.LimitedAccessToken))
                    {
                        return LoginResponse.Awaiting2FASetup(details);
                    }

                    token = new Token() { AccessToken = details.LimitedAccessToken };
                    return LoginResponse.Awaiting2FAValidation(details);
                }

                token = response.Result;
                AuthenticationStatus = AuthenticationState.Authenticated;

                return LoginResponse.Success();
            }
            catch (Exception e)
            {
                AuthenticationStatus = AuthenticationState.Error;
                Debug.LogError($"[{nameof(ApiClient)}] Unexpected Request Error: {e}");

                return LoginResponse.Unauthorized();
            }
        }

        public override async Task<bool> RequestRefresh()
        {
            try
            {
                if (!RestoreCredentials())
                {
                    AuthenticationStatus = AuthenticationState.Unauthenticated;
                    return false;
                }

                var refreshToken = token as Token;

                var requestBody = CreateRefreshRequestBody(currentUser, refreshToken?.RefreshToken);

                var response = await AsyncRestClient.SendRequest<Token>(LoginUrl, Request.Post, body: requestBody);

                if (!response.IsSuccess)
                {
                    AuthenticationStatus = AuthenticationState.Rejected;
                    return false;
                }

                token = response.Result;
                AuthenticationStatus = AuthenticationState.Authenticated;
            }
            catch (Exception e)
            {
                AuthenticationStatus = AuthenticationState.Error;
                Debug.LogError($"[{nameof(ApiClient)}] Unexpected Request Error: {e}");

                return false;
            }

            return true;
        }

        public override async Task<bool> RequestLogout()
        {
            try
            {
                var response = await AsyncRestClient.SendRequest(LogoutUrl, Request.Post, token?.AccessToken);

                if (!response.IsSuccess)
                {
                    AuthenticationStatus = AuthenticationState.Error;
                    return false;
                }

                ClearCredentials();
                AuthenticationStatus = AuthenticationState.Unauthenticated;
            }
            catch (Exception e)
            {
                AuthenticationStatus = AuthenticationState.Error;
                Debug.LogError($"[{nameof(ApiClient)}] Unexpected Request Error: {e}");

                return false;
            }

            return true;
        }

        public async void RequestResend2FASMSCode()
        {
            try
            {
                var response = await AsyncRestClient.SendRequest(Resend2FASMSCodeUrl, Request.Post, token?.AccessToken);
            }
            catch (Exception ex)
            {

            }
        }

        public async Task<LoginResponse> Request2FAVerification(int code, string type)
        {
            VerificationRequest verificationRequest = VerificationRequest.CreateVerificationRequest(code, type);

            try
            {
                var verificationJson = JsonConvert.SerializeObject(verificationRequest);
                var body =  WebRequestBody.GetRequestBody(verificationJson);

                var response = await AsyncRestClient.SendRequest<Token>(Submit2FAVerificationCodeUrl, Request.Post, token?.AccessToken, body);

                if (response.IsSuccess)
                {
                    token = response.Result;
                    AuthenticationStatus = AuthenticationState.Authenticated;
                    return LoginResponse.Success();
                }
                else
                {
                    var details = LoginResponseDetails.ParseResponseDetails(response.Code, response.Error.RawText);

                    if (details.HttpCode == System.Net.HttpStatusCode.TooManyRequests)
                    {
                        return LoginResponse.AccountTempLocked(details);
                    }

                    return LoginResponse.Invalid2FACode(details);
                }
            }
            catch (Exception e)
            {
            }

            return LoginResponse.Invalid2FACode();
        }

        public async Task<LoginResponse> Request2FARecovery(string code)
        {
            RecoveryRequest recoveryRequest = RecoveryRequest.CreateRecoveryRequest(code);

            try
            {
                var recoveryJson = JsonConvert.SerializeObject(recoveryRequest);
                var body = WebRequestBody.GetRequestBody(recoveryJson);

                var response = await AsyncRestClient.SendRequest<Token>(Submit2FARecoveryCodeUrl, Request.Post, token?.AccessToken, body);

                if (response.IsSuccess)
                {
                    token = response.Result;
                    AuthenticationStatus = AuthenticationState.Authenticated;
                    return LoginResponse.Success();
                }
                else
                {
                    var details = LoginResponseDetails.ParseResponseDetails(response.Code, response.Error.RawText);

                    if (details.HttpCode == System.Net.HttpStatusCode.TooManyRequests)
                    {
                        return LoginResponse.AccountTempLocked(details);
                    }

                    return LoginResponse.Invalid2FACode(details);
                }
            }
            catch (Exception e)
            {

            }

            return LoginResponse.Invalid2FACode();
        }
    }
}
