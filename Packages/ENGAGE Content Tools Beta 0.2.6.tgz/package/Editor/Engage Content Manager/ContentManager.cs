﻿using Engage.UI.Editor;
using UnityEditor;

namespace Engage.AssetManagement.Content
{
    public class ContentManager
    {
        public const string Company = "EngageXR";
        public const string Title =  "ENGAGE Content Manager";
        public const string Version = "0.2.6";

        [MenuItem(MenuLabels.EngageAssetManagementPath + "About " + Title, priority = MenuLabels.VersionViewPriority)]
        public static void DisplayVersion()
        {
            EditorUtility.DisplayDialog(Company, $"{Title}\n\nVersion: {Version}", "OK");
        }
    }
}