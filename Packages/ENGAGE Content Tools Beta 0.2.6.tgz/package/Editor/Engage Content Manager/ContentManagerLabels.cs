﻿using Engage.Network;
using System.Collections.Generic;

namespace Engage.AssetManagement.Content
{
    public class Labels
    {
        public const string CreateButton = "Create";
        public const string CreateSelectedButton = "Create Selected";
        public const string CreateAllButton = "Create All";

        public const string NotAuthenticated = "User not currently authenticated";
        public const string LoginPrompt = "Log in with your authorized ENGAGE account";

        public const string UserName = "Username";
        public const string UserNameTooltip = "Username or email";
        public const string Password = "Password";
        public const string Login = "Log in";
        public const string Logout = "Log out";
        public const string EngageUser = "User";
        public const string Remember = "Remember me";

        public const string SsoEmailMismatchMessage = "We were unable to authenticate your SSO login due to an email mismatch between your ENGAGE account and the SSO identity provider";
        public const string SsoRequiredMessage = "This account requires you to use single sign-on (SSO)";
        public const string SsoNotAvailableMessage = "This account doesn't use single sign-on (SSO)";
        public const string SsoAuthenticationFailedMessage = "We were unable to authenticate you with your SSO identity provider";

        public const string Select = "Select";
        public const string Id = "ID";
        public const string Name = "Name";
        public const string PrettyName = "Pretty Name";
        public const string Project = "Project";
        public const string AssetType = "Asset Type";
        public const string Created = "Created On";
        public const string Updated = "Last Updated";
        public const string Ifx = "IFX";
        public const string Location = "Location";
        public const string AssetTarget = "Target";
        public const string LocalFiles = "Local Files";
        public const string Status = "Status";
        public const string Thumbnail = "Thumbnail";
        public const string Description = "Description";
        public const string Category = "Category";
        public const string SortOrder = "Sort Order";
        public const string Parameters = "Parameters";
        public const string IsPrivate = "Privacy";
        public const string IsPremium = "Premium";
        public const string EditorOnly = "Editor Only";
        public const string Unlisted = "Unlisted";
        public const string AssetStatus = "Asset Status";
        public const string Scale = "Scale";
        public const string SceneScale = "Scene Scale";
        public const string BaseLocation = "Base Location";
        public const string BrandingGroup = "Branding Group";

        public const string OK = "OK";
        public const string Confirm = "Confirm";
        public const string CancelUpload = "Cancel Upload";
        public const string Yes = "Yes";
        public const string No = "No";
        public const string Close = "Close";
        public const string Cancel = "Cancel";
        public const string Clear = "Clear";
        public const string Edit = "Edit";
        public const string Manage = "Manage";
        public const string Refresh = "Refresh";
        public const string SetDefault = "Set Default";

        public const string Create = "Create";
        public const string Update = "Update";
        public const string Delete = "Delete";
        public const string UploadAll = "Upload All";
        public const string Upload = "Upload";
        public const string Uploaded = "Uploaded";
        public const string Retry = "Retry";
        public const string Resend = "Resend";
        public const string Verify = "Verify";

        public const string RefreshFromServer = "Refresh From Server";
        public const string LastRefresh = "Last Refresh";
        public const string DataStale = "Data last refreshed over a day ago. Please log in to refresh.";
        public const string NoLastRefreshValue = "???";

        public const string ChangeBundleConfirm = "Change Bundle Association";
        public const string ChangeBundleConfirmMessage = "Are you sure you want to change the Bundle this asset is associated with?";

        public const string IfxExplanation = "These are the IFX entries associated with this Bundle";
        public const string LocalFileExplanation = "These are the local bundle files associated with this Bundle and their contents";
        public const string LocationExplanation = "These are the Location entries associated with this Bundle";
        public const string RefreshFilesTooltip = "Refresh local file information";

        public const string ProjectDoesntExist = "Project [{0}] does not yet exist in Database";
        public const string BundleDoesntExist = "Bundle [{0}] does not yet exist in Database";
        public const string EntityNameProblem = "Name contains illegal characters";

        public const string BundleProblemMixed = "Asset Bundle contains mixed asset types";
        public const string BundleProblemName = "Asset Bundle contains asset name with illegal characters";
        public const string BundleProblemEmpty = "Asset Bundle is empty or unreadable";
        public const string BundleProblemUnbuilt = "There is no Asset Bundle file present";

        // AssetBuilder
        public const string EmptySelection = "--";

        public const string BatchBuildMode = "Batch Build Mode";
        public const string BatchBuildTooltip = "Batch build mode will create duplicate copies of the project and run the bundle build process in parallel";
        public const string LocalBuildPath = "Local Build Path";
        public const string BuildModulesMissing = "Unity Editor is missing platform modules required for creating a complete Engage Location.";
        public const string BuildModuleNotInstalledMessage = "Module is not installed";

        public const string Save = "Save";
        public const string ThumbnailSelectTitle = "Select Thumbnail Image";
        public const string ThumbnailSelectTooltip = "Select thumbnail image";
        public const string ThumbnailSpecification = "Thumbnail images should be jpeg\nor png, and 750 x 500 pixels.";

        public const string ThumbnailSizeWarningTitle = "Thumbnail Size Warning";
        public const string ThumbnailSizeWarning = "Thumbnail size does not match required dimensions.";
        public const string ThumbnailWarningConsequences = "Thumbnail images should be jpeg or png, and 750 x 500 pixels";

        public const string Bundles = "Bundles uploaded";
        public const string ThumbnailUploaded = "Thumbnail uploaded";
        public const string LoginTooltip = "You must log in with your authorized ENGAGE User account.";

        public const string Building = "Building...";
        public const string Uploading = "Uploading...";
        public const string Error = "Error";
        public const string Done = "Done";

        public const string Publish = "Publish";
        public const string ReUpload = "Re-upload";

        public const string LargeAssetSizeWarningTitle = "Large Asset Size Warning";
        public const string LargeAssetSizeWarning = "One or more of these asset bundles is larger than {0}.";
        public const string LargeAssetSizeWarningConsequences = "This may cause performance issues for users on some devices. Your upload may also fail unless you have a fast network connection.";

        public const string LoginSSO = "Log in using SSO";
        public const string LoginPassword = "Log in using password";

        public const string LoginTooManyFailedAttemptsMessage = "Too many failed log-in attempts. Please reset your password or wait for {0} and try again.";

        public const string Login2FAAppHintMessage = "Enter the 6-digit code shown in your authentication app.";
        public const string Login2FASmsHintMessage = "Enter the 6-digit code we've just sent to your phone.";
        public const string Login2FACodeInputLabel = "Enter code";
        public const string Login2FADeviceInaccessible = "Can't access your device?";
        public const string Login2FAUserRecoveryCode = "Use recovery code";

        public const string Login2FAReturnToLoginLabel = "Return to log-in";

        public const string Login2FAVerificationCodeInvalid = "The verification code you entered is invalid.";
        public const string Login2FATooManyFailedAttempts = "You have made too many failed attempts. Please wait {0} before attempting again.";


        // ------------

        public const string SyncStatusLocal = "This item only exists locally";
        public const string SyncStatusUncommittedChanges = "The item has uncommitted changes";
        public const string SyncStatusSynced = "This item is fully synced";
        public const string SyncStatusRemote = "This item has no local files";

        public static Dictionary<SyncStatus, string> SyncStatusDescription = new Dictionary<SyncStatus, string>()
        {
            { SyncStatus.None, string.Empty },
            { SyncStatus.Local, SyncStatusLocal },
            { SyncStatus.UncommittedChanges, SyncStatusUncommittedChanges },
            { SyncStatus.Synced, SyncStatusSynced },
            { SyncStatus.Remote, SyncStatusRemote }
        };

        /* ICONS */
        public const string Checkbox = "☑";
        public const string XButton = "✕";
        public const string Ellipsis = "⋯";
        public const string Plus = "＋";
    }
}