﻿using Engage.UI.Editor;
using UnityEditor;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    public class Authentication2FARecoveryDialog : EngageConfirmDialog<EngageUser>
    {
        public class Labels : Content.Labels
        {
            public const string Login2FARecoveryTitle = "Two-Factor Authentication (2FA)";
            public const string Login2FARecoveryMessage = "Use one of the recovery codes that were provided when you set up 2FA.";

            public const string Login2FAInputMessage = "Enter your recovery code";

            public const string Login2FARecoveryInvalidCodeMessage = "The recovery code you entered is invalid or has already been used. Please try again.";
            public const string Login2FARecoveryTooManyFails = "You have made too many failed attempts. Please wait {0} before attempting again.";
        }

        protected string recoveryCode;

        protected const int heightExtent = 100;
        protected const int widthExtent = 180;

        public override void Draw()
        {
            EditorGUILayout.Space();

            using (var messagePanel = new EditorGUILayout.HorizontalScope(GUILayout.MinHeight(60)))
            {
                EditorGUILayout.LabelField(string.Empty, GUILayout.Width(20));

                using (var content = new EditorGUILayout.VerticalScope())
                {
                    EditorGUILayout.LabelField(MessageBody, MessageStyle);

                    EditorGUILayout.LabelField(string.Empty);

                    recoveryCode = GUILayout.TextField(recoveryCode);

                    if (EngageUser.RecoveryCodeInvalid)
                    {
                        using (var warningColor = new GuiTools.ColorScope(CreatorStyle.Red))
                        {
                            if (EngageUser.AccountLocked(EngageUser.AccountLockType.RecoveryCode))
                            {
                                int timeRemaining = EngageUser.LockoutTimeRemaining(EngageUser.AccountLockType.RecoveryCode);
                                EditorGUILayout.LabelField(string.Format(Labels.Login2FARecoveryTooManyFails, timeRemaining.ToMinuteString()), MessageStyle);
                            }
                            else
                            {
                                EditorGUILayout.LabelField(Labels.Login2FARecoveryInvalidCodeMessage, MessageStyle);
                            }
                        }
                    }
                }

                EditorGUILayout.LabelField(string.Empty, GUILayout.Width(20));
            }

            EditorGUILayout.LabelField(string.Empty, GUILayout.ExpandHeight(true));

            using (var messagePanel = new EditorGUILayout.HorizontalScope())
            {
                using (var selectionButtons = new EditorGUILayout.HorizontalScope())
                {
                    GuiTools.DrawButton(LabelCancel, Cancel);
                }

                using (var selectionButtons = new EditorGUILayout.HorizontalScope())
                {
                    GuiTools.DrawButton(LabelConfirm, SubmitRecoverCode);
                }
            }
        }

        //public static void OpenDialog()
        //{
        //    var screenCenter = new Vector2(Screen.width, Screen.height) / 2;
        //    OpenDialog(screenCenter);
        //}

        public static void OpenDialog()//Vector2 position)
        {
            var dialog = GetWindow<Authentication2FARecoveryDialog>(Labels.Login2FARecoveryTitle);

            dialog.MessageBody = string.Format(Labels.Login2FARecoveryMessage, EngageUser.LastLoginRequestResponse.Details.PolicyGroup?.Name);

            dialog.LabelConfirm = Labels.Verify;

            var extents = new Vector2(widthExtent, heightExtent);

            dialog.maxSize = dialog.minSize = extents * 2;

            // TODO: Figure out the whole centering on parent view thing
            //dialog.position = new Rect(position - extents, dialog.maxSize);

            dialog.ShowModalUtility();
        }

        public async void SubmitRecoverCode()
        {
            var success = await EngageUser.Submit2FARecoveryCode(recoveryCode);

            if (success)
            {
                ConfirmSelection();
            }
        }
    }
}
