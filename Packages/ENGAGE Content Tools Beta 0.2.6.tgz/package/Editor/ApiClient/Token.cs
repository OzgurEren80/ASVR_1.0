﻿using Newtonsoft.Json;

namespace Engage.Network
{
    public class Token : IToken
    {
        [JsonProperty("access_token", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        public string AccessToken { get; set; }

        [JsonProperty("refresh_token", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        public string RefreshToken { get; set; }

        [JsonProperty("token_type", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        public string TokenType { get; set; }

        [JsonProperty("expires_in", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        public string ExpiresIn { get; set; }
    }
}